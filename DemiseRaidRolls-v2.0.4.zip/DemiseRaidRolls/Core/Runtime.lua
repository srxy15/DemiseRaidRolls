-- Legacy runtime coordinator. New independent systems belong in dedicated
-- Core, Features, Interface, or Utils modules and are loaded through the TOC.
local ADDON_NAME = "DemiseRaidRolls"

local RuntimeState = DemiseRaidRolls.RuntimeState
local UpdateUI
local SetButtonEnabled

-- Tie-break state. A tie-break never replaces the original valid roll. Instead,
-- each participating player's tiePath stores successive reroll values. Sorting
-- compares this path lexicographically, so repeated ties can be resolved safely
-- without breaking the original "first roll counts" rule.
local FinishTieBreak

local MAX_HISTORY = 200
local DEFAULT_ROLL_DURATION = 15
local MIN_ROLL_DURATION = 5
local MAX_ROLL_DURATION = 300

-- Raid synchronization -----------------------------------------------------------
-- The active Master Looter is the authoritative host for timed roll sessions.
-- Other raid members receive the item, timer state, and accepted rolls through
-- addon messages and operate the main window in viewer mode.
local SYNC_PREFIX = "ARRSYNC"
local SYNC_PROTOCOL = 2
local ADDON_VERSION = (DemiseRaidRolls.GetVersion and DemiseRaidRolls.GetVersion()) or "2.0.3"
local latestSeenVersion = ADDON_VERSION
local latestSeenVersionSender = nil
local notifiedNewerVersions = {}
local syncSessionID = nil
local syncOwner = nil
local syncStateRequested = false
local syncReceivingState = false
local GetActualMasterLooterName
local CanControlRolls
local UpdateControlState
local BroadcastRollSync
local BroadcastSessionEnd
local SendFullSyncState
local IsRemoteSyncedSession
local BroadcastLootHistory
local BroadcastLootCount
local UpdateOptionsControlState
local IsInRaid

local function Print(message)
    if DEFAULT_CHAT_FRAME then
        DEFAULT_CHAT_FRAME:AddMessage("|cff33ff99ARLC|r: " .. tostring(message))
    end
end

local function Trim(text)
    if not text then
        return nil
    end
    return (text:gsub("^%s+", ""):gsub("%s+$", ""))
end

local function NormalizeName(name)
    name = Trim(name)
    if not name or name == "" then
        return nil
    end

    name = name:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", "")

    if YOU and name == YOU then
        name = UnitName("player") or name
    end

    local shortName = name:match("^([^%-]+)") or name
    return string.lower(shortName)
end

local function IsSamePlayerName(a, b)
    local aKey = NormalizeName(a)
    local bKey = NormalizeName(b)
    return aKey ~= nil and bKey ~= nil and aKey == bKey
end

local function ShouldUseSyncedLootHistory()
    return IsInRaid()
        and syncOwner ~= nil
        and not IsSamePlayerName(syncOwner, UnitName("player"))
end

local function IsRaidCouncilModuleActive()
    return DemiseRaidRolls
        and DemiseRaidRolls.RaidCouncil
        and DemiseRaidRolls.RaidCouncil.IsEnabled
        and DemiseRaidRolls.RaidCouncil.IsEnabled() == true
end

local function IsMSOSPlusOneEnabled()
    if IsRaidCouncilModuleActive() then
        return false
    end
    if ShouldUseSyncedLootHistory() then
        return RuntimeState.syncedPlusOneEnabled == true
    end
    return AscensionRaidRollsDB and AscensionRaidRollsDB.msosPlusOneEnabled == true
end

local function GetActiveLootHistory()
    if ShouldUseSyncedLootHistory() then
        return RuntimeState.syncedLootHistory
    end
    return AscensionRaidRollsDB and AscensionRaidRollsDB.lootHistory or nil
end

local function GetLootWinCount(name, rollType)
    if not IsMSOSPlusOneEnabled() then
        return 0
    end

    local playerKey = NormalizeName(name)
    local history = GetActiveLootHistory()
    rollType = rollType == "OS" and "OS" or "MS"
    local typedHistory = type(history) == "table" and history[rollType] or nil
    return playerKey and type(typedHistory) == "table" and tonumber(typedHistory[playerKey]) or 0
end

local function GetRollDisplayName(name, rollType)
    local count = GetLootWinCount(name, rollType)
    if count > 0 then
        return tostring(name) .. " |cff73e68a+" .. tostring(count) .. "|r"
    end
    return tostring(name)
end

local function AdjustLootWinCount(name, rollType, delta, broadcast)
    if not AscensionRaidRollsDB or AscensionRaidRollsDB.msosPlusOneEnabled ~= true then
        return false
    end

    local playerKey = NormalizeName(name)
    if not playerKey then
        return false
    end

    rollType = rollType == "OS" and "OS" or "MS"
    AscensionRaidRollsDB.lootHistory = AscensionRaidRollsDB.lootHistory or { MS = {}, OS = {} }
    AscensionRaidRollsDB.lootHistory.MS = AscensionRaidRollsDB.lootHistory.MS or {}
    AscensionRaidRollsDB.lootHistory.OS = AscensionRaidRollsDB.lootHistory.OS or {}
    local typedHistory = AscensionRaidRollsDB.lootHistory[rollType]
    local nextCount = math.max(0, (tonumber(typedHistory[playerKey]) or 0) + (tonumber(delta) or 0))
    if nextCount > 0 then
        typedHistory[playerKey] = nextCount
    else
        typedHistory[playerKey] = nil
    end
    if broadcast and BroadcastLootCount then
        BroadcastLootCount(playerKey, rollType, nextCount)
    end
    return true
end

local function RecordLootWin(name, rollType)
    if not AscensionRaidRollsDB or AscensionRaidRollsDB.msosPlusOneEnabled ~= true then
        return false
    end

    local playerKey = NormalizeName(name)
    if not playerKey or RuntimeState.awardedPlayersForRoll[playerKey] then
        return false
    end
    rollType = rollType == "OS" and "OS" or "MS"

    local maximumWinners = math.max(1, tonumber(RuntimeState.currentTopRolls) or 1)
    if #RuntimeState.currentRollAwardOrder >= maximumWinners then
        return false
    end

    RuntimeState.currentRollAwardOrder[#RuntimeState.currentRollAwardOrder + 1] = { playerKey = playerKey, rollType = rollType }
    RuntimeState.awardedPlayersForRoll[playerKey] = true
    AdjustLootWinCount(playerKey, rollType, 1, true)
    return true
end

local function ClearLootHistory()
    if IsInRaid() and (not CanControlRolls or not CanControlRolls()) then
        Print("only the current Master Looter can clear the shared MS/OS+1 history.")
        return false
    end
    AscensionRaidRollsDB.lootHistory = { MS = {}, OS = {} }
    RuntimeState.awardedPlayersForRoll = {}
    RuntimeState.currentRollAwardOrder = {}
    if BroadcastLootHistory then
        BroadcastLootHistory()
    end
    if UpdateUI then
        UpdateUI()
    end
    Print("MS/OS+1 loot history cleared.")
    return true
end

IsInRaid = function()
    return (GetNumRaidMembers and GetNumRaidMembers() or 0) > 0
end

-- Base64 and JSON codecs are loaded from Features/SoftRes/Codec.lua.

function DemiseRaidRollsSoftRes.IsPriorityEnabled()
    if IsRaidCouncilModuleActive() then
        return false
    end
    if ShouldUseSyncedLootHistory() then
        return DemiseRaidRollsSoftRes.syncedPriorityEnabled == true
    end
    return AscensionRaidRollsDB and AscensionRaidRollsDB.reservePriorityEnabled == true
end

function DemiseRaidRollsSoftRes.GetData()
    return AscensionRaidRollsDB and AscensionRaidRollsDB.reserveData or nil
end

function DemiseRaidRollsSoftRes.IsPlayerSoftReserved(name, itemID)
    return DemiseRaidRollsSoftRes.GetPlayerReserveCount(name, itemID) > 0
end

function DemiseRaidRollsSoftRes.GetPlayerReserveCount(name, itemID)
    if not DemiseRaidRollsSoftRes.IsPriorityEnabled() then
        return 0
    end
    local playerKey = NormalizeName(name)
    local itemKey = tostring(tonumber(itemID) or 0)
    if not playerKey or itemKey == "0" then
        return 0
    end
    if ShouldUseSyncedLootHistory() then
        return math.max(0, math.floor(tonumber(DemiseRaidRollsSoftRes.syncedPlayers[playerKey]) or 0))
    end
    local data = DemiseRaidRollsSoftRes.GetData()
    return data and data.byItem and data.byItem[itemKey] and math.max(0, math.floor(tonumber(data.byItem[itemKey][playerKey]) or 0)) or 0
end

function DemiseRaidRollsSoftRes.GetTooltipReservations(itemID)
    if not DemiseRaidRollsSoftRes.IsPriorityEnabled() then
        return nil
    end

    local itemKey = tostring(tonumber(itemID) or 0)
    if itemKey == "0" then
        return nil
    end

    local reservations
    local roster
    if ShouldUseSyncedLootHistory() then
        if not RuntimeState.currentItemID or tonumber(RuntimeState.currentItemID) ~= tonumber(itemID) then
            return nil
        end
        reservations = DemiseRaidRollsSoftRes.syncedPlayers
    else
        local data = DemiseRaidRollsSoftRes.GetData()
        reservations = data and data.byItem and data.byItem[itemKey] or nil
        roster = data and data.roster or nil
    end
    if type(reservations) ~= "table" then
        return nil
    end

    local result = {}
    local playerKey, count
    for playerKey, count in pairs(reservations) do
        count = math.max(0, math.floor(tonumber(count) or 0))
        if count > 0 then
            local rosterEntry = roster and roster[playerKey] or nil
            local raidEntry = RuntimeState.raidMembers and RuntimeState.raidMembers[playerKey] or nil
            result[#result + 1] = {
                name = rosterEntry and rosterEntry.name or raidEntry and raidEntry.name or playerKey,
                count = count,
            }
        end
    end
    table.sort(result, function(a, b)
        return tostring(a.name):lower() < tostring(b.name):lower()
    end)
    return result
end

function DemiseRaidRollsSoftRes.GetCurrentHardReserve()
    if not DemiseRaidRollsSoftRes.IsPriorityEnabled() then
        return nil
    end
    if ShouldUseSyncedLootHistory() then
        return DemiseRaidRollsSoftRes.syncedHardReserve and true or nil
    end
    local data = DemiseRaidRollsSoftRes.GetData()
    return data and data.hardItems and data.hardItems[tostring(tonumber(RuntimeState.currentItemID) or 0)] or nil
end

function DemiseRaidRollsSoftRes.SetImportStatus(message, isError)
    if RuntimeState.optionsFrame and RuntimeState.optionsFrame.reserveStatus then
        RuntimeState.optionsFrame.reserveStatus:SetText(tostring(message or ""))
        if isError then
            RuntimeState.optionsFrame.reserveStatus:SetTextColor(1.0, 0.35, 0.35)
        else
            RuntimeState.optionsFrame.reserveStatus:SetTextColor(0.45, 0.95, 0.55)
        end
    end
    if DemiseRaidRollsSoftRes.importFrame and DemiseRaidRollsSoftRes.importFrame.status then
        DemiseRaidRollsSoftRes.importFrame.status:SetText(tostring(message or ""))
        if isError then
            DemiseRaidRollsSoftRes.importFrame.status:SetTextColor(1.0, 0.35, 0.35)
        else
            DemiseRaidRollsSoftRes.importFrame.status:SetTextColor(0.45, 0.95, 0.55)
        end
    end
end

function DemiseRaidRollsSoftRes.ImportExport(encoded)
    if IsInRaid() and (not CanControlRolls or not CanControlRolls()) then
        DemiseRaidRollsSoftRes.SetImportStatus("Only the Master Looter can import reserves in a raid.", true)
        return false
    end

    local decoded, decodeError = DemiseRaidRollsSoftRes.DecodeBase64(encoded)
    if not decoded then
        DemiseRaidRollsSoftRes.SetImportStatus("Import failed: " .. tostring(decodeError), true)
        return false
    end
    local root, jsonError = DemiseRaidRollsSoftRes.DecodeJSON(decoded)
    if type(root) ~= "table" then
        DemiseRaidRollsSoftRes.SetImportStatus("Import failed: " .. tostring(jsonError or "invalid JSON"), true)
        return false
    end
    if type(root.softreserves) ~= "table" or type(root.hardreserves) ~= "table" then
        DemiseRaidRollsSoftRes.SetImportStatus("Import failed: missing softreserves/hardreserves lists.", true)
        return false
    end

    local reserveData = {
        metadata = root.metadata or {},
        roster = {},
        byItem = {},
        hardItems = {},
    }
    local playerCount = 0
    local reserveCount = 0
    local _, playerData
    for _, playerData in ipairs(root.softreserves) do
        if type(playerData) == "table" and type(playerData.name) == "string" then
            local playerKey = NormalizeName(playerData.name)
            if playerKey then
                local rosterEntry = { name = playerData.name, itemCount = 0 }
                reserveData.roster[playerKey] = rosterEntry
                playerCount = playerCount + 1
                if type(playerData.items) == "table" then
                    local _, itemData
                    for _, itemData in ipairs(playerData.items) do
                        local itemID = type(itemData) == "table" and tonumber(itemData.id) or tonumber(itemData)
                        if itemID then
                            local itemKey = tostring(math.floor(itemID))
                            reserveData.byItem[itemKey] = reserveData.byItem[itemKey] or {}
                            reserveData.byItem[itemKey][playerKey] = (tonumber(reserveData.byItem[itemKey][playerKey]) or 0) + 1
                            rosterEntry.itemCount = rosterEntry.itemCount + 1
                            reserveCount = reserveCount + 1
                        end
                    end
                end
            end
        end
    end

    local hardCount = 0
    local function AddHardReserve(itemID, owner)
        itemID = tonumber(itemID)
        if itemID then
            reserveData.hardItems[tostring(math.floor(itemID))] = owner or true
            hardCount = hardCount + 1
        end
    end
    local _, hardData
    for _, hardData in pairs(root.hardreserves) do
        if type(hardData) == "number" then
            AddHardReserve(hardData)
        elseif type(hardData) == "table" then
            AddHardReserve(hardData.id or hardData.itemId, hardData.name or hardData.player)
            if type(hardData.items) == "table" then
                local _, itemData
                for _, itemData in ipairs(hardData.items) do
                    AddHardReserve(type(itemData) == "table" and (itemData.id or itemData.itemId) or itemData, hardData.name or hardData.player)
                end
            end
        end
    end

    AscensionRaidRollsDB.reserveData = reserveData
    AscensionRaidRollsDB.reserveImportText = Trim(encoded)
    DemiseRaidRollsSoftRes.SetImportStatus(tostring(playerCount) .. " players, " .. tostring(reserveCount) .. " SR, " .. tostring(hardCount) .. " HR imported.", false)
    Print("SoftRes import complete: " .. tostring(playerCount) .. " players, " .. tostring(reserveCount) .. " reservations, " .. tostring(hardCount) .. " hard reserves.")
    if DemiseRaidRollsSoftRes.BroadcastCurrentState then
        DemiseRaidRollsSoftRes.BroadcastCurrentState()
    end
    if UpdateUI then UpdateUI() end
    return true
end

-- A remote synchronized session exists only while the player is actually in
-- a raid. Outside a raid ARR switches to Standalone Mode and deliberately
-- ignores any stale ML/viewer state left over from a previous raid.
IsRemoteSyncedSession = function()
    if not IsInRaid() then
        return false
    end

    return syncSessionID ~= nil
        and syncOwner ~= nil
        and not IsSamePlayerName(syncOwner, UnitName("player"))
end

local function SendSyncRaw(message, channel, target)
    if not SendAddonMessage then
        return false
    end

    channel = channel or "RAID"
    if channel == "RAID" and not IsInRaid() then
        return false
    end
    if channel == "WHISPER" then
        if not target or target == "" then
            return false
        end
        SendAddonMessage(SYNC_PREFIX, message, channel, target)
    else
        SendAddonMessage(SYNC_PREFIX, message, channel)
    end
    return true
end

DemiseRaidRolls.TradeAwards.SetCompletedCallback(function(name, rollType)
    if RecordLootWin(name, rollType) then
        Print(tostring(name) .. " is now " .. tostring(rollType) .. " +" .. tostring(GetLootWinCount(name, rollType)) .. " for this loot history.")
        UpdateUI()
    end
end)

local function BroadcastRaidCouncilMode(channel, target)
    if not CanControlRolls or not CanControlRolls() then
        return false
    end

    local enabled = DemiseRaidRolls.RaidCouncil
        and DemiseRaidRolls.RaidCouncil.IsEnabled
        and DemiseRaidRolls.RaidCouncil.IsEnabled()
    return SendSyncRaw("MODE\t" .. (enabled and "1" or "0"), channel or "RAID", target)
end

DemiseRaidRolls.BroadcastRaidCouncilMode = BroadcastRaidCouncilMode

BroadcastLootHistory = function(channel, target)
    if not AscensionRaidRollsDB or not CanControlRolls or not CanControlRolls() then
        return false
    end

    channel = channel or "RAID"
    AscensionRaidRollsDB.lootHistoryRevision = (tonumber(AscensionRaidRollsDB.lootHistoryRevision) or 0) + 1
    local revision = AscensionRaidRollsDB.lootHistoryRevision
    -- Keep the ARR preference synchronized while ARC masks the feature so it
    -- can be restored immediately when the raid switches back to Raid Rolls.
    local enabled = AscensionRaidRollsDB.msosPlusOneEnabled == true and "1" or "0"
    SendSyncRaw("PLUSBEGIN\t" .. tostring(revision) .. "\t" .. enabled, channel, target)

    local _, rollType
    for _, rollType in ipairs({ "MS", "OS" }) do
        local playerKey, count
        for playerKey, count in pairs((AscensionRaidRollsDB.lootHistory and AscensionRaidRollsDB.lootHistory[rollType]) or {}) do
            count = math.max(0, math.floor(tonumber(count) or 0))
            if count > 0 then
                SendSyncRaw("PLUSENTRY\t" .. tostring(revision) .. "\t" .. tostring(rollType) .. "\t" .. tostring(playerKey) .. "\t" .. tostring(count), channel, target)
            end
        end
    end

    SendSyncRaw("PLUSEND\t" .. tostring(revision), channel, target)
    return true
end

DemiseRaidRollsSoftRes.BroadcastCurrentState = function(channel, target)
    if not AscensionRaidRollsDB or not CanControlRolls or not CanControlRolls() then
        return false
    end

    channel = channel or "RAID"
    local sessionID = tostring(syncSessionID or "0")
    -- Synchronize the stored ARR preference even while ARC is active; the
    -- effective IsPriorityEnabled() check remains false until ARR is selected.
    local enabled = AscensionRaidRollsDB.reservePriorityEnabled == true and "1" or "0"
    local data = DemiseRaidRollsSoftRes.GetData()
    local hardReserved = data
        and data.hardItems
        and data.hardItems[tostring(tonumber(RuntimeState.currentItemID) or 0)]
        and "1" or "0"
    SendSyncRaw("SRSTATE\t" .. sessionID .. "\t" .. enabled .. "\t" .. hardReserved, channel, target)

    if enabled == "1" and RuntimeState.currentItemID then
        local reservations = data and data.byItem and data.byItem[tostring(tonumber(RuntimeState.currentItemID) or 0)] or nil
        local playerKey
        local playerKey, reserveCount
        for playerKey, reserveCount in pairs(reservations or {}) do
            SendSyncRaw("SRPLAYER\t" .. sessionID .. "\t" .. tostring(playerKey) .. "\t" .. tostring(math.max(1, tonumber(reserveCount) or 1)), channel, target)
        end
    end
    return true
end

BroadcastLootCount = function(playerKey, rollType, count)
    if not IsInRaid() or not CanControlRolls or not CanControlRolls() then
        return false
    end

    AscensionRaidRollsDB.lootHistoryRevision = (tonumber(AscensionRaidRollsDB.lootHistoryRevision) or 0) + 1
    local revision = AscensionRaidRollsDB.lootHistoryRevision
    rollType = rollType == "OS" and "OS" or "MS"
    return SendSyncRaw("PLUSSET\t" .. tostring(revision) .. "\t" .. tostring(rollType) .. "\t" .. tostring(playerKey) .. "\t" .. tostring(math.max(0, tonumber(count) or 0)), "RAID")
end

local function NotifyNewerVersion(version, sender, force)
    if not DemiseRaidRolls.Version.IsNewer(version, ADDON_VERSION) then
        return
    end

    if DemiseRaidRolls.Version.IsNewer(version, latestSeenVersion) then
        latestSeenVersion = version
        latestSeenVersionSender = sender
    elseif version == latestSeenVersion and sender then
        latestSeenVersionSender = latestSeenVersionSender or sender
    end

    if not force and notifiedNewerVersions[version] then
        return
    end
    notifiedNewerVersions[version] = true

    local who = sender and (" (seen on " .. tostring(sender) .. ")") or ""
    Print("UPDATE AVAILABLE: v" .. tostring(version) .. who .. ". You are using v" .. tostring(ADDON_VERSION) .. ". Check the DemiseRaidRolls GitHub release page.")
    if UIErrorsFrame and UIErrorsFrame.AddMessage then
        UIErrorsFrame:AddMessage("DemiseRaidRolls update available: v" .. tostring(version), 1.0, 0.25, 0.25, 1.0)
    end
end

local function BroadcastVersion()
    local payload = "VER\t" .. tostring(SYNC_PROTOCOL) .. "\t" .. tostring(ADDON_VERSION)
    if IsInRaid() then
        SendSyncRaw(payload, "RAID")
    end
    if IsInGuild and IsInGuild() then
        SendSyncRaw(payload, "GUILD")
    elseif GetGuildInfo and GetGuildInfo("player") then
        SendSyncRaw(payload, "GUILD")
    end
end

local function GenerateSessionID()
    local name = UnitName("player") or "player"
    local stamp = math.floor(((GetTime and GetTime()) or 0) * 1000)
    return tostring(name) .. ":" .. tostring(stamp)
end

local function IsSenderCurrentMasterLooter(sender)
    if not GetActualMasterLooterName then
        return false
    end

    local actualMaster, method = GetActualMasterLooterName()
    if method ~= "master" or not actualMaster then
        return false
    end

    return IsSamePlayerName(sender, actualMaster)
end

local function RequestSyncState()
    local raidCount = GetNumRaidMembers and GetNumRaidMembers() or 0
    if raidCount <= 0 or not SendAddonMessage then
        return false
    end

    syncStateRequested = true
    return SendSyncRaw("REQ\t" .. tostring(SYNC_PROTOCOL), "RAID")
end

local function EscapePatternChar(char)
    if char:find("[%^%$%(%)%%%.%[%]%*%+%-%?]") then
        return "%" .. char
    end
    return char
end

local function BuildRollPattern()
    local formatString = RANDOM_ROLL_RESULT
    if type(formatString) ~= "string" or formatString == "" then
        return nil, nil
    end

    local pattern = "^"
    local captureOrder = {}
    local nextArgument = 1
    local i = 1

    while i <= #formatString do
        local char = formatString:sub(i, i)

        if char == "%" then
            local rest = formatString:sub(i)
            local position, specifier = rest:match("^%%(%d+)%$([sd])")

            if position and specifier then
                position = tonumber(position)
                captureOrder[#captureOrder + 1] = position
                if specifier == "d" then
                    pattern = pattern .. "(%d+)"
                else
                    pattern = pattern .. "(.+)"
                end
                i = i + 3 + #tostring(position)
            else
                specifier = formatString:sub(i + 1, i + 1)

                if specifier == "s" or specifier == "d" then
                    captureOrder[#captureOrder + 1] = nextArgument
                    nextArgument = nextArgument + 1
                    if specifier == "d" then
                        pattern = pattern .. "(%d+)"
                    else
                        pattern = pattern .. "(.+)"
                    end
                    i = i + 2
                elseif specifier == "%" then
                    pattern = pattern .. "%%"
                    i = i + 2
                else
                    pattern = pattern .. "%%"
                    i = i + 1
                end
            end
        else
            pattern = pattern .. EscapePatternChar(char)
            i = i + 1
        end
    end

    pattern = pattern .. "$"
    return pattern, captureOrder
end

local function ParseRollMessage(message)
    if not RuntimeState.rollPattern then
        RuntimeState.rollPattern, RuntimeState.rollCaptureOrder = BuildRollPattern()
    end

    if RuntimeState.rollPattern and RuntimeState.rollCaptureOrder then
        local captures = { string.match(message, RuntimeState.rollPattern) }
        if #captures > 0 then
            local args = {}
            for index, argumentPosition in ipairs(RuntimeState.rollCaptureOrder) do
                args[argumentPosition] = captures[index]
            end

            local playerName = args[1]
            local roll = tonumber(args[2])
            local minimum = tonumber(args[3])
            local maximum = tonumber(args[4])

            if playerName and roll and minimum and maximum then
                return Trim(playerName), roll, minimum, maximum
            end
        end
    end

    local minimum, maximum = message:match("%((%d+)%s*%-%s*(%d+)%)%s*$")
    minimum = tonumber(minimum)
    maximum = tonumber(maximum)

    if not minimum or not maximum then
        return nil
    end

    local prefix = message:gsub("%s*%(%d+%s*%-%s*%d+%)%s*$", "")
    local numbers = {}
    for number in prefix:gmatch("%d+") do
        numbers[#numbers + 1] = tonumber(number)
    end

    if #numbers == 0 then
        return nil
    end

    local roll = numbers[#numbers]
    local rollText = tostring(roll)
    local playerName = prefix:match("^(.-)%s+[^%s]*" .. rollText .. "%s*$")

    if not playerName or playerName == "" then
        return nil
    end

    playerName = playerName:match("^([^%s]+)") or playerName
    return Trim(playerName), roll, minimum, maximum
end

local function RefreshRaidMembers()
    RuntimeState.raidMembers = {}

    local count = GetNumRaidMembers and GetNumRaidMembers() or 0
    for i = 1, count do
        local name, rank, subgroup, level, class, classFile = GetRaidRosterInfo(i)
        local key = NormalizeName(name)
        if key then
            RuntimeState.raidMembers[key] = {
                name = name,
                classFile = classFile,
                rank = rank or 0,
                index = i,
            }
        end
    end
end

local function IsRaidMember(name)
    if not name then
        return false
    end

    local count = GetNumRaidMembers and GetNumRaidMembers() or 0
    if count <= 0 then
        return false
    end

    local key = NormalizeName(name)
    if key and RuntimeState.raidMembers[key] then
        return true
    end

    RefreshRaidMembers()
    return key and RuntimeState.raidMembers[key] ~= nil
end

-- Outside a raid, rolls are tracked locally so the addon can be fully tested
-- solo or in a normal party. Accept the player and visible party members.
local function IsLocalGroupMember(name)
    local key = NormalizeName(name)
    if not key then
        return false
    end

    if IsSamePlayerName(name, UnitName("player")) then
        return true
    end

    local i
    for i = 1, 4 do
        local partyName = UnitName and UnitName("party" .. i) or nil
        if partyName and IsSamePlayerName(name, partyName) then
            return true
        end
    end

    return false
end

local function GetClassColorCode(name)
    local key = NormalizeName(name)
    local member = key and RuntimeState.raidMembers[key]
    local classFile = member and member.classFile

    if not classFile and IsSamePlayerName(name, UnitName("player")) then
        local _, playerClass = UnitClass("player")
        classFile = playerClass
    end
    if not classFile then
        for i = 1, (GetNumPartyMembers and GetNumPartyMembers() or 0) do
            local unit = "party" .. i
            if IsSamePlayerName(name, UnitName(unit)) then
                local _, partyClass = UnitClass(unit)
                classFile = partyClass
                break
            end
        end
    end

    return DemiseRaidRolls.GetClassColorCode(classFile)
end

local function CompareTiePaths(a, b)
    local pathA = a.tiePath or {}
    local pathB = b.tiePath or {}
    local maxLen = math.max(#pathA, #pathB)
    local i

    for i = 1, maxLen do
        local valueA = pathA[i]
        local valueB = pathB[i]

        if valueA ~= nil and valueB ~= nil and valueA ~= valueB then
            return valueA > valueB
        end

        -- A different path length should normally only happen after the players
        -- were already separated by an earlier tie-break value. If it does occur,
        -- keep the shorter path stable instead of inventing a result.
        if valueA == nil or valueB == nil then
            break
        end
    end

    return nil
end

local function GetTieSignature(entry)
    if not entry then
        return nil
    end

    local parts = { tostring(entry.roll or 0) }
    local path = entry.tiePath or {}
    local i
    for i = 1, #path do
        parts[#parts + 1] = tostring(path[i])
    end
    return table.concat(parts, ":")
end

local function SortRolls(list)
    table.sort(list, function(a, b)
        if a == b then
            return false
        end
        if a.isSoftReserved ~= b.isSoftReserved then
            return a.isSoftReserved == true
        end
        if a.roll ~= b.roll then
            return a.roll > b.roll
        end

        local tieCompare = CompareTiePaths(a, b)
        if tieCompare ~= nil then
            return tieCompare
        end

        return (tonumber(a.sequence) or 0) < (tonumber(b.sequence) or 0)
    end)
end

local function GetAllRolls()
    local all = {}
    local i

    for i = 1, #RuntimeState.rollsMS do
        all[#all + 1] = RuntimeState.rollsMS[i]
    end

    for i = 1, #RuntimeState.rollsOS do
        all[#all + 1] = RuntimeState.rollsOS[i]
    end

    return all
end

local function RefreshDuplicateFlags()
    local counts = {}
    local tieCounts = {}
    local all = GetAllRolls()
    local i

    for i = 1, #all do
        local entry = all[i]
        counts[entry.playerKey] = (counts[entry.playerKey] or 0) + 1
    end

    for i = 1, #all do
        local entry = all[i]
        if entry.isFirst == nil then
            entry.isFirst = RuntimeState.firstRollByPlayer[entry.playerKey] == entry.sequence
        end
        entry.isReroll = not entry.isFirst
        entry.hasDuplicate = (counts[entry.playerKey] or 0) > 1
        entry.isTied = false

        if entry.isFirst then
            local tieKey = tostring(entry.type or "") .. "|" .. tostring(GetTieSignature(entry) or "")
            tieCounts[tieKey] = (tieCounts[tieKey] or 0) + 1
        end
    end

    for i = 1, #all do
        local entry = all[i]
        if entry.isFirst then
            local tieKey = tostring(entry.type or "") .. "|" .. tostring(GetTieSignature(entry) or "")
            entry.isTied = (tieCounts[tieKey] or 0) > 1
        end
    end
end

local function FindValidEntry(playerKey, rollType)
    local list = rollType == "OS" and RuntimeState.rollsOS or RuntimeState.rollsMS
    local i
    for i = 1, #list do
        local entry = list[i]
        if entry.playerKey == playerKey and entry.isFirst then
            return entry
        end
    end
    return nil
end

local function GetTieGroupForEntry(entry)
    local group = {}
    if not entry or not entry.isFirst or not entry.isTied then
        return group
    end

    local list = entry.type == "OS" and RuntimeState.rollsOS or RuntimeState.rollsMS
    local signature = GetTieSignature(entry)
    local i
    for i = 1, #list do
        local candidate = list[i]
        if candidate.isFirst and GetTieSignature(candidate) == signature then
            group[#group + 1] = candidate
        end
    end

    table.sort(group, function(a, b)
        if a == b then
            return false
        end
        return (tonumber(a.sequence) or 0) < (tonumber(b.sequence) or 0)
    end)
    return group
end

local function GetValidCount(list)
    local count = 0
    local i
    for i = 1, #list do
        if list[i].isFirst then
            count = count + 1
        end
    end
    return count
end

local function GetWinner()
    local bestMS
    local bestOS
    local i

    for i = 1, #RuntimeState.rollsMS do
        local entry = RuntimeState.rollsMS[i]
        if entry.isFirst then
            if not bestMS
                or (entry.isSoftReserved and not bestMS.isSoftReserved)
                or (entry.isSoftReserved == bestMS.isSoftReserved and (entry.roll > bestMS.roll or (entry.roll == bestMS.roll and (tonumber(entry.sequence) or 0) < (tonumber(bestMS.sequence) or 0)))) then
                bestMS = entry
            end
        end
    end

    if bestMS then
        return bestMS
    end

    for i = 1, #RuntimeState.rollsOS do
        local entry = RuntimeState.rollsOS[i]
        if entry.isFirst then
            if not bestOS or entry.roll > bestOS.roll or (entry.roll == bestOS.roll and (tonumber(entry.sequence) or 0) < (tonumber(bestOS.sequence) or 0)) then
                bestOS = entry
            end
        end
    end

    return bestOS
end

local function UpdatePanel(panel, list)
    if not panel then
        return
    end

    SortRolls(list)

    local rowHeight = 22
    local minimumHeight = panel.scroll:GetHeight()
    local contentHeight = math.max(minimumHeight, #list * rowHeight)
    panel.content:SetHeight(contentHeight)

    local validRank = 0
    local i
    for i = 1, #list do
        local row = panel.rows[i]
        if not row then
            row = CreateFrame("Button", nil, panel.content)
            row:SetHeight(rowHeight)
            row:SetPoint("TOPLEFT", panel.content, "TOPLEFT", 0, -((i - 1) * rowHeight))
            row:SetPoint("RIGHT", panel.content, "RIGHT", 0, 0)
            row:RegisterForClicks("LeftButtonUp")

            row.bg = row:CreateTexture(nil, "BACKGROUND")
            row.bg:SetAllPoints(row)

            row.selection = row:CreateTexture(nil, "BORDER")
            row.selection:SetAllPoints(row)
            row.selection:SetTexture(0.18, 0.52, 0.95, 0.32)
            row.selection:Hide()

            row.hover = row:CreateTexture(nil, "HIGHLIGHT")
            row.hover:SetAllPoints(row)
            row.hover:SetTexture(1, 1, 1, 0.08)

            row:SetScript("OnClick", function(self)
                if not self.entry then
                    return
                end

                if CanControlRolls and not CanControlRolls() then
                    return
                end

                RuntimeState.selectedRoll = self.entry
                if UpdateUI then
                    UpdateUI()
                end
            end)

            row.rank = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            row.rank:SetPoint("LEFT", row, "LEFT", 3, 0)
            row.rank:SetWidth(22)
            row.rank:SetJustifyH("RIGHT")

            row.name = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            row.name:SetPoint("LEFT", row.rank, "RIGHT", 5, 0)
            row.name:SetWidth(100)
            row.name:SetJustifyH("LEFT")

            row.minusButton = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
            row.minusButton:SetWidth(14)
            row.minusButton:SetHeight(14)
            row.minusButton:SetText("-")
            row.minusButton:SetScript("OnClick", function(self)
                local entry = self:GetParent().entry
                if entry and CanControlRolls and CanControlRolls() then
                    AdjustLootWinCount(entry.name, entry.type, -1, true)
                    UpdateUI()
                end
            end)

            row.plusButton = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
            row.plusButton:SetWidth(14)
            row.plusButton:SetHeight(14)
            row.plusButton:SetPoint("RIGHT", row, "RIGHT", -3, 0)
            row.plusButton:SetText("+")
            row.plusButton:SetScript("OnClick", function(self)
                local entry = self:GetParent().entry
                if entry and CanControlRolls and CanControlRolls() then
                    AdjustLootWinCount(entry.name, entry.type, 1, true)
                    UpdateUI()
                end
            end)

            row.minusButton:SetPoint("RIGHT", row.plusButton, "LEFT", -1, 0)

            row.status = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            row.status:SetPoint("LEFT", row.name, "RIGHT", 2, 0)
            row.status:SetWidth(36)
            row.status:SetJustifyH("CENTER")

            row.value = row:CreateFontString(nil, "OVERLAY", "GameFontNormal")
            row.value:SetPoint("RIGHT", row.minusButton, "LEFT", -2, 0)
            row.value:SetWidth(34)
            row.value:SetJustifyH("RIGHT")

            panel.rows[i] = row
        end

        local entry = list[i]
        row.entry = entry

        local showAdjustmentButtons = entry.isFirst and IsMSOSPlusOneEnabled()
        if showAdjustmentButtons then
            local canAdjust = CanControlRolls and CanControlRolls() or false
            row.minusButton:Show()
            row.plusButton:Show()
            SetButtonEnabled(row.minusButton, canAdjust)
            SetButtonEnabled(row.plusButton, canAdjust)
        else
            row.minusButton:Hide()
            row.plusButton:Hide()
        end

        if entry.isFirst then
            validRank = validRank + 1
            row.rank:SetText(validRank .. ".")
            row.name:SetText(GetClassColorCode(entry.name) .. GetRollDisplayName(entry.name, entry.type) .. "|r")
            row.value:SetText(entry.roll)
            row.rank:SetTextColor(1, 1, 1)
            row.value:SetTextColor(1, 0.82, 0.20)

            local latestTieRoll = entry.tiePath and entry.tiePath[#entry.tiePath] or nil
            local isCurrentTiePlayer = RuntimeState.tieBreakActive and RuntimeState.tieBreakPlayers[entry.playerKey] and entry.type == RuntimeState.tieBreakType

            if isCurrentTiePlayer and RuntimeState.tieBreakRoundRolls[entry.playerKey] then
                row.status:SetText("TB " .. tostring(RuntimeState.tieBreakRoundRolls[entry.playerKey]))
                row.status:SetTextColor(0.35, 1.0, 0.35)
                row.bg:SetTexture(0.55, 0.35, 0.05, 0.24)
            elseif isCurrentTiePlayer then
                row.status:SetText("TIE")
                row.status:SetTextColor(1.0, 0.65, 0.15)
                row.bg:SetTexture(0.65, 0.35, 0.02, 0.24)
            elseif entry.isTied then
                row.status:SetText("TIE")
                row.status:SetTextColor(1.0, 0.65, 0.15)
                row.bg:SetTexture(0.65, 0.35, 0.02, 0.24)
            elseif latestTieRoll then
                row.status:SetText("TB " .. tostring(latestTieRoll))
                row.status:SetTextColor(0.45, 0.95, 0.55)
                row.bg:SetTexture(0.08, 0.45, 0.18, 0.16)
            elseif entry.isSoftReserved then
                row.status:SetText(tostring(entry.softReserveIndex or 1) .. "xSR")
                row.status:SetTextColor(0.75, 0.45, 1.0)
                row.bg:SetTexture(0.38, 0.12, 0.60, 0.22)
            elseif entry.hasDuplicate then
                row.status:SetText("FIRST")
                row.status:SetTextColor(0.35, 1.0, 0.35)
                row.bg:SetTexture(0.10, 0.55, 0.10, 0.20)
            else
                row.status:SetText("")
                if (i % 2) == 0 then
                    row.bg:SetTexture(1, 1, 1, 0.035)
                else
                    row.bg:SetTexture(0, 0, 0, 0)
                end
            end
        else
            row.rank:SetText("x")
            row.rank:SetTextColor(1.0, 0.35, 0.35)
            row.name:SetText("|cff888888" .. GetRollDisplayName(entry.name, entry.type) .. "|r")
            row.status:SetText("REROLL")
            row.status:SetTextColor(1.0, 0.35, 0.35)
            row.value:SetText(entry.roll)
            row.value:SetTextColor(1, 0.82, 0.20)
            row.bg:SetTexture(0.60, 0.08, 0.08, 0.18)
        end

        if RuntimeState.selectedRoll == entry then
            row.selection:Show()
        else
            row.selection:Hide()
        end

        row:Show()
    end

    for i = #list + 1, #panel.rows do
        panel.rows[i].entry = nil
        panel.rows[i].selection:Hide()
        panel.rows[i]:Hide()
    end
end

SetButtonEnabled = function(button, enabled)
    if not button then
        return
    end

    if enabled then
        button:Enable()
        if button.SetAlpha then
            button:SetAlpha(1.0)
        end
    else
        button:Disable()
        if button.SetAlpha then
            button:SetAlpha(0.45)
        end
    end
end

local function UpdateWinnerDisplay()
    if not RuntimeState.mainFrame then
        return
    end

    local canControl = CanControlRolls and CanControlRolls() or false

    if RuntimeState.selectedRoll and canControl then
        local status = ""
        if RuntimeState.selectedRoll.isReroll then
            status = "  |cffff6666[REROLL]|r"
        elseif RuntimeState.selectedRoll.isTied then
            status = "  |cffffa62b[TIE]|r"
        elseif RuntimeState.selectedRoll.tiePath and #RuntimeState.selectedRoll.tiePath > 0 then
            status = "  |cff73e68a[TB " .. tostring(RuntimeState.selectedRoll.tiePath[#RuntimeState.selectedRoll.tiePath]) .. "]|r"
        end
        RuntimeState.mainFrame.winnerText:SetText(
            "Selected: " .. GetClassColorCode(RuntimeState.selectedRoll.name) .. RuntimeState.selectedRoll.name .. "|r  -  |cffffd24a" .. RuntimeState.selectedRoll.roll .. "|r  (" .. RuntimeState.selectedRoll.type .. ")" .. status
        )
        SetButtonEnabled(RuntimeState.mainFrame.tradeButton, true)
    elseif canControl then
        RuntimeState.mainFrame.winnerText:SetText("Selected: |cff888888click a roll to choose a winner|r")
        SetButtonEnabled(RuntimeState.mainFrame.tradeButton, false)
    else
        RuntimeState.mainFrame.winnerText:SetText("|cffaaaaaaViewer mode - the Master Looter selects and trades winners|r")
        SetButtonEnabled(RuntimeState.mainFrame.tradeButton, false)
    end
end

UpdateUI = function()
    if not RuntimeState.mainFrame then
        return
    end

    RefreshDuplicateFlags()
    UpdatePanel(RuntimeState.msPanel, RuntimeState.rollsMS)
    UpdatePanel(RuntimeState.osPanel, RuntimeState.rollsOS)

    RuntimeState.mainFrame.msCount:SetText("MS  (1-100)   |cffaaaaaa" .. GetValidCount(RuntimeState.rollsMS) .. " valid|r")
    RuntimeState.mainFrame.osCount:SetText("OS  (1-99)   |cffaaaaaa" .. GetValidCount(RuntimeState.rollsOS) .. " valid|r")
    UpdateWinnerDisplay()
    if UpdateControlState then
        UpdateControlState()
    end
    if DemiseRaidRolls.ApplyHighContrast then DemiseRaidRolls.ApplyHighContrast() end
end

function DemiseRaidRolls.CheckVersion()
    BroadcastVersion()
    if DemiseRaidRolls.Version.IsNewer(latestSeenVersion, ADDON_VERSION) then
        NotifyNewerVersion(latestSeenVersion, latestSeenVersionSender, true)
    else
        Print("VERSION CHECK: You are using v" .. tostring(ADDON_VERSION) .. ". No newer ARLC version has been seen this session.")
    end
end

local function AddTieBreakRoll(name, roll, minimum, maximum, bypassRaidCheck)
    if not RuntimeState.tieBreakActive or minimum ~= 1 then
        return false
    end

    local expectedMaximum = RuntimeState.tieBreakType == "OS" and 99 or 100
    if maximum ~= expectedMaximum then
        return false
    end

    local playerKey = NormalizeName(name)
    if not playerKey or not RuntimeState.tieBreakPlayers[playerKey] then
        return false
    end

    if RuntimeState.tieBreakRoundRolls[playerKey] ~= nil then
        return false
    end

    if not bypassRaidCheck then
        if IsInRaid() then
            if not IsRaidMember(name) then
                return false
            end
        elseif not IsLocalGroupMember(name) then
            return false
        end
    end

    local entry = FindValidEntry(playerKey, RuntimeState.tieBreakType)
    if not entry then
        return false
    end

    entry.tiePath = entry.tiePath or {}
    entry.tiePath[#entry.tiePath + 1] = roll
    RuntimeState.tieBreakRoundRolls[playerKey] = roll

    if not bypassRaidCheck and IsInRaid() and syncSessionID and CanControlRolls and CanControlRolls() then
        local message = table.concat({
            "TIEROLL",
            tostring(syncSessionID),
            tostring(RuntimeState.tieBreakRound),
            tostring(name or ""),
            tostring(roll or 0),
            tostring(maximum or expectedMaximum),
        }, "\t")
        SendSyncRaw(message, "RAID")
    end

    -- Publish the authoritative result before rendering it. A local UI fault
    -- must never prevent viewers from receiving an otherwise valid tie roll.
    UpdateUI()
    return true
end

local function AddRoll(name, roll, minimum, maximum, bypassRaidCheck, validOverride, softReserveIndexOverride)
    if minimum ~= 1 then
        return false
    end

    if RuntimeState.tieBreakActive then
        return AddTieBreakRoll(name, roll, minimum, maximum, bypassRaidCheck)
    end

    if not bypassRaidCheck and RuntimeState.rollSessionStarted and not RuntimeState.rollSessionOpen then
        return false
    end

    if not bypassRaidCheck then
        if IsInRaid() then
            if not IsRaidMember(name) then
                return false
            end
        elseif not IsLocalGroupMember(name) then
            return false
        end
    end

    local rollType
    local targetList

    if maximum == 100 then
        rollType = "MS"
        targetList = RuntimeState.rollsMS
    elseif maximum == 99 then
        rollType = "OS"
        targetList = RuntimeState.rollsOS
    else
        return false
    end

    local playerKey = NormalizeName(name)
    if not playerKey then
        return false
    end

    local allRolls = GetAllRolls()
    local hasValidRoll = false
    local validMSRolls = 0
    local i
    for i = 1, #allRolls do
        local previous = allRolls[i]
        if previous.playerKey == playerKey and previous.isFirst then
            hasValidRoll = true
            if previous.type == "MS" then validMSRolls = validMSRolls + 1 end
        end
    end

    local reserveCount = rollType == "MS" and DemiseRaidRollsSoftRes.GetPlayerReserveCount(name, RuntimeState.currentItemID) or 0
    local isValid
    if rollType == "MS" and reserveCount > 0 then
        isValid = validMSRolls < reserveCount
    else
        isValid = not hasValidRoll
    end
    local softReserveIndex = isValid and reserveCount > 0 and (validMSRolls + 1) or nil
    if validOverride ~= nil then isValid = validOverride == true end
    if tonumber(softReserveIndexOverride) and tonumber(softReserveIndexOverride) > 0 then
        softReserveIndex = math.floor(tonumber(softReserveIndexOverride))
    elseif validOverride == false then
        softReserveIndex = nil
    end

    RuntimeState.sequence = RuntimeState.sequence + 1

    if isValid and not RuntimeState.firstRollByPlayer[playerKey] then RuntimeState.firstRollByPlayer[playerKey] = RuntimeState.sequence end

    local entry = {
        name = name,
        playerKey = playerKey,
        roll = roll,
        minimum = minimum,
        maximum = maximum,
        type = rollType,
        sequence = RuntimeState.sequence,
        isFirst = isValid,
        isSoftReserved = softReserveIndex ~= nil,
        softReserveIndex = softReserveIndex,
    }
    targetList[#targetList + 1] = entry

    if #targetList > MAX_HISTORY then
        table.remove(targetList, 1)
    end

    -- Only the authoritative Master Looter republishes rolls. Remote viewers
    -- receive these messages instead of trusting their own CHAT_MSG_SYSTEM
    -- timing, so the host decides exactly which rolls arrived before 0. Send
    -- before rendering so a local UI error cannot silently drop the sync.
    if not bypassRaidCheck and RuntimeState.rollSessionStarted and RuntimeState.rollSessionOpen and BroadcastRollSync and CanControlRolls and CanControlRolls() then
        BroadcastRollSync(entry)
    end

    UpdateUI()
    return true
end

local function ClearRolls()
    RuntimeState.rollsMS = {}
    RuntimeState.rollsOS = {}
    RuntimeState.firstRollByPlayer = {}
    RuntimeState.selectedRoll = nil
    RuntimeState.sequence = 0
    RuntimeState.tieBreakActive = false
    RuntimeState.tieBreakType = nil
    RuntimeState.tieBreakPlayers = {}
    RuntimeState.tieBreakRoundRolls = {}
    RuntimeState.tieBreakRound = 0
    UpdateUI()
end

BroadcastRollSync = function(entry, channel, target)
    if not entry or not syncSessionID then
        return false
    end

    local message = table.concat({
        "ROLL",
        tostring(syncSessionID),
        tostring(entry.name or ""),
        tostring(entry.roll or 0),
        tostring(entry.minimum or 1),
        tostring(entry.maximum or 0),
        entry.isFirst and "1" or "0",
        tostring(entry.softReserveIndex or 0),
    }, "\t")

    return SendSyncRaw(message, channel or "RAID", target)
end

SendFullSyncState = function(target)
    if not CanControlRolls or not CanControlRolls() or not target then
        return false
    end

    BroadcastRaidCouncilMode("WHISPER", target)

    if not RuntimeState.rollSessionStarted or not syncSessionID then
        SendSyncRaw("IDLE\t" .. tostring(SYNC_PROTOCOL), "WHISPER", target)
        BroadcastLootHistory("WHISPER", target)
        return true
    end

    local now = GetTime and GetTime() or 0
    local remaining = 0
    if RuntimeState.rollSessionOpen and RuntimeState.rollTimerActive then
        remaining = math.max(0, RuntimeState.rollEndTime - now)
    end

    local stateMessage = table.concat({
        "STATE",
        tostring(syncSessionID),
        RuntimeState.rollSessionOpen and "1" or "0",
        string.format("%.2f", remaining),
        tostring(RuntimeState.activeDuration or DEFAULT_ROLL_DURATION),
        tostring(RuntimeState.currentItemID or 0),
        tostring(RuntimeState.currentItemLink or ""),
    }, "\t")

    SendSyncRaw(stateMessage, "WHISPER", target)
    SendSyncRaw("TOP\t" .. tostring(syncSessionID) .. "\t" .. tostring(RuntimeState.currentTopRolls or 1), "WHISPER", target)
    DemiseRaidRollsSoftRes.BroadcastCurrentState("WHISPER", target)
    BroadcastLootHistory("WHISPER", target)

    local all = GetAllRolls()
    table.sort(all, function(a, b)
        if a == b then
            return false
        end
        return (tonumber(a.sequence) or 0) < (tonumber(b.sequence) or 0)
    end)

    local i
    for i = 1, #all do
        BroadcastRollSync(all[i], "WHISPER", target)
    end

    -- Rebuild completed tie-break history for players that reload mid-session.
    -- While a tie-break is still active, omit the current round's last value
    -- here; it is replayed as TIEROLL after TIESTATE so the viewer also knows
    -- that player has already used their one allowed reroll for this round.
    for i = 1, #all do
        local entry = all[i]
        if entry.isFirst and entry.tiePath and #entry.tiePath > 0 then
            local pathParts = {}
            local pathLimit = #entry.tiePath
            if RuntimeState.tieBreakActive and RuntimeState.tieBreakPlayers[entry.playerKey] and RuntimeState.tieBreakRoundRolls[entry.playerKey] ~= nil then
                pathLimit = math.max(0, pathLimit - 1)
            end
            local pathIndex
            for pathIndex = 1, pathLimit do
                pathParts[#pathParts + 1] = tostring(entry.tiePath[pathIndex])
            end
            if #pathParts > 0 then
                SendSyncRaw(table.concat({
                    "TBPATH",
                    tostring(syncSessionID),
                    tostring(entry.name or ""),
                    tostring(entry.type or "MS"),
                    table.concat(pathParts, ","),
                }, "\t"), "WHISPER", target)
            end
        end
    end

    if RuntimeState.tieBreakActive then
        local names = {}
        for playerKey in pairs(RuntimeState.tieBreakPlayers) do
            local entry = FindValidEntry(playerKey, RuntimeState.tieBreakType)
            if entry then
                names[#names + 1] = entry.name
            end
        end
        table.sort(names)

        SendSyncRaw(table.concat({
            "TIESTATE",
            tostring(syncSessionID),
            tostring(RuntimeState.tieBreakRound),
            tostring(RuntimeState.tieBreakType or "MS"),
            string.format("%.2f", remaining),
            tostring(RuntimeState.activeDuration or DEFAULT_ROLL_DURATION),
            table.concat(names, ","),
        }, "\t"), "WHISPER", target)

        for playerKey, tieRoll in pairs(RuntimeState.tieBreakRoundRolls) do
            local entry = FindValidEntry(playerKey, RuntimeState.tieBreakType)
            if entry then
                SendSyncRaw(table.concat({
                    "TIEROLL",
                    tostring(syncSessionID),
                    tostring(RuntimeState.tieBreakRound),
                    tostring(entry.name or ""),
                    tostring(tieRoll or 0),
                    tostring(RuntimeState.tieBreakType == "OS" and 99 or 100),
                }, "\t"), "WHISPER", target)
            end
        end
    end

    SendSyncRaw("STATEDONE\t" .. tostring(syncSessionID), "WHISPER", target)
    return true
end

local function GetPlayerRaidRank()
    local playerKey = NormalizeName(UnitName("player"))
    if not playerKey then
        return 0
    end

    if not RuntimeState.raidMembers[playerKey] then
        RefreshRaidMembers()
    end

    local member = RuntimeState.raidMembers[playerKey]
    return member and member.rank or 0
end

local function SendRaidAnnouncement(message, allowRaidFallback)
    local raidCount = GetNumRaidMembers and GetNumRaidMembers() or 0

    -- Standalone Mode: outside a raid there is no /rw channel to use. In a
    -- normal party, mirror the announcement to /party; when solo, print it
    -- locally so Start Rolls / winner / timer flows can still be fully tested.
    if raidCount <= 0 then
        local partyCount = GetNumPartyMembers and GetNumPartyMembers() or 0
        if partyCount > 0 and SendChatMessage then
            SendChatMessage(message, "PARTY")
        else
            Print("[Standalone] " .. tostring(message))
        end
        return true
    end

    if not SendChatMessage then
        Print("SendChatMessage is unavailable on this client.")
        return false
    end

    if GetPlayerRaidRank() >= 1 then
        SendChatMessage(message, "RAID_WARNING")
        return true
    end

    if allowRaidFallback then
        SendChatMessage(message, "RAID")
        Print("you are not raid leader/assistant, so the message was sent in /raid instead of /rw.")
        return true
    end

    Print("you must be raid leader or assistant to send this message in /rw.")
    return false
end

local function CheckMissingReservations()
    if not IsInRaid() then
        Print("join a raid before checking the SoftRes roster.")
        return false
    end
    if not CanControlRolls or not CanControlRolls() then
        Print("only the Master Looter can check missing reservations in a raid.")
        return false
    end
    local data = DemiseRaidRollsSoftRes.GetData()
    if not data or type(data.roster) ~= "table" then
        Print("import a SoftRes list first.")
        return false
    end

    local limit = math.max(1, math.floor(tonumber(AscensionRaidRollsDB.softResLimit) or 2))
    local missing = {}
    local incomplete = {}
    local raidCount = GetNumRaidMembers and GetNumRaidMembers() or 0
    local i
    for i = 1, raidCount do
        local raidName = GetRaidRosterInfo(i)
        local playerKey = NormalizeName(raidName)
        if playerKey then
            local entry = data.roster[playerKey]
            if not entry then
                missing[#missing + 1] = tostring(raidName)
            else
                local count = math.max(0, math.floor(tonumber(entry.itemCount) or 0))
                if count < limit then
                    incomplete[#incomplete + 1] = tostring(raidName) .. " (" .. tostring(count) .. "/" .. tostring(limit) .. ")"
                end
            end
        end
    end
    table.sort(missing)
    table.sort(incomplete)

    local function AnnounceList(prefix, list)
        local line = prefix
        local index
        for index = 1, #list do
            local addition = (line == prefix and "" or ", ") .. list[index]
            if #line + #addition > 220 then
                SendRaidAnnouncement(line, true)
                line = prefix .. list[index]
            else
                line = line .. addition
            end
        end
        if line ~= prefix then SendRaidAnnouncement(line, true) end
    end

    if #missing > 0 then
        AnnounceList("Missing from SoftRes export: ", missing)
    end
    if #incomplete > 0 then
        AnnounceList("Incomplete SoftRes (max " .. tostring(limit) .. "): ", incomplete)
    end
    if #missing > 0 or #incomplete > 0 then
        local reservationURL = Trim(AscensionRaidRollsDB.softResURL or "") or ""
        local invitation = "Please complete your SoftRes reservations"
        if reservationURL ~= "" then
            invitation = invitation .. ": " .. reservationURL
        else
            invitation = invitation .. " on the BisBeard reservation page."
        end
        SendRaidAnnouncement(invitation, false)
    end
    if #missing == 0 and #incomplete == 0 then
        SendRaidAnnouncement("SoftRes check: every raid member is in the export and has used " .. tostring(limit) .. "/" .. tostring(limit) .. " reservations.", true)
    end
    Print("SoftRes roster check: " .. tostring(#missing) .. " missing from export, " .. tostring(#incomplete) .. " below the " .. tostring(limit) .. " SR limit.")
    return true
end

local function ShowLocalTimerAlert(text)
    if RaidNotice_AddMessage and RaidWarningFrame and ChatTypeInfo and ChatTypeInfo["RAID_WARNING"] then
        RaidNotice_AddMessage(RaidWarningFrame, tostring(text), ChatTypeInfo["RAID_WARNING"])
    elseif UIErrorsFrame and UIErrorsFrame.AddMessage then
        UIErrorsFrame:AddMessage(tostring(text), 1.0, 0.2, 0.2, 1.0)
    end

    if PlaySound then
        pcall(PlaySound, "RaidWarning")
    end
end

local function GetConfiguredDuration()
    local duration

    if RuntimeState.mainFrame and RuntimeState.mainFrame.durationEdit then
        duration = tonumber(RuntimeState.mainFrame.durationEdit:GetText())
    end

    if not duration and AscensionRaidRollsDB then
        duration = tonumber(AscensionRaidRollsDB.rollDuration)
    end

    duration = math.floor((duration or DEFAULT_ROLL_DURATION) + 0.5)

    if duration < MIN_ROLL_DURATION then
        duration = MIN_ROLL_DURATION
    elseif duration > MAX_ROLL_DURATION then
        duration = MAX_ROLL_DURATION
    end

    if AscensionRaidRollsDB then
        AscensionRaidRollsDB.rollDuration = duration
    end

    if RuntimeState.mainFrame and RuntimeState.mainFrame.durationEdit then
        RuntimeState.mainFrame.durationEdit:SetText(tostring(duration))
    end

    return duration
end

local function GetTopRollsLabel()
    local count = math.max(1, tonumber(RuntimeState.currentTopRolls) or 1)
    if count == 1 then
        return "Top 1 roll"
    end
    return "Top " .. tostring(count) .. " rolls"
end

local function UpdateItemDisplay()
    if not RuntimeState.mainFrame then
        return
    end

    local canControl = CanControlRolls and CanControlRolls() or false

    if RuntimeState.currentItemLink then
        local itemName, resolvedLink, _, _, _, _, _, _, _, texture = GetItemInfo(RuntimeState.currentItemLink)
        if resolvedLink then
            RuntimeState.currentItemLink = resolvedLink
        end

        RuntimeState.mainFrame.itemText:SetText(RuntimeState.currentItemLink or itemName or "Selected item")
        RuntimeState.mainFrame.itemIcon:SetTexture(texture or "Interface\\Icons\\INV_Misc_QuestionMark")
        if canControl then
            RuntimeState.mainFrame.itemHint:SetText(GetTopRollsLabel() .. "  •  Shift+RClick to change")
        else
            RuntimeState.mainFrame.itemHint:SetText(GetTopRollsLabel() .. "  •  Master Looter item")
        end
        SetButtonEnabled(RuntimeState.mainFrame.startRollButton, canControl)
    else
        RuntimeState.mainFrame.itemText:SetText("|cffaaaaaaNo active roll item|r")
        RuntimeState.mainFrame.itemIcon:SetTexture("Interface\\Icons\\INV_Misc_QuestionMark")
        if canControl then
            RuntimeState.mainFrame.itemHint:SetText("Drag here or Shift + Right-click an item in your bags")
        else
            RuntimeState.mainFrame.itemHint:SetText("Waiting for the Master Looter to start a roll")
        end
        SetButtonEnabled(RuntimeState.mainFrame.startRollButton, false)
    end
end

local function SetCurrentItem(itemLink, itemID)
    local link = itemLink

    if (not link or link == "") and itemID and GetItemInfo then
        local _, resolvedLink = GetItemInfo(itemID)
        link = resolvedLink
    end

    if not link or link == "" then
        Print("could not read that item from the cursor.")
        return false
    end

    RuntimeState.currentItemLink = link
    RuntimeState.currentItemID = itemID
    if not CanControlRolls or CanControlRolls() then
        RuntimeState.currentTopRolls = DemiseRaidRolls.TradeableItems.Count(RuntimeState.currentItemLink, RuntimeState.currentItemID)
    elseif not RuntimeState.currentTopRolls or RuntimeState.currentTopRolls < 1 then
        RuntimeState.currentTopRolls = 1
    end
    UpdateItemDisplay()
    return true
end

DemiseRaidRolls.SetRollItem = function(itemLink, itemID)
    if CanControlRolls and not CanControlRolls() then
        Print("only the current Master Looter can choose the roll item.")
        return false
    end
    if SetCurrentItem(itemLink, itemID) then
        Print("selected " .. tostring(itemLink or itemID) .. " for the next roll.")
        return true
    end
    return false
end

local function ClearCurrentItem()
    RuntimeState.currentItemLink = nil
    RuntimeState.currentItemID = nil
    RuntimeState.currentTopRolls = 1
    UpdateItemDisplay()
end

local function CaptureCursorItem()
    if CanControlRolls and not CanControlRolls() then
        Print("only the current Master Looter can choose the roll item.")
        return false
    end

    if not GetCursorInfo then
        Print("GetCursorInfo is unavailable on this client.")
        return false
    end

    local cursorType, data1, data2 = GetCursorInfo()
    if cursorType ~= "item" then
        return false
    end

    local itemLink = nil
    if type(data2) == "string" and data2 ~= "" then
        itemLink = data2
    elseif data1 and GetItemInfo then
        local _, resolvedLink = GetItemInfo(data1)
        itemLink = resolvedLink
    end

    if SetCurrentItem(itemLink, data1) then
        if ClearCursor then
            ClearCursor()
        end
        return true
    end

    return false
end

-- Shift + Right-click shortcut for bag items.
-- IMPORTANT: never replace Blizzard/Ascension ContainerFrame global handlers here.
-- Replacing secure/shared click handlers can taint the UI and later cause unrelated
-- "blocked from calling a protected function" errors in other addons.
-- We therefore use hooksecurefunc only. This observes the click after the stock
-- handler without modifying the secure execution path.
local bagItemShortcutInstalled = false
local lastBagShortcutKey = nil
local lastBagShortcutTime = 0

local function GetBagItemFromButton(buttonFrame)
    if not buttonFrame or not buttonFrame.GetID then
        return nil, nil, nil, nil
    end

    local parent = buttonFrame.GetParent and buttonFrame:GetParent() or nil
    local bag = parent and parent.GetID and parent:GetID() or nil
    local slot = buttonFrame:GetID()
    if bag == nil or slot == nil then
        return nil, nil, nil, nil
    end

    local itemLink = nil
    if GetContainerItemLink then
        itemLink = GetContainerItemLink(bag, slot)
    end

    -- Some 3.3.5-derived clients also return the item link as the seventh
    -- value of GetContainerItemInfo. Use it only as a compatibility fallback.
    if (not itemLink or itemLink == "") and GetContainerItemInfo then
        local _, _, _, _, _, _, infoLink = GetContainerItemInfo(bag, slot)
        itemLink = infoLink
    end

    local itemID = nil
    if type(itemLink) == "string" then
        itemID = tonumber(itemLink:match("item:(%d+)"))
    end

    return itemLink, itemID, bag, slot
end

local function HandleBagItemShortcut(buttonFrame, mouseButton)
    if mouseButton ~= "RightButton" then
        return false
    end

    if DemiseRaidRollsMenu and DemiseRaidRollsMenu.GetActiveModule
        and DemiseRaidRollsMenu.GetActiveModule() ~= "rolls" then
        return false
    end

    if not IsShiftKeyDown or not IsShiftKeyDown() then
        return false
    end

    -- Viewer clients cannot choose the item for a hosted roll session.
    if CanControlRolls and not CanControlRolls() then
        return false
    end

    local itemLink, itemID, bag, slot = GetBagItemFromButton(buttonFrame)
    if not itemLink or itemLink == "" then
        return false
    end

    -- Ascension/custom bag XML can route a modified click through more than one
    -- handler. Avoid selecting/printing the same item twice for a single click.
    local now = (GetTime and GetTime()) or 0
    local shortcutKey = tostring(bag) .. ":" .. tostring(slot)
    if lastBagShortcutKey == shortcutKey and (now - lastBagShortcutTime) < 0.10 then
        return true
    end
    lastBagShortcutKey = shortcutKey
    lastBagShortcutTime = now

    if SetCurrentItem(itemLink, itemID) then
        Print("roll item selected: " .. tostring(itemLink))
        return true
    end

    return false
end

local function InstallBagItemShortcut()
    if bagItemShortcutInstalled then
        return true
    end

    -- hooksecurefunc is intentionally mandatory here. Falling back to replacing
    -- ContainerFrameItemButton_OnClick would reintroduce UI taint.
    if type(hooksecurefunc) ~= "function" then
        Print("Shift + Right-click bag shortcut disabled: secure hook API unavailable.")
        return false
    end

    local installedAny = false

    if type(ContainerFrameItemButton_OnModifiedClick) == "function" then
        hooksecurefunc("ContainerFrameItemButton_OnModifiedClick", function(self, button, ...)
            HandleBagItemShortcut(self, button)
        end)
        installedAny = true
    end

    -- Ascension/custom-UI compatibility fallback. This is still a secure post-hook;
    -- the original global function is never replaced.
    if type(ContainerFrameItemButton_OnClick) == "function" then
        hooksecurefunc("ContainerFrameItemButton_OnClick", function(self, button, ...)
            HandleBagItemShortcut(self, button)
        end)
        installedAny = true
    end

    if not installedAny then
        Print("Shift + Right-click bag shortcut is unavailable on this client.")
        return false
    end

    bagItemShortcutInstalled = true
    return true
end

local function SetTimerVisual(remainingFloat)
    if not RuntimeState.mainFrame or not RuntimeState.mainFrame.timerBar then
        return
    end

    local remaining = math.max(0, remainingFloat or 0)
    RuntimeState.mainFrame.timerBar:SetMinMaxValues(0, math.max(1, RuntimeState.activeDuration))
    RuntimeState.mainFrame.timerBar:SetValue(remaining)

    if remaining <= 5 then
        RuntimeState.mainFrame.timerBar:SetStatusBarColor(0.85, 0.12, 0.12)
    elseif remaining <= 10 then
        RuntimeState.mainFrame.timerBar:SetStatusBarColor(0.95, 0.65, 0.10)
    else
        RuntimeState.mainFrame.timerBar:SetStatusBarColor(0.20, 0.75, 0.25)
    end
end

BroadcastSessionEnd = function()
    if not syncSessionID then
        return false
    end
    return SendSyncRaw("END\t" .. tostring(syncSessionID), "RAID")
end

local function BroadcastSessionReset()
    if not syncSessionID then
        return false
    end
    return SendSyncRaw("RESET\t" .. tostring(syncSessionID), "RAID")
end

local function CancelRollSession()
    RuntimeState.rollTimerActive = false
    RuntimeState.rollSessionStarted = false
    RuntimeState.rollSessionOpen = true
    RuntimeState.rollStartTime = 0
    RuntimeState.rollEndTime = 0
    RuntimeState.timerAlerted = {}
    RuntimeState.timerAccumulator = 0
    RuntimeState.tieBreakActive = false
    RuntimeState.tieBreakType = nil
    RuntimeState.tieBreakPlayers = {}
    RuntimeState.tieBreakRoundRolls = {}
    RuntimeState.tieBreakRound = 0

    if RuntimeState.mainFrame then
        RuntimeState.mainFrame.timerText:SetText("Timer ready")
        RuntimeState.mainFrame.timerBar:SetMinMaxValues(0, 1)
        RuntimeState.mainFrame.timerBar:SetValue(0)
        RuntimeState.mainFrame.timerBar:SetStatusBarColor(0.20, 0.75, 0.25)
        RuntimeState.mainFrame.startRollButton:SetText("Start Rolls")
    end
end

local function GetTieBreakPlayerNames()
    local names = {}
    local playerKey
    for playerKey in pairs(RuntimeState.tieBreakPlayers) do
        local entry = FindValidEntry(playerKey, RuntimeState.tieBreakType)
        if entry then
            names[#names + 1] = entry.name
        end
    end
    table.sort(names)
    return names
end

local function ApplyTieBreakStart(sessionID, round, rollType, remaining, duration, playerList)
    if syncSessionID and tostring(sessionID) ~= tostring(syncSessionID) then
        return false
    end

    RuntimeState.tieBreakActive = true
    -- A pre-tie selection is not a winner. Require an explicit selection after
    -- the tie-break so Trade can never target the player originally clicked.
    RuntimeState.selectedRoll = nil
    RuntimeState.tieBreakType = rollType == "OS" and "OS" or "MS"
    RuntimeState.tieBreakRound = tonumber(round) or (RuntimeState.tieBreakRound + 1)
    RuntimeState.tieBreakPlayers = {}
    RuntimeState.tieBreakRoundRolls = {}

    local name
    for name in string.gmatch(tostring(playerList or ""), "[^,]+") do
        local key = NormalizeName(name)
        if key then
            RuntimeState.tieBreakPlayers[key] = true
        end
    end

    RuntimeState.activeDuration = tonumber(duration) or DEFAULT_ROLL_DURATION
    local remainingValue = tonumber(remaining) or RuntimeState.activeDuration
    local now = GetTime and GetTime() or 0

    RuntimeState.rollSessionStarted = true
    RuntimeState.rollSessionOpen = remainingValue > 0
    RuntimeState.rollTimerActive = remainingValue > 0
    RuntimeState.rollStartTime = now
    RuntimeState.rollEndTime = now + math.max(0, remainingValue)
    RuntimeState.timerAlerted = {}
    RuntimeState.timerAccumulator = 0

    if RuntimeState.mainFrame then
        if RuntimeState.rollTimerActive then
            RuntimeState.mainFrame.timerText:SetText("Tie-break closes in: " .. math.ceil(remainingValue) .. "s")
        else
            RuntimeState.mainFrame.timerText:SetText("TIE-BREAK CLOSED")
        end
        RuntimeState.mainFrame:Show()
    end
    SetTimerVisual(remainingValue)
    UpdateUI()
    return true
end

local function StartTieBreak()
    if not CanControlRolls or not CanControlRolls() then
        Print("only the current Master Looter can start a tie-break.")
        return false
    end

    if RuntimeState.rollTimerActive then
        Print("wait for the current timer to finish before starting a tie-break.")
        return false
    end

    RefreshDuplicateFlags()
    if not RuntimeState.selectedRoll or not RuntimeState.selectedRoll.isFirst or not RuntimeState.selectedRoll.isTied then
        Print("select a valid roll marked TIE first.")
        return false
    end

    local group = GetTieGroupForEntry(RuntimeState.selectedRoll)
    if #group < 2 then
        Print("that roll is no longer tied.")
        UpdateUI()
        return false
    end

    local tieBreakType = RuntimeState.selectedRoll.type
    RuntimeState.tieBreakActive = true
    RuntimeState.tieBreakType = tieBreakType
    -- The row selected to create the tie-break must not remain tradeable once
    -- the tie-break starts. The ML will select the final winner manually.
    RuntimeState.selectedRoll = nil
    RuntimeState.tieBreakRound = RuntimeState.tieBreakRound + 1
    RuntimeState.tieBreakPlayers = {}
    RuntimeState.tieBreakRoundRolls = {}

    local names = {}
    local i
    for i = 1, #group do
        RuntimeState.tieBreakPlayers[group[i].playerKey] = true
        names[#names + 1] = group[i].name
    end

    RuntimeState.activeDuration = GetConfiguredDuration()
    RuntimeState.rollSessionStarted = true
    RuntimeState.rollSessionOpen = true
    RuntimeState.rollTimerActive = true
    RuntimeState.timerAlerted = {}
    RuntimeState.timerAccumulator = 0
    RuntimeState.rollStartTime = GetTime and GetTime() or 0
    RuntimeState.rollEndTime = RuntimeState.rollStartTime + RuntimeState.activeDuration

    local maximum = RuntimeState.tieBreakType == "OS" and 99 or 100
    local message = "TIE - " .. table.concat(names, " / ") .. " - " .. RuntimeState.tieBreakType .. ": /roll " .. tostring(maximum) .. " - " .. tostring(RuntimeState.activeDuration) .. " sec"
    SendRaidAnnouncement(message, true)
    ShowLocalTimerAlert("TIE-BREAK - " .. tostring(RuntimeState.activeDuration) .. "s")

    if RuntimeState.mainFrame then
        RuntimeState.mainFrame.timerText:SetText("Tie-break closes in: " .. RuntimeState.activeDuration .. "s")
        RuntimeState.mainFrame:Show()
    end
    SetTimerVisual(RuntimeState.activeDuration)

    if IsInRaid() and syncSessionID then
        SendSyncRaw(table.concat({
            "TIESTART",
            tostring(syncSessionID),
            tostring(RuntimeState.tieBreakRound),
            tostring(RuntimeState.tieBreakType),
            tostring(RuntimeState.activeDuration),
            table.concat(names, ","),
        }, "\t"), "RAID")
    end

    UpdateUI()
    return true
end

FinishTieBreak = function()
    if not RuntimeState.tieBreakActive then
        return false
    end

    local isController = CanControlRolls and CanControlRolls() or false
    local finishedRound = RuntimeState.tieBreakRound

    RuntimeState.rollTimerActive = false
    RuntimeState.rollSessionOpen = false
    RuntimeState.rollStartTime = 0
    RuntimeState.rollEndTime = 0
    RuntimeState.tieBreakActive = false
    RuntimeState.selectedRoll = nil
    SetTimerVisual(0)

    if RuntimeState.mainFrame then
        RuntimeState.mainFrame.timerText:SetText("TIE-BREAK CLOSED")
    end

    ShowLocalTimerAlert("TIE-BREAK CLOSED")

    if isController then
        SendRaidAnnouncement("Tie-break closed", true)
        if IsInRaid() and syncSessionID then
            SendSyncRaw("TIEEND\t" .. tostring(syncSessionID) .. "\t" .. tostring(finishedRound), "RAID")
        end
    end

    RuntimeState.tieBreakPlayers = {}
    RuntimeState.tieBreakRoundRolls = {}
    UpdateUI()
    return true
end

local function FinishTimedRoll()
    if not RuntimeState.rollTimerActive then
        return
    end

    if RuntimeState.tieBreakActive then
        FinishTieBreak()
        return
    end

    local isController = CanControlRolls and CanControlRolls() or false

    RuntimeState.rollTimerActive = false
    RuntimeState.rollSessionOpen = false
    SetTimerVisual(0)

    if RuntimeState.mainFrame then
        RuntimeState.mainFrame.timerText:SetText("ROLL CLOSED")
        RuntimeState.mainFrame.startRollButton:SetText("Start Rolls")
    end

    ShowLocalTimerAlert("ROLL CLOSED")

    -- Only the Master Looter is allowed to publish raid announcements.
    -- Viewer clients still run the local visual countdown, but never speak.
    if isController then
        if RuntimeState.currentItemLink then
            SendRaidAnnouncement("Rolls closed - " .. RuntimeState.currentItemLink, true)
        else
            SendRaidAnnouncement("Rolls closed", true)
        end
        if BroadcastSessionEnd then
            BroadcastSessionEnd()
        end
    end

    if UpdateControlState then
        UpdateControlState()
    end
end

local function HandleTimerAlert(seconds)
    if RuntimeState.timerAlerted[seconds] then
        return
    end

    RuntimeState.timerAlerted[seconds] = true

    if seconds <= 5 then
        ShowLocalTimerAlert(tostring(seconds))
    elseif seconds == 10 then
        ShowLocalTimerAlert("10 seconds remaining")
    end

    -- The authoritative host publishes a clean raid-warning countdown for
    -- every one of the final five seconds. Do not repeat the item link here;
    -- everyone already knows which item the active session is for.
    if seconds <= 5 and CanControlRolls and CanControlRolls() then
        SendRaidAnnouncement(tostring(seconds), true)
    end
end

local function UpdateRollTimer()
    if not RuntimeState.rollTimerActive then
        return
    end

    local now = GetTime and GetTime() or 0
    local remainingFloat = RuntimeState.rollEndTime - now

    if remainingFloat <= 0 then
        FinishTimedRoll()
        return
    end

    local remaining = math.ceil(remainingFloat)

    if RuntimeState.mainFrame then
        RuntimeState.mainFrame.timerText:SetText((RuntimeState.tieBreakActive and "Tie-break closes in: " or "Roll closes in: ") .. remaining .. "s")
    end
    SetTimerVisual(remainingFloat)

    local thresholds = { 10, 5, 4, 3, 2, 1 }
    local i
    for i = 1, #thresholds do
        local threshold = thresholds[i]
        if threshold <= RuntimeState.activeDuration and remaining <= threshold then
            HandleTimerAlert(threshold)
        end
    end
end

local function StartTimedRoll()
    if not CanControlRolls or not CanControlRolls() then
        local actualMaster = GetActualMasterLooterName and GetActualMasterLooterName() or nil
        if actualMaster then
            Print("only the current Master Looter (" .. tostring(actualMaster) .. ") can start a roll.")
        else
            Print("only the current Master Looter can start a roll.")
        end
        return
    end

    if not RuntimeState.currentItemLink then
        Print("drop an item into the item slot first.")
        return
    end

    local hardReserve = DemiseRaidRollsSoftRes.GetCurrentHardReserve()
    if hardReserve then
        local ownerText = type(hardReserve) == "string" and hardReserve ~= "" and (" for " .. hardReserve) or ""
        Print("this item is Hard Reserved" .. ownerText .. "; no roll was started.")
        if UIErrorsFrame and UIErrorsFrame.AddMessage then
            UIErrorsFrame:AddMessage("HARD RESERVED" .. ownerText, 1.0, 0.25, 0.25, 1.0)
        end
        return
    end

    local raidCount = GetNumRaidMembers and GetNumRaidMembers() or 0
    local inRaid = raidCount > 0

    RuntimeState.activeDuration = GetConfiguredDuration()
    RuntimeState.currentTopRolls = DemiseRaidRolls.TradeableItems.Count(RuntimeState.currentItemLink, RuntimeState.currentItemID)
    UpdateItemDisplay()

    local startMessage
    local priorityLabel = DemiseRaidRollsSoftRes.IsPriorityEnabled() and "SR > MS > OS - " or ""
    if (tonumber(RuntimeState.currentTopRolls) or 1) > 1 then
        startMessage = "Top " .. tostring(RuntimeState.currentTopRolls) .. " Rolls " .. RuntimeState.currentItemLink .. " - " .. priorityLabel .. "MS: /roll 100 - OS: /roll 99 - " .. RuntimeState.activeDuration .. " sec"
    else
        startMessage = "Roll " .. RuntimeState.currentItemLink .. " - " .. priorityLabel .. "MS: /roll 100 - OS: /roll 99 - " .. RuntimeState.activeDuration .. " sec"
    end
    if not SendRaidAnnouncement(startMessage, true) then
        return
    end

    ClearRolls()
    RuntimeState.awardedPlayersForRoll = {}
    RuntimeState.currentRollAwardOrder = {}
    RuntimeState.rollSessionStarted = true
    RuntimeState.rollSessionOpen = true
    RuntimeState.rollTimerActive = true
    RuntimeState.timerAlerted = {}
    RuntimeState.timerAccumulator = 0
    RuntimeState.rollStartTime = GetTime and GetTime() or 0
    RuntimeState.rollEndTime = RuntimeState.rollStartTime + RuntimeState.activeDuration
    if inRaid then
        syncSessionID = GenerateSessionID()
    else
        syncSessionID = nil
    end
    syncOwner = UnitName("player")

    if RuntimeState.mainFrame then
        RuntimeState.mainFrame.startRollButton:SetText("Stop Rolls")
        RuntimeState.mainFrame.timerText:SetText("Roll closes in: " .. RuntimeState.activeDuration .. "s")
        RuntimeState.mainFrame:Show()
    end
    SetTimerVisual(RuntimeState.activeDuration)
    ShowLocalTimerAlert("ROLL STARTED - " .. RuntimeState.activeDuration .. "s")

    if inRaid then
        local syncMessage = table.concat({
            "START",
            tostring(syncSessionID),
            tostring(RuntimeState.activeDuration),
            tostring(RuntimeState.currentItemID or 0),
            tostring(RuntimeState.currentItemLink or ""),
        }, "\t")

        if not SendSyncRaw(syncMessage, "RAID") then
            Print("raid synchronization is unavailable on this client; other addon users will not receive the shared timer.")
        else
            SendSyncRaw("TOP\t" .. tostring(syncSessionID) .. "\t" .. tostring(RuntimeState.currentTopRolls or 1), "RAID")
            DemiseRaidRollsSoftRes.BroadcastCurrentState("RAID")
            BroadcastLootHistory("RAID")
        end
    end

    if UpdateControlState then
        UpdateControlState()
    end
end

local function AnnounceWinner()
    if not CanControlRolls or not CanControlRolls() then
        Print("only the current Master Looter can announce a winner.")
        return
    end

    if not RuntimeState.selectedRoll then
        Print("click a roll first to select the winner.")
        return
    end

    if not RuntimeState.currentItemLink then
        Print("no item is currently selected.")
        return
    end

    local message = RuntimeState.selectedRoll.name .. " has won " .. RuntimeState.currentItemLink
    SendRaidAnnouncement(message, true)
end

local function FindRaidUnit(name)
    local key = NormalizeName(name)
    if not key then
        return nil
    end

    local playerName = UnitName("player")
    if NormalizeName(playerName) == key then
        return "player"
    end

    local count = GetNumRaidMembers and GetNumRaidMembers() or 0
    local i
    for i = 1, count do
        local rosterName = GetRaidRosterInfo(i)
        if NormalizeName(rosterName) == key then
            return "raid" .. i
        end
    end

    -- Outside raids, allow Trade testing/use with normal party members too.
    for i = 1, 4 do
        local partyName = UnitName and UnitName("party" .. i) or nil
        if NormalizeName(partyName) == key then
            return "party" .. i
        end
    end

    return nil
end

local function ExtractItemID(itemLink)
    if type(itemLink) ~= "string" then
        return nil
    end

    return tonumber(itemLink:match("item:(%d+)"))
end

local function FindItemInBags(itemLink, itemID)
    if not GetContainerNumSlots or not GetContainerItemLink then
        return nil, nil
    end

    local wantedID = tonumber(itemID) or ExtractItemID(itemLink)
    local bag
    for bag = 0, 4 do
        local slots = GetContainerNumSlots(bag) or 0
        local slot
        for slot = 1, slots do
            local bagLink = GetContainerItemLink(bag, slot)
            if bagLink then
                local matches = false
                if itemLink and bagLink == itemLink then
                    matches = true
                elseif wantedID and ExtractItemID(bagLink) == wantedID then
                    matches = true
                end

                if matches then
                    local locked = false
                    if GetContainerItemInfo then
                        local _, _, isLocked = GetContainerItemInfo(bag, slot)
                        locked = isLocked and true or false
                    end

                    if not locked then
                        return bag, slot
                    end
                end
            end
        end
    end

    return nil, nil
end

local function FindFreeTradeSlot()
    local slot
    for slot = 1, 6 do
        if not GetTradePlayerItemLink or not GetTradePlayerItemLink(slot) then
            return slot
        end
    end
    return nil
end

local function ClearPendingTradeItem()
    RuntimeState.pendingTradeItemLink = nil
    RuntimeState.pendingTradeItemID = nil
    RuntimeState.pendingTradePlayer = nil
    RuntimeState.pendingTradeRollType = nil
end

local function PlacePendingTradeItem()
    if not RuntimeState.pendingTradeItemLink then
        return
    end

    if not PickupContainerItem or not ClickTradeButton then
        Print("the client does not expose the bag/trade functions needed to auto-place the item.")
        ClearPendingTradeItem()
        return
    end

    local bag, slot = FindItemInBags(RuntimeState.pendingTradeItemLink, RuntimeState.pendingTradeItemID)
    if bag == nil or slot == nil then
        Print("could not find the selected item in your bags. Trade opened without auto-placing it.")
        ClearPendingTradeItem()
        return
    end

    local tradeSlot = FindFreeTradeSlot()
    if not tradeSlot then
        Print("no free item slot is available in the trade window.")
        ClearPendingTradeItem()
        return
    end

    if ClearCursor then
        ClearCursor()
    end

    DemiseRaidRolls.TradeAwards.Begin(
        RuntimeState.pendingTradePlayer,
        RuntimeState.pendingTradeRollType,
        RuntimeState.pendingTradeItemLink,
        RuntimeState.pendingTradeItemID
    )
    PickupContainerItem(bag, slot)
    ClickTradeButton(tradeSlot)

    if CursorHasItem and CursorHasItem() then
        if ClearCursor then
            ClearCursor()
        end
        DemiseRaidRolls.TradeAwards.CancelPreparation()
        Print("the item could not be placed automatically. You can still add it manually.")
    else
        DemiseRaidRolls.TradeAwards.MarkPlaced()
        Print("placed the selected item into the trade window for " .. tostring(RuntimeState.pendingTradePlayer or "the selected player") .. ".")
    end

    ClearPendingTradeItem()
end

local function TradeWinner()
    if not CanControlRolls or not CanControlRolls() then
        Print("only the current Master Looter can announce and trade the winner.")
        return
    end

    if not RuntimeState.selectedRoll then
        Print("click a roll first to select the player to trade with.")
        return
    end

    if not RuntimeState.currentItemLink then
        Print("no item is currently selected. Drop the item into the addon before using Trade.")
        return
    end

    local unit = FindRaidUnit(RuntimeState.selectedRoll.name)
    if not unit then
        RefreshRaidMembers()
        unit = FindRaidUnit(RuntimeState.selectedRoll.name)
    end

    if not unit then
        Print("could not find " .. RuntimeState.selectedRoll.name .. " in your current raid/party.")
        return
    end

    -- The winner announcement is optional. Muting it never changes winner
    -- tracking or the trade flow; it only suppresses the chat/RW message.
    if not AscensionRaidRollsDB.muteWinnerAnnouncement then
        SendRaidAnnouncement(RuntimeState.selectedRoll.name .. " has won " .. RuntimeState.currentItemLink, true)
    end

    if unit == "player" then
        if RecordLootWin(RuntimeState.selectedRoll.name, RuntimeState.selectedRoll.type) then
            Print(RuntimeState.selectedRoll.name .. " is now " .. tostring(RuntimeState.selectedRoll.type) .. " +" .. tostring(GetLootWinCount(RuntimeState.selectedRoll.name, RuntimeState.selectedRoll.type)) .. " for this loot history.")
            UpdateUI()
        end
        Print("winner announced. The selected player is you, so no trade was opened.")
        return
    end

    if not InitiateTrade then
        Print("winner announced, but InitiateTrade is unavailable on this client.")
        return
    end

    -- TRADE_SHOW fires only once the trade window really exists.  Store the
    -- item now and deposit it when that event arrives, otherwise the client
    -- can receive ClickTradeButton before there is a valid trade slot.
    RuntimeState.pendingTradeItemLink = RuntimeState.currentItemLink
    RuntimeState.pendingTradeItemID = RuntimeState.currentItemID or ExtractItemID(RuntimeState.currentItemLink)
    RuntimeState.pendingTradePlayer = RuntimeState.selectedRoll.name
    RuntimeState.pendingTradeRollType = RuntimeState.selectedRoll.type

    InitiateTrade(unit)
end

-- Automatic Master Loot -----------------------------------------------------------
-- Opt-in: when enabled, each master-loot eligible item in the open loot window
-- is assigned to the configured recipient (@ME or a player name).
local function NormalizeMasterLooterSetting(value)
    value = Trim(value or "") or ""
    if value == "" or string.upper(value) == "@ME" then
        return "@ME"
    end

    -- Also accept the visual notation [PlayerName].
    value = value:gsub("^%[", ""):gsub("%]$", "")
    value = Trim(value) or ""
    if value == "" then
        return "@ME"
    end
    return value
end

local function SaveMasterLooterSetting()
    local value = (AscensionRaidRollsDB and AscensionRaidRollsDB.masterLooter) or "@ME"
    if RuntimeState.mainFrame and RuntimeState.mainFrame.masterLooterEdit then
        value = RuntimeState.mainFrame.masterLooterEdit:GetText()
    end

    value = NormalizeMasterLooterSetting(value)
    AscensionRaidRollsDB.masterLooter = value
    if RuntimeState.mainFrame and RuntimeState.mainFrame.masterLooterEdit then
        RuntimeState.mainFrame.masterLooterEdit:SetText(value)
    end
    return value
end

local function ResolveMasterLooterTarget()
    local setting = SaveMasterLooterSetting()
    if string.upper(setting) == "@ME" then
        return UnitName("player") or "player"
    end
    return setting
end

local function SetAutoMasterLootEnabled(enabled, quiet)
    AscensionRaidRollsDB.autoMasterLoot = enabled and true or false
    if RuntimeState.mainFrame and RuntimeState.mainFrame.autoLootCheck then
        RuntimeState.mainFrame.autoLootCheck:SetChecked(AscensionRaidRollsDB.autoMasterLoot)
    end

    if not AscensionRaidRollsDB.autoMasterLoot then
        RuntimeState.autoMasterLootProcessing = false
        RuntimeState.autoMasterLootWaiting = false
        RuntimeState.autoMasterLootTarget = nil
    end

    if not quiet then
        if AscensionRaidRollsDB.autoMasterLoot then
            Print("automatic Master Loot enabled -> " .. tostring(ResolveMasterLooterTarget()) .. ".")
        else
            Print("automatic Master Loot disabled.")
        end
    end
end

GetActualMasterLooterName = function()
    if not GetLootMethod then
        return nil, nil
    end

    local method, partyIndex, raidIndex = GetLootMethod()
    if method ~= "master" then
        return nil, method
    end

    if raidIndex and raidIndex > 0 and GetRaidRosterInfo then
        return GetRaidRosterInfo(raidIndex), method
    end

    if partyIndex ~= nil then
        if partyIndex == 0 then
            return UnitName("player"), method
        elseif partyIndex > 0 then
            return UnitName("party" .. partyIndex), method
        end
    end

    if raidIndex == 0 then
        return UnitName("player"), method
    end

    return nil, method
end

CanControlRolls = function()
    -- ML / Viewer permissions only apply in raids. Outside a raid ARR runs in
    -- Standalone Mode with full controls, which is useful for setup and tests.
    if not IsInRaid() then
        return true
    end

    if not GetActualMasterLooterName then
        return false
    end

    local actualMaster, method = GetActualMasterLooterName()
    if method ~= "master" or not actualMaster then
        return false
    end

    return IsSamePlayerName(actualMaster, UnitName("player"))
end

DemiseRaidRolls.SetAutoMasterLootEnabled = SetAutoMasterLootEnabled

DemiseRaidRolls.CanControlRolls = function()
    return CanControlRolls and CanControlRolls() or false
end

function DemiseRaidRolls.UpdateViewerRollSummary()
    if not RuntimeState.mainFrame or not RuntimeState.mainFrame.viewerRollText then
        return
    end

    local playerKey = NormalizeName(UnitName("player"))
    local matchingEntry
    local matchingRank
    local matchingTotal = GetValidCount(RuntimeState.rollsMS) + GetValidCount(RuntimeState.rollsOS)
    -- The MS list is already ordered with SoftRes entries first. Walking MS
    -- before OS therefore gives the minimized viewer the effective SR > MS > OS
    -- rank instead of a misleading rank that resets inside each roll category.
    local lists = { RuntimeState.rollsMS, RuntimeState.rollsOS }
    local validRank = 0
    local listIndex
    for listIndex = 1, #lists do
        local list = lists[listIndex]
        local i
        for i = 1, #list do
            local entry = list[i]
            if entry.isFirst then
                validRank = validRank + 1
                if not matchingEntry and entry.playerKey == playerKey then
                    matchingEntry = entry
                    matchingRank = validRank
                end
            end
        end
    end

    if matchingEntry then
        local reserveText = matchingEntry.isSoftReserved and ("  •  " .. tostring(matchingEntry.softReserveIndex or 1) .. "xSR") or ""
        RuntimeState.mainFrame.viewerRollText:SetText(
            "Your roll: |cffffd24a" .. tostring(matchingEntry.roll) .. " " .. tostring(matchingEntry.type) .. "|r" ..
            reserveText .. "  •  Rank |cffffffff" .. tostring(matchingRank) .. "/" .. tostring(matchingTotal) .. "|r"
        )
        return
    end

    for listIndex = 1, #lists do
        local list = lists[listIndex]
        local i
        for i = 1, #list do
            local entry = list[i]
            if entry.playerKey == playerKey then
                RuntimeState.mainFrame.viewerRollText:SetText(
                    "Your roll: |cffaaaaaa" .. tostring(entry.roll) .. " " .. tostring(entry.type) .. "|r  •  |cffff6666REROLL|r"
                )
                return
            end
        end
    end

    RuntimeState.mainFrame.viewerRollText:SetText("Your roll: |cffaaaaaawaiting for your roll|r")
end

function DemiseRaidRolls.SetFrameVisible(frame, visible)
    if not frame then
        return
    end
    if visible then
        frame:Show()
    else
        frame:Hide()
    end
end

function DemiseRaidRolls.ApplyMainWindowRoleLayout(canControl, remoteSyncedSession)
    if not RuntimeState.mainFrame or not RuntimeState.mainFrame.minimizeButton then
        return
    end

    local viewerMode = IsInRaid() and not canControl
    local minimized = viewerMode and AscensionRaidRollsDB.viewerMinimized == true

    DemiseRaidRolls.SetFrameVisible(RuntimeState.mainFrame.startRollButton, not viewerMode)
    DemiseRaidRolls.SetFrameVisible(RuntimeState.mainFrame.durationLabel, not viewerMode)
    DemiseRaidRolls.SetFrameVisible(RuntimeState.mainFrame.durationEdit, not viewerMode)
    DemiseRaidRolls.SetFrameVisible(RuntimeState.mainFrame.durationSec, not viewerMode)
    DemiseRaidRolls.SetFrameVisible(RuntimeState.mainFrame.tieButton, not viewerMode)
    DemiseRaidRolls.SetFrameVisible(RuntimeState.mainFrame.optionsButton, not viewerMode)
    DemiseRaidRolls.SetFrameVisible(RuntimeState.mainFrame.timersButton, not viewerMode)
    DemiseRaidRolls.SetFrameVisible(RuntimeState.mainFrame.tradeButton, not viewerMode)
    DemiseRaidRolls.SetFrameVisible(RuntimeState.mainFrame.minimizeButton, viewerMode)

    if not viewerMode then
        RuntimeState.mainFrame:SetWidth(600)
        RuntimeState.mainFrame:SetHeight(565)
        RuntimeState.mainFrame.title:ClearAllPoints()
        RuntimeState.mainFrame.title:SetPoint("TOP", RuntimeState.mainFrame, "TOP", 0, -17)
        RuntimeState.mainFrame.itemSlot:ClearAllPoints()
        RuntimeState.mainFrame.itemSlot:SetPoint("TOPLEFT", RuntimeState.mainFrame, "TOPLEFT", 24, -57)
        RuntimeState.mainFrame.itemText:SetWidth(245)
        RuntimeState.mainFrame.itemHint:Show()
        RuntimeState.mainFrame.subtitle:Show()
        RuntimeState.mainFrame.timerBar:ClearAllPoints()
        RuntimeState.mainFrame.timerBar:SetWidth(365)
        RuntimeState.mainFrame.timerBar:SetPoint("TOPLEFT", RuntimeState.mainFrame, "TOPLEFT", 24, -106)
        RuntimeState.mainFrame.msCount:Show()
        RuntimeState.mainFrame.osCount:Show()
        RuntimeState.msPanel:Show()
        RuntimeState.osPanel:Show()
        RuntimeState.mainFrame.separator:Show()
        RuntimeState.mainFrame.winnerText:Show()
        RuntimeState.mainFrame.viewerRollText:Hide()
        RuntimeState.mainFrame.clearButton:Show()
        RuntimeState.mainFrame.msRollButton:Show()
        RuntimeState.mainFrame.osRollButton:Show()
        RuntimeState.mainFrame.tradeButton:Show()
        RuntimeState.mainFrame.clearButton:ClearAllPoints()
        RuntimeState.mainFrame.clearButton:SetPoint("BOTTOMLEFT", RuntimeState.mainFrame, "BOTTOMLEFT", 18, 18)
        RuntimeState.mainFrame.msRollButton:ClearAllPoints()
        RuntimeState.mainFrame.msRollButton:SetPoint("LEFT", RuntimeState.mainFrame.clearButton, "RIGHT", 6, 0)
        RuntimeState.mainFrame.osRollButton:ClearAllPoints()
        RuntimeState.mainFrame.osRollButton:SetPoint("LEFT", RuntimeState.mainFrame.msRollButton, "RIGHT", 6, 0)
        RuntimeState.mainFrame.tradeButton:ClearAllPoints()
        RuntimeState.mainFrame.tradeButton:SetPoint("LEFT", RuntimeState.mainFrame.osRollButton, "RIGHT", 6, 0)
        return
    end

    RuntimeState.mainFrame.minimizeButton:SetText(minimized and "Maximize" or "Minimize")
    RuntimeState.mainFrame.msRollButton:Show()
    RuntimeState.mainFrame.osRollButton:Show()

    if minimized then
        RuntimeState.mainFrame:SetWidth(430)
        RuntimeState.mainFrame:SetHeight(190)
        RuntimeState.mainFrame.title:ClearAllPoints()
        RuntimeState.mainFrame.title:SetPoint("TOP", RuntimeState.mainFrame, "TOP", -38, -17)
        RuntimeState.mainFrame.itemSlot:ClearAllPoints()
        RuntimeState.mainFrame.itemSlot:SetPoint("TOPLEFT", RuntimeState.mainFrame, "TOPLEFT", 20, -48)
        RuntimeState.mainFrame.itemText:SetWidth(335)
        RuntimeState.mainFrame.itemHint:Hide()
        RuntimeState.mainFrame.subtitle:Hide()
        RuntimeState.mainFrame.timerBar:ClearAllPoints()
        RuntimeState.mainFrame.timerBar:SetWidth(390)
        RuntimeState.mainFrame.timerBar:SetPoint("TOPLEFT", RuntimeState.mainFrame, "TOPLEFT", 20, -98)
        RuntimeState.mainFrame.msCount:Hide()
        RuntimeState.mainFrame.osCount:Hide()
        RuntimeState.msPanel:Hide()
        RuntimeState.osPanel:Hide()
        RuntimeState.mainFrame.separator:Hide()
        RuntimeState.mainFrame.winnerText:Hide()
        RuntimeState.mainFrame.viewerRollText:Show()
        RuntimeState.mainFrame.viewerRollText:ClearAllPoints()
        RuntimeState.mainFrame.viewerRollText:SetPoint("TOP", RuntimeState.mainFrame.timerBar, "BOTTOM", 0, -9)
        RuntimeState.mainFrame.clearButton:Hide()
        RuntimeState.mainFrame.msRollButton:ClearAllPoints()
        RuntimeState.mainFrame.msRollButton:SetPoint("BOTTOMLEFT", RuntimeState.mainFrame, "BOTTOMLEFT", 77, 16)
        RuntimeState.mainFrame.osRollButton:ClearAllPoints()
        RuntimeState.mainFrame.osRollButton:SetPoint("LEFT", RuntimeState.mainFrame.msRollButton, "RIGHT", 6, 0)
    else
        RuntimeState.mainFrame:SetWidth(600)
        RuntimeState.mainFrame:SetHeight(565)
        RuntimeState.mainFrame.title:ClearAllPoints()
        RuntimeState.mainFrame.title:SetPoint("TOP", RuntimeState.mainFrame, "TOP", 0, -17)
        RuntimeState.mainFrame.itemSlot:ClearAllPoints()
        RuntimeState.mainFrame.itemSlot:SetPoint("TOPLEFT", RuntimeState.mainFrame, "TOPLEFT", 24, -57)
        RuntimeState.mainFrame.itemText:SetWidth(480)
        RuntimeState.mainFrame.itemHint:Hide()
        RuntimeState.mainFrame.subtitle:Show()
        RuntimeState.mainFrame.timerBar:ClearAllPoints()
        RuntimeState.mainFrame.timerBar:SetWidth(552)
        RuntimeState.mainFrame.timerBar:SetPoint("TOPLEFT", RuntimeState.mainFrame, "TOPLEFT", 24, -106)
        RuntimeState.mainFrame.msCount:Show()
        RuntimeState.mainFrame.osCount:Show()
        RuntimeState.msPanel:Show()
        RuntimeState.osPanel:Show()
        RuntimeState.mainFrame.separator:Show()
        RuntimeState.mainFrame.winnerText:Show()
        RuntimeState.mainFrame.viewerRollText:Hide()

        if remoteSyncedSession then
            RuntimeState.mainFrame.clearButton:Hide()
            RuntimeState.mainFrame.msRollButton:ClearAllPoints()
            RuntimeState.mainFrame.msRollButton:SetPoint("BOTTOMLEFT", RuntimeState.mainFrame, "BOTTOMLEFT", 162, 18)
        else
            RuntimeState.mainFrame.clearButton:Show()
            RuntimeState.mainFrame.clearButton:ClearAllPoints()
            RuntimeState.mainFrame.clearButton:SetPoint("BOTTOMLEFT", RuntimeState.mainFrame, "BOTTOMLEFT", 91, 18)
            RuntimeState.mainFrame.msRollButton:ClearAllPoints()
            RuntimeState.mainFrame.msRollButton:SetPoint("LEFT", RuntimeState.mainFrame.clearButton, "RIGHT", 6, 0)
        end
        RuntimeState.mainFrame.osRollButton:ClearAllPoints()
        RuntimeState.mainFrame.osRollButton:SetPoint("LEFT", RuntimeState.mainFrame.msRollButton, "RIGHT", 6, 0)
    end
end

UpdateControlState = function()
    if not RuntimeState.mainFrame then
        return
    end

    if DemiseRaidRolls.RaidCouncil and DemiseRaidRolls.RaidCouncil.ApplyMainWindow and DemiseRaidRolls.RaidCouncil.ApplyMainWindow() then
        return
    end

    local actualMaster, method = GetActualMasterLooterName()
    local canControl = CanControlRolls()
    local inRaid = IsInRaid()

    local remoteSyncedSession = IsRemoteSyncedSession and IsRemoteSyncedSession() or false
    local controlledTimedSession = RuntimeState.rollSessionStarted and ((inRaid and syncSessionID ~= nil) or (not inRaid))

    DemiseRaidRolls.ApplyMainWindowRoleLayout(canControl, remoteSyncedSession)
    DemiseRaidRolls.UpdateViewerRollSummary()

    if not inRaid then
        RuntimeState.mainFrame.subtitle:SetText("Standalone mode  •  Full controls  •  First roll counts")
    elseif canControl then
        RuntimeState.mainFrame.subtitle:SetText("Master Looter mode  •  First roll counts")
    elseif remoteSyncedSession then
        RuntimeState.mainFrame.subtitle:SetText("Viewer mode  •  Master Looter: " .. tostring(actualMaster or syncOwner) .. "  •  First roll counts")
    elseif method == "master" and actualMaster then
        RuntimeState.mainFrame.subtitle:SetText("Local roll mode  •  Master Looter: " .. tostring(actualMaster) .. "  •  First roll counts")
    else
        RuntimeState.mainFrame.subtitle:SetText("Local roll mode  •  First roll counts")
    end

    SetButtonEnabled(RuntimeState.mainFrame.startRollButton, canControl and RuntimeState.currentItemLink ~= nil and not RuntimeState.tieBreakActive)
    if RuntimeState.mainFrame.tieButton then
        local canTieBreak = canControl and not RuntimeState.rollTimerActive and RuntimeState.selectedRoll ~= nil and RuntimeState.selectedRoll.isFirst and RuntimeState.selectedRoll.isTied
        SetButtonEnabled(RuntimeState.mainFrame.tieButton, canTieBreak)
    end

    -- The Master Looter can reset the shared session. A viewer can also reset
    -- their own local log when no addon-hosted shared session currently exists.
    SetButtonEnabled(RuntimeState.mainFrame.clearButton, canControl or not remoteSyncedSession)
    SetButtonEnabled(RuntimeState.mainFrame.tradeButton, canControl and RuntimeState.selectedRoll ~= nil and not RuntimeState.tieBreakActive)

    -- In fallback/local mode the MS/OS buttons stay usable even when the real
    -- Master Looter does not run ARR. Once an addon-hosted timed session exists,
    -- both host and viewers are bound by its open/closed state, so at 0 the
    -- buttons are disabled and late rolls remain rejected.
    local canPlayerRoll = true
    if controlledTimedSession then
        canPlayerRoll = RuntimeState.rollSessionOpen
    end
    if RuntimeState.tieBreakActive then
        local playerKey = NormalizeName(UnitName("player"))
        local eligible = playerKey and RuntimeState.tieBreakPlayers[playerKey] and RuntimeState.tieBreakRoundRolls[playerKey] == nil
        SetButtonEnabled(RuntimeState.mainFrame.msRollButton, canPlayerRoll and eligible and RuntimeState.tieBreakType == "MS")
        SetButtonEnabled(RuntimeState.mainFrame.osRollButton, canPlayerRoll and eligible and RuntimeState.tieBreakType == "OS")
    else
        SetButtonEnabled(RuntimeState.mainFrame.msRollButton, canPlayerRoll)
        SetButtonEnabled(RuntimeState.mainFrame.osRollButton, canPlayerRoll)
    end

    if RuntimeState.mainFrame.durationEdit then
        if RuntimeState.mainFrame.durationEdit.Enable and RuntimeState.mainFrame.durationEdit.Disable then
            if canControl then
                RuntimeState.mainFrame.durationEdit:Enable()
            else
                RuntimeState.mainFrame.durationEdit:Disable()
            end
        end
        RuntimeState.mainFrame.durationEdit:SetAlpha(canControl and 1.0 or 0.45)
    end

    if RuntimeState.mainFrame.masterLooterEdit then
        if RuntimeState.mainFrame.masterLooterEdit.Enable and RuntimeState.mainFrame.masterLooterEdit.Disable then
            if canControl then
                RuntimeState.mainFrame.masterLooterEdit:Enable()
            else
                RuntimeState.mainFrame.masterLooterEdit:Disable()
            end
        end
        RuntimeState.mainFrame.masterLooterEdit:SetAlpha(canControl and 1.0 or 0.45)
    end

    if RuntimeState.mainFrame.autoLootCheck then
        if canControl and RuntimeState.mainFrame.autoLootCheck.Enable then
            RuntimeState.mainFrame.autoLootCheck:Enable()
        elseif (not canControl) and RuntimeState.mainFrame.autoLootCheck.Disable then
            RuntimeState.mainFrame.autoLootCheck:Disable()
        end
        RuntimeState.mainFrame.autoLootCheck:SetAlpha(canControl and 1.0 or 0.45)
    end

    if RuntimeState.mainFrame.masterLooterLabel then
        RuntimeState.mainFrame.masterLooterLabel:SetAlpha(canControl and 1.0 or 0.55)
    end
    if UpdateOptionsControlState then
        UpdateOptionsControlState()
    end
end

local function ApplySyncedSession(sender, sessionID, isOpen, remaining, duration, itemID, itemLink, fromSnapshot)
    if not IsSenderCurrentMasterLooter(sender) then
        return false
    end

    syncStateRequested = false
    syncOwner = sender
    syncSessionID = sessionID
    syncReceivingState = fromSnapshot and true or false
    RuntimeState.selectedRoll = nil

    ClearRolls()
    RuntimeState.currentTopRolls = 1

    local parsedItemID = tonumber(itemID)
    if parsedItemID == 0 then
        parsedItemID = nil
    end

    if itemLink and itemLink ~= "" then
        SetCurrentItem(itemLink, parsedItemID)
    else
        RuntimeState.currentItemLink = nil
        RuntimeState.currentItemID = nil
        RuntimeState.currentTopRolls = 1
        UpdateItemDisplay()
    end

    RuntimeState.activeDuration = tonumber(duration) or DEFAULT_ROLL_DURATION
    if RuntimeState.activeDuration < MIN_ROLL_DURATION then
        RuntimeState.activeDuration = MIN_ROLL_DURATION
    elseif RuntimeState.activeDuration > MAX_ROLL_DURATION then
        RuntimeState.activeDuration = MAX_ROLL_DURATION
    end

    RuntimeState.rollSessionStarted = true
    RuntimeState.rollSessionOpen = isOpen and true or false
    RuntimeState.timerAlerted = {}
    RuntimeState.timerAccumulator = 0

    local now = GetTime and GetTime() or 0
    local remainingValue = tonumber(remaining) or 0

    if RuntimeState.rollSessionOpen and remainingValue > 0 then
        RuntimeState.rollTimerActive = true
        RuntimeState.rollStartTime = now
        RuntimeState.rollEndTime = now + remainingValue
        if RuntimeState.mainFrame then
            RuntimeState.mainFrame.timerText:SetText("Roll closes in: " .. math.ceil(remainingValue) .. "s")
            RuntimeState.mainFrame.startRollButton:SetText("Start Rolls")
        end
        SetTimerVisual(remainingValue)
    else
        RuntimeState.rollTimerActive = false
        RuntimeState.rollSessionOpen = false
        RuntimeState.rollStartTime = 0
        RuntimeState.rollEndTime = 0
        SetTimerVisual(0)
        if RuntimeState.mainFrame then
            RuntimeState.mainFrame.timerText:SetText("ROLL CLOSED")
            RuntimeState.mainFrame.startRollButton:SetText("Start Rolls")
        end
    end

    -- A passive state snapshot must never open the window. Only a currently
    -- active Master Looter roll is allowed to summon it for raid viewers.
    if RuntimeState.mainFrame and RuntimeState.rollSessionOpen and remainingValue > 0 then
        RuntimeState.mainFrame:Show()
    end

    UpdateUI()
    return true
end

local function CloseSyncedSession(sessionID)
    if not syncSessionID or tostring(sessionID) ~= tostring(syncSessionID) then
        return false
    end

    local wasActive = RuntimeState.rollTimerActive
    RuntimeState.rollTimerActive = false
    RuntimeState.rollSessionStarted = true
    RuntimeState.rollSessionOpen = false
    RuntimeState.rollStartTime = 0
    RuntimeState.rollEndTime = 0
    syncReceivingState = false
    SetTimerVisual(0)

    if RuntimeState.mainFrame then
        RuntimeState.mainFrame.timerText:SetText("ROLL CLOSED")
        RuntimeState.mainFrame.startRollButton:SetText("Start Rolls")
    end

    if wasActive then
        ShowLocalTimerAlert("ROLL CLOSED")
    end

    UpdateUI()
    return true
end

local function ResetSyncedSession(sessionID)
    if syncSessionID and sessionID and tostring(sessionID) ~= tostring(syncSessionID) then
        return false
    end

    ClearRolls()
    CancelRollSession()
    syncSessionID = nil
    syncReceivingState = false
    RuntimeState.selectedRoll = nil
    UpdateUI()
    return true
end

-- If the player leaves a raid while viewing another player's synchronized
-- session, discard that remote authority immediately. Standalone Mode should
-- never inherit a closed timer or viewer lock from the raid that was just left.
local function ClearRemoteRaidStateOutsideRaid()
    if IsInRaid() then
        return false
    end

    if DemiseRaidRolls.RaidCouncil and DemiseRaidRolls.RaidCouncil.ClearSyncedMode then
        DemiseRaidRolls.RaidCouncil.ClearSyncedMode()
    end

    if syncOwner and not IsSamePlayerName(syncOwner, UnitName("player")) then
        ClearRolls()
        RuntimeState.awardedPlayersForRoll = {}
        RuntimeState.currentRollAwardOrder = {}
        CancelRollSession()
        syncSessionID = nil
        syncOwner = nil
        syncStateRequested = false
        syncReceivingState = false
        RuntimeState.selectedRoll = nil
        RuntimeState.syncedLootHistory = { MS = {}, OS = {} }
        RuntimeState.syncedPlusOneEnabled = false
        DemiseRaidRollsSoftRes.syncedPriorityEnabled = false
        DemiseRaidRollsSoftRes.syncedPlayers = {}
        DemiseRaidRollsSoftRes.syncedHardReserve = false
        RuntimeState.syncedLootHistoryRevision = 0
        RuntimeState.pendingSyncedLootHistory = nil
        RuntimeState.currentItemLink = nil
        RuntimeState.currentItemID = nil
        RuntimeState.currentTopRolls = 1
        UpdateItemDisplay()
        UpdateUI()
        return true
    end

    return false
end

local function HandleAddonSync(prefix, message, channel, sender)
    if prefix ~= SYNC_PREFIX or type(message) ~= "string" or not sender then
        return
    end

    -- Ignore our own broadcast echo; the authoritative client has already
    -- applied the local state before publishing it.
    if IsSamePlayerName(sender, UnitName("player")) then
        return
    end

    local command = message:match("^([^\t]+)")
    if not command then
        return
    end

    if command == "VER" then
        local protocol, version = message:match("^VER\t([^\t]+)\t([^\t]+)$")
        if version then
            NotifyNewerVersion(version, sender)
            if DemiseRaidRolls.Version.IsNewer(ADDON_VERSION, version) then
                SendSyncRaw("VER\t" .. tostring(SYNC_PROTOCOL) .. "\t" .. tostring(ADDON_VERSION), "WHISPER", sender)
            end
        end
        return
    end

    if command == "REQ" then
        if CanControlRolls and CanControlRolls() and SendFullSyncState then
            SendFullSyncState(sender)
        end
        return
    end

    -- All state-changing synchronization must come from the actual current
    -- Master Looter. This prevents assistants or ordinary raid members from
    -- creating fake roll sessions for other addon users.
    if not IsSenderCurrentMasterLooter(sender) then
        return
    end

    if command == "MODE" then
        local enabled = message:match("^MODE\t([01])$")
        if enabled and DemiseRaidRolls.RaidCouncil and DemiseRaidRolls.RaidCouncil.ApplySyncedMode then
            DemiseRaidRolls.RaidCouncil.ApplySyncedMode(enabled == "1", sender)
            UpdateControlState()
        end
        return
    end

    if command == "SRSTATE" then
        local sessionID, enabled, hardReserved = message:match("^SRSTATE\t([^\t]+)\t([01])\t([01])$")
        if sessionID and (sessionID == "0" or not syncSessionID or tostring(sessionID) == tostring(syncSessionID)) then
            DemiseRaidRollsSoftRes.syncedPriorityEnabled = enabled == "1"
            DemiseRaidRollsSoftRes.syncedHardReserve = hardReserved == "1"
            DemiseRaidRollsSoftRes.syncedPlayers = {}
            UpdateItemDisplay()
            UpdateUI()
        end
        return
    end

    if command == "SRPLAYER" then
        local sessionID, playerKey, reserveCount = message:match("^SRPLAYER\t([^\t]+)\t([^\t]+)\t([^\t]+)$")
        if not sessionID then
            sessionID, playerKey = message:match("^SRPLAYER\t([^\t]+)\t([^\t]+)$")
            reserveCount = 1
        end
        if sessionID and playerKey and (sessionID == "0" or not syncSessionID or tostring(sessionID) == tostring(syncSessionID)) then
            playerKey = NormalizeName(playerKey)
            if playerKey then DemiseRaidRollsSoftRes.syncedPlayers[playerKey] = math.max(1, math.floor(tonumber(reserveCount) or 1)) end
            UpdateUI()
        end
        return
    end

    if command == "PLUSBEGIN" then
        local revision, enabled = message:match("^PLUSBEGIN\t([^\t]+)\t([01])$")
        revision = tonumber(revision)
        if revision and revision >= RuntimeState.syncedLootHistoryRevision then
            RuntimeState.pendingSyncedLootHistory = {
                revision = revision,
                enabled = enabled == "1",
                history = { MS = {}, OS = {} },
            }
        end
        return
    end

    if command == "PLUSENTRY" then
        local revision, rollType, playerKey, count = message:match("^PLUSENTRY\t([^\t]+)\t([A-Z]+)\t([^\t]+)\t([^\t]+)$")
        if rollType ~= "MS" and rollType ~= "OS" then revision = nil end
        if not revision then
            revision, playerKey, count = message:match("^PLUSENTRY\t([^\t]+)\t([^\t]+)\t([^\t]+)$")
            rollType = "MS"
        end
        revision = tonumber(revision)
        count = math.max(0, math.floor(tonumber(count) or 0))
        if RuntimeState.pendingSyncedLootHistory and revision == RuntimeState.pendingSyncedLootHistory.revision and count > 0 then
            RuntimeState.pendingSyncedLootHistory.history[rollType][NormalizeName(playerKey) or playerKey] = count
        end
        return
    end

    if command == "PLUSEND" then
        local revision = tonumber(message:match("^PLUSEND\t([^\t]+)$"))
        if RuntimeState.pendingSyncedLootHistory and revision == RuntimeState.pendingSyncedLootHistory.revision then
            RuntimeState.syncedLootHistoryRevision = revision
            RuntimeState.syncedPlusOneEnabled = RuntimeState.pendingSyncedLootHistory.enabled
            RuntimeState.syncedLootHistory = RuntimeState.pendingSyncedLootHistory.history
            RuntimeState.pendingSyncedLootHistory = nil
            UpdateUI()
        end
        return
    end

    if command == "PLUSSET" then
        local revision, rollType, playerKey, count = message:match("^PLUSSET\t([^\t]+)\t([A-Z]+)\t([^\t]+)\t([^\t]+)$")
        if rollType ~= "MS" and rollType ~= "OS" then revision = nil end
        if not revision then
            revision, playerKey, count = message:match("^PLUSSET\t([^\t]+)\t([^\t]+)\t([^\t]+)$")
            rollType = "MS"
        end
        revision = tonumber(revision)
        count = math.max(0, math.floor(tonumber(count) or 0))
        playerKey = NormalizeName(playerKey)
        if revision and playerKey and revision >= RuntimeState.syncedLootHistoryRevision then
            RuntimeState.syncedLootHistoryRevision = revision
            if count > 0 then
                RuntimeState.syncedLootHistory[rollType] = RuntimeState.syncedLootHistory[rollType] or {}
                RuntimeState.syncedLootHistory[rollType][playerKey] = count
            else
                RuntimeState.syncedLootHistory[rollType] = RuntimeState.syncedLootHistory[rollType] or {}
                RuntimeState.syncedLootHistory[rollType][playerKey] = nil
            end
            UpdateUI()
        end
        return
    end

    if command == "START" then
        local sessionID, duration, itemID, itemLink = message:match("^START\t([^\t]+)\t([^\t]+)\t([^\t]+)\t(.*)$")
        if sessionID then
            ApplySyncedSession(sender, sessionID, true, duration, duration, itemID, itemLink, false)
            ShowLocalTimerAlert("ROLL STARTED - " .. tostring(math.ceil(tonumber(duration) or DEFAULT_ROLL_DURATION)) .. "s")
        end
        return
    end

    if command == "STATE" then
        local sessionID, openFlag, remaining, duration, itemID, itemLink = message:match("^STATE\t([^\t]+)\t([01])\t([^\t]+)\t([^\t]+)\t([^\t]+)\t(.*)$")
        if sessionID then
            ApplySyncedSession(sender, sessionID, openFlag == "1", remaining, duration, itemID, itemLink, true)
        end
        return
    end

    if command == "TOP" then
        local sessionID, topRolls = message:match("^TOP\t([^\t]+)\t([^\t]+)$")
        if sessionID and syncSessionID and tostring(sessionID) == tostring(syncSessionID) then
            RuntimeState.currentTopRolls = math.max(1, math.floor((tonumber(topRolls) or 1) + 0.5))
            UpdateItemDisplay()
        end
        return
    end

    if command == "ROLL" then
        local sessionID, playerName, roll, minimum, maximum, validFlag, softReserveIndex = message:match("^ROLL\t([^\t]+)\t([^\t]+)\t([^\t]+)\t([^\t]+)\t([^\t]+)\t([01])\t([^\t]+)$")
        if not sessionID then
            local reserved
            sessionID, playerName, roll, minimum, maximum, reserved = message:match("^ROLL\t([^\t]+)\t([^\t]+)\t([^\t]+)\t([^\t]+)\t([^\t]+)\t([01])$")
            if sessionID then
                softReserveIndex = reserved == "1" and "1" or "0"
            else
                sessionID, playerName, roll, minimum, maximum = message:match("^ROLL\t([^\t]+)\t([^\t]+)\t([^\t]+)\t([^\t]+)\t([^\t]+)$")
            end
        end
        if sessionID and syncSessionID and tostring(sessionID) == tostring(syncSessionID) then
            if RuntimeState.rollSessionOpen or syncReceivingState then
                local validOverride
                if validFlag == "1" then
                    validOverride = true
                elseif validFlag == "0" then
                    validOverride = false
                end
                AddRoll(playerName, tonumber(roll), tonumber(minimum), tonumber(maximum), true, validOverride, tonumber(softReserveIndex))
            end
        end
        return
    end

    if command == "TBPATH" then
        local sessionID, playerName, rollType, pathText = message:match("^TBPATH\t([^\t]+)\t([^\t]+)\t([^\t]+)\t(.*)$")
        if sessionID and syncSessionID and tostring(sessionID) == tostring(syncSessionID) then
            local entry = FindValidEntry(NormalizeName(playerName), rollType)
            if entry then
                entry.tiePath = {}
                local value
                for value in string.gmatch(tostring(pathText or ""), "[^,]+") do
                    local numberValue = tonumber(value)
                    if numberValue then
                        entry.tiePath[#entry.tiePath + 1] = numberValue
                    end
                end
                UpdateUI()
            end
        end
        return
    end

    if command == "TIESTART" then
        local sessionID, round, rollType, duration, playerList = message:match("^TIESTART\t([^\t]+)\t([^\t]+)\t([^\t]+)\t([^\t]+)\t(.*)$")
        if sessionID and syncSessionID and tostring(sessionID) == tostring(syncSessionID) then
            ApplyTieBreakStart(sessionID, round, rollType, duration, duration, playerList)
            ShowLocalTimerAlert("TIE-BREAK - " .. tostring(math.ceil(tonumber(duration) or DEFAULT_ROLL_DURATION)) .. "s")
        end
        return
    end

    if command == "TIESTATE" then
        local sessionID, round, rollType, remaining, duration, playerList = message:match("^TIESTATE\t([^\t]+)\t([^\t]+)\t([^\t]+)\t([^\t]+)\t([^\t]+)\t(.*)$")
        if sessionID and syncSessionID and tostring(sessionID) == tostring(syncSessionID) then
            ApplyTieBreakStart(sessionID, round, rollType, remaining, duration, playerList)
        end
        return
    end

    if command == "TIEROLL" then
        local sessionID, round, playerName, roll, maximum = message:match("^TIEROLL\t([^\t]+)\t([^\t]+)\t([^\t]+)\t([^\t]+)\t([^\t]+)$")
        if sessionID and syncSessionID and tostring(sessionID) == tostring(syncSessionID) and tonumber(round) == tonumber(RuntimeState.tieBreakRound) then
            AddTieBreakRoll(playerName, tonumber(roll), 1, tonumber(maximum), true)
        end
        return
    end

    if command == "TIEEND" then
        local sessionID, round = message:match("^TIEEND\t([^\t]+)\t([^\t]+)$")
        if sessionID and syncSessionID and tostring(sessionID) == tostring(syncSessionID) and tonumber(round) == tonumber(RuntimeState.tieBreakRound) then
            local wasActive = RuntimeState.tieBreakActive
            RuntimeState.rollTimerActive = false
            RuntimeState.rollSessionOpen = false
            RuntimeState.rollStartTime = 0
            RuntimeState.rollEndTime = 0
            RuntimeState.tieBreakActive = false
            RuntimeState.tieBreakPlayers = {}
            RuntimeState.tieBreakRoundRolls = {}
            SetTimerVisual(0)
            if RuntimeState.mainFrame then
                RuntimeState.mainFrame.timerText:SetText("TIE-BREAK CLOSED")
            end
            if wasActive then
                ShowLocalTimerAlert("TIE-BREAK CLOSED")
            end
            UpdateUI()
        end
        return
    end

    if command == "STATEDONE" then
        local sessionID = message:match("^STATEDONE\t([^\t]+)$")
        if sessionID and syncSessionID and tostring(sessionID) == tostring(syncSessionID) then
            syncReceivingState = false
            syncStateRequested = false
            UpdateUI()
        end
        return
    end

    if command == "END" then
        local sessionID = message:match("^END\t([^\t]+)$")
        if sessionID then
            CloseSyncedSession(sessionID)
        end
        return
    end

    if command == "RESET" then
        local sessionID = message:match("^RESET\t([^\t]+)$")
        if sessionID then
            ResetSyncedSession(sessionID)
        end
        return
    end

    if command == "IDLE" then
        syncStateRequested = false
        syncOwner = sender
        syncSessionID = nil
        syncReceivingState = false
        ClearRolls()
        CancelRollSession()
        RuntimeState.currentItemLink = nil
        RuntimeState.currentItemID = nil
        RuntimeState.currentTopRolls = 1
        UpdateItemDisplay()
        UpdateUI()
        return
    end
end

local function ResetRollSessionByController()
    local canControl = CanControlRolls and CanControlRolls() or false

    if canControl then
        if IsInRaid() and syncSessionID then
            BroadcastSessionReset()
        end

        ClearRolls()
        RuntimeState.awardedPlayersForRoll = {}
        RuntimeState.currentRollAwardOrder = {}
        CancelRollSession()
        syncSessionID = nil
        syncOwner = UnitName("player")
        syncReceivingState = false
        UpdateUI()
        return true, "shared"
    end

    -- Viewer fallback: when no addon-enabled Master Looter is currently hosting
    -- a synchronized session, Reset is purely local and only clears this user's
    -- roll history. It never sends RESET to the raid or affects another client.
    if IsRemoteSyncedSession and IsRemoteSyncedSession() then
        Print("the shared roll session is controlled by the Master Looter; Reset is locked until that session is cleared.")
        return false
    end

    ClearRolls()
    RuntimeState.awardedPlayersForRoll = {}
    RuntimeState.currentRollAwardOrder = {}
    RuntimeState.selectedRoll = nil
    UpdateUI()
    return true, "local"
end

local function PlayerCanAssignMasterLoot()
    local actualMaster, method = GetActualMasterLooterName()
    if method ~= "master" then
        return false, "the current loot method is not Master Loot"
    end

    if actualMaster and NormalizeName(actualMaster) ~= NormalizeName(UnitName("player")) then
        return false, tostring(actualMaster) .. " is the current Master Looter"
    end

    -- Ascension may expose the indices differently from stock 3.3.5. If the
    -- method is Master Loot but the owner index is missing, let GiveMasterLoot
    -- perform the final permission check instead of disabling the feature.
    return true
end

local function LootSlotContainsItem(slot)
    if LootSlotIsItem then
        return LootSlotIsItem(slot) and true or false
    end
    if GetLootSlotLink then
        return GetLootSlotLink(slot) ~= nil
    end
    if GetLootSlotInfo then
        local texture, itemName = GetLootSlotInfo(slot)
        return texture ~= nil and itemName ~= nil
    end
    return false
end

local function GetLootSlotDisplay(slot)
    local link = GetLootSlotLink and GetLootSlotLink(slot) or nil
    if link then
        return link
    end
    if GetLootSlotInfo then
        local _, itemName = GetLootSlotInfo(slot)
        if itemName then
            return itemName
        end
    end
    return "loot slot " .. tostring(slot)
end

local function IsLootSlotLockedCompat(slot)
    if not GetLootSlotInfo then
        return false
    end
    local _, _, _, _, locked = GetLootSlotInfo(slot)
    return locked and true or false
end

local function FindMasterLootCandidateIndex(targetName)
    if not GetMasterLootCandidate then
        return nil
    end

    local targetKey = NormalizeName(targetName)
    if not targetKey then
        return nil
    end

    -- Project Ascension's 3.3.5a API differs from stock WoW here:
    -- GetMasterLootCandidate accepts ONLY the candidate index.
    -- Passing the loot slot as the first argument makes the client repeatedly
    -- query the wrong candidate (usually candidate #1), which prevented @ME
    -- from being found whenever the player was candidate #2 or later.
    local i
    for i = 1, 40 do
        local candidateName = GetMasterLootCandidate(i)
        if candidateName and candidateName ~= "" and NormalizeName(candidateName) == targetKey then
            return i
        end
    end
    return nil
end

local function StopAutoMasterLoot(message)
    RuntimeState.autoMasterLootProcessing = false
    RuntimeState.autoMasterLootWaiting = false
    RuntimeState.autoMasterLootWaitingLink = nil
    RuntimeState.autoMasterLootBindConfirmSlot = nil
    RuntimeState.autoMasterLootTarget = nil
    RuntimeState.autoMasterLootAccumulator = 0
    if message then
        Print(message)
    end
end

local function ProcessAutoMasterLootStep()
    if not RuntimeState.autoMasterLootProcessing or RuntimeState.autoMasterLootWaiting then
        return
    end

    if not AscensionRaidRollsDB or AscensionRaidRollsDB.autoMasterLoot ~= true then
        StopAutoMasterLoot()
        return
    end

    if not GetNumLootItems or not GiveMasterLoot or not GetMasterLootCandidate then
        StopAutoMasterLoot("automatic Master Loot is unavailable: required loot functions are missing on this client.")
        return
    end

    local numLoot = GetNumLootItems() or 0
    if numLoot <= 0 then
        local assigned = RuntimeState.autoMasterLootAssignedCount
        StopAutoMasterLoot()
        if assigned > 0 then
            Print("automatic Master Loot complete: " .. tostring(assigned) .. " item(s) assigned.")
        end
        return
    end

    local sawItem = false
    local sawUnlockedItem = false
    local slot
    for slot = 1, numLoot do
        if LootSlotContainsItem(slot) then
            sawItem = true
            if not IsLootSlotLockedCompat(slot) then
                sawUnlockedItem = true
                local candidateIndex = FindMasterLootCandidateIndex(RuntimeState.autoMasterLootTarget)
                if candidateIndex then
                    RuntimeState.autoMasterLootWaiting = true
                    RuntimeState.autoMasterLootWaitingLink = GetLootSlotDisplay(slot)
                    RuntimeState.autoMasterLootWaitingSince = GetTime and GetTime() or 0
                    GiveMasterLoot(slot, candidateIndex)
                    return
                end
            end
        end
    end

    if not sawItem then
        StopAutoMasterLoot()
        return
    end

    -- A slot can remain locked for a short moment after another assignment.
    -- Wait for the next update instead of treating that temporary state as a
    -- permanent eligibility failure.
    if not sawUnlockedItem then
        return
    end

    -- This is an expected outcome when the remaining loot is below the Master
    -- Loot threshold or the configured recipient is not eligible. Stop quietly
    -- instead of printing the same informational message for every loot event.
    StopAutoMasterLoot()
end

local function StartAutoMasterLoot()
    if not AscensionRaidRollsDB or AscensionRaidRollsDB.autoMasterLoot ~= true then
        return
    end

    local canAssign, reason = PlayerCanAssignMasterLoot()
    if not canAssign then
        -- Opening normal Personal/Group Loot while Auto Loot to ML is enabled is
        -- expected outside Master Loot raids. Ignore that case silently instead
        -- of flooding chat every time the player loots an item or opens a cache.
        if reason ~= "the current loot method is not Master Loot" then
            Print("automatic Master Loot skipped: " .. tostring(reason) .. ".")
        end
        return
    end

    if not GetNumLootItems or not GiveMasterLoot or not GetMasterLootCandidate then
        Print("automatic Master Loot is unavailable: required loot functions are missing on this client.")
        return
    end

    RuntimeState.autoMasterLootProcessing = true
    RuntimeState.autoMasterLootTarget = ResolveMasterLooterTarget()
    RuntimeState.autoMasterLootAccumulator = 0
    RuntimeState.autoMasterLootWaiting = false
    RuntimeState.autoMasterLootWaitingLink = nil
    RuntimeState.autoMasterLootBindConfirmSlot = nil
    RuntimeState.autoMasterLootAssignedCount = 0

    ProcessAutoMasterLootStep()
end

local function HandleAutoMasterLootSlotCleared()
    if not RuntimeState.autoMasterLootProcessing then
        return
    end
    RuntimeState.autoMasterLootAssignedCount = RuntimeState.autoMasterLootAssignedCount + 1
    RuntimeState.autoMasterLootWaiting = false
    RuntimeState.autoMasterLootWaitingLink = nil
    RuntimeState.autoMasterLootAccumulator = 0
end

local function HandleAutoMasterLootBindConfirm(slot)
    if not RuntimeState.autoMasterLootProcessing or not AscensionRaidRollsDB or AscensionRaidRollsDB.autoMasterLoot ~= true then
        return
    end

    -- Defer to the next OnUpdate so the stock UI has time to create its
    -- LOOT_BIND popup first; then confirm and hide it.
    if slot then
        RuntimeState.autoMasterLootBindConfirmSlot = slot
    end
end

local function UpdateAutoMasterLoot(elapsed)
    if not RuntimeState.autoMasterLootProcessing then
        return
    end

    RuntimeState.autoMasterLootAccumulator = RuntimeState.autoMasterLootAccumulator + (elapsed or 0)
    if RuntimeState.autoMasterLootAccumulator < 0.20 then
        return
    end
    RuntimeState.autoMasterLootAccumulator = 0

    if RuntimeState.autoMasterLootBindConfirmSlot then
        local slot = RuntimeState.autoMasterLootBindConfirmSlot
        RuntimeState.autoMasterLootBindConfirmSlot = nil
        if ConfirmLootSlot then
            ConfirmLootSlot(slot)
        end
        if StaticPopup_Hide then
            StaticPopup_Hide("LOOT_BIND")
        end
    end

    if RuntimeState.autoMasterLootWaiting then
        local now = GetTime and GetTime() or 0
        if now - (RuntimeState.autoMasterLootWaitingSince or now) >= 2.0 then
            local pending = RuntimeState.autoMasterLootWaitingLink or "an item"
            StopAutoMasterLoot("automatic Master Loot paused on " .. tostring(pending) .. ". The loot slot did not clear.")
        end
        return
    end

    ProcessAutoMasterLootStep()
end

local function ExecutePlayerRoll(maximum)
    maximum = tonumber(maximum)
    if maximum ~= 100 and maximum ~= 99 then
        return
    end

    if RuntimeState.rollSessionStarted and not RuntimeState.rollSessionOpen then
        Print("this roll is closed; your /roll was not sent.")
        return
    end

    if RandomRoll then
        RandomRoll(1, maximum)
        return
    end

    if RunMacroText then
        RunMacroText("/roll " .. tostring(maximum))
        return
    end

    Print("unable to start /roll " .. tostring(maximum) .. " on this client.")
end

local function ToggleMainFrame()
    if DemiseRaidRolls.RaidCouncil and DemiseRaidRolls.RaidCouncil.IsEnabled and DemiseRaidRolls.RaidCouncil.IsEnabled() then
        if DemiseRaidCouncil and DemiseRaidCouncil.ToggleCouncilFrame then
            DemiseRaidCouncil:ToggleCouncilFrame()
        end
        return
    end
    if not RuntimeState.mainFrame then
        return
    end

    if RuntimeState.mainFrame:IsShown() then
        RuntimeState.mainFrame:Hide()
    else
        RuntimeState.mainFrame:Show()
    end
end

local function SaveFramePosition()
    if not RuntimeState.mainFrame or not AscensionRaidRollsDB then
        return
    end

    local point, _, relativePoint, x, y = RuntimeState.mainFrame:GetPoint(1)
    AscensionRaidRollsDB.point = point
    AscensionRaidRollsDB.relativePoint = relativePoint
    AscensionRaidRollsDB.x = x
    AscensionRaidRollsDB.y = y
end

local function CreateRollPanel(parent, anchorPoint, xOffset)
    local panel = CreateFrame("Frame", nil, parent)
    panel:SetPoint(anchorPoint, parent, anchorPoint, xOffset, -181)
    panel:SetWidth(275)
    panel:SetHeight(304)

    panel.bg = panel:CreateTexture(nil, "BACKGROUND")
    panel.bg:SetAllPoints(panel)
    panel.bg:SetTexture(0, 0, 0, 0.22)

    panel.scroll = CreateFrame("ScrollFrame", nil, panel, "UIPanelScrollFrameTemplate")
    panel.scroll:SetPoint("TOPLEFT", panel, "TOPLEFT", 8, -7)
    panel.scroll:SetPoint("BOTTOMRIGHT", panel, "BOTTOMRIGHT", -27, 7)
    panel.scroll:EnableMouseWheel(true)
    panel.scroll:SetScript("OnMouseWheel", function(self, delta)
        local current = self:GetVerticalScroll()
        local range = self:GetVerticalScrollRange()
        local nextScroll = current - (delta * 44)
        if nextScroll < 0 then
            nextScroll = 0
        elseif nextScroll > range then
            nextScroll = range
        end
        self:SetVerticalScroll(nextScroll)
    end)

    panel.content = CreateFrame("Frame", nil, panel.scroll)
    panel.content:SetWidth(236)
    panel.content:SetHeight(1)
    panel.scroll:SetScrollChild(panel.content)
    panel.rows = {}

    return panel
end

UpdateOptionsControlState = function()
    if not RuntimeState.optionsFrame then
        return
    end

    local canManageHistory = not IsInRaid() or (CanControlRolls and CanControlRolls())
    RuntimeState.optionsFrame.plusOneCheck:SetChecked(IsMSOSPlusOneEnabled())
    SetButtonEnabled(RuntimeState.optionsFrame.plusOneCheck, canManageHistory)
    SetButtonEnabled(RuntimeState.optionsFrame.clearHistoryButton, canManageHistory)
    if RuntimeState.optionsFrame.muteWinnerCheck then
        SetButtonEnabled(RuntimeState.optionsFrame.muteWinnerCheck, canManageHistory)
    end
    if RuntimeState.optionsFrame.reserveModeCheck then
        RuntimeState.optionsFrame.reserveModeCheck:SetChecked(DemiseRaidRollsSoftRes.IsPriorityEnabled())
        SetButtonEnabled(RuntimeState.optionsFrame.reserveModeCheck, canManageHistory)
        SetButtonEnabled(RuntimeState.optionsFrame.reserveImportButton, canManageHistory)
        SetButtonEnabled(RuntimeState.optionsFrame.reserveCheckButton, canManageHistory)
        if RuntimeState.optionsFrame.reserveLimitEdit then
            RuntimeState.optionsFrame.reserveLimitEdit:EnableMouse(canManageHistory)
            RuntimeState.optionsFrame.reserveLimitEdit:SetTextColor(canManageHistory and 1 or 0.5, canManageHistory and 1 or 0.5, canManageHistory and 1 or 0.5)
        end
        if RuntimeState.optionsFrame.reserveURLEdit then
            RuntimeState.optionsFrame.reserveURLEdit:EnableMouse(canManageHistory)
            RuntimeState.optionsFrame.reserveURLEdit:SetTextColor(canManageHistory and 1 or 0.5, canManageHistory and 1 or 0.5, canManageHistory and 1 or 0.5)
        end
    end

    if RuntimeState.optionsFrame.historyText then
        local players = 0
        local items = 0
        local seenPlayers = {}
        local history = GetActiveLootHistory() or {}
        local _, rollType
        for _, rollType in ipairs({ "MS", "OS" }) do
            local playerKey, count
            for playerKey, count in pairs(history[rollType] or {}) do
                if not seenPlayers[playerKey] then
                    seenPlayers[playerKey] = true
                    players = players + 1
                end
                items = items + (tonumber(count) or 0)
            end
        end
        RuntimeState.optionsFrame.historyText:SetText("History: " .. tostring(items) .. " MS+OS items / " .. tostring(players) .. " players")
    end
    if RuntimeState.optionsFrame.reserveStatus and not ShouldUseSyncedLootHistory() then
        local data = DemiseRaidRollsSoftRes.GetData()
        if data and type(data.roster) == "table" then
            local players, reserves, hard = 0, 0, 0
            local _, entry
            for _, entry in pairs(data.roster) do players = players + 1; reserves = reserves + (tonumber(entry.itemCount) or 0) end
            for _ in pairs(data.hardItems or {}) do hard = hard + 1 end
            RuntimeState.optionsFrame.reserveStatus:SetText(tostring(players) .. " players, " .. tostring(reserves) .. " SR, " .. tostring(hard) .. " HR imported.")
        end
    end
end

function DemiseRaidRollsSoftRes.CreateImportFrame()
    if DemiseRaidRollsSoftRes.importFrame then
        return DemiseRaidRollsSoftRes.importFrame
    end

    local frame = CreateFrame("Frame", "DemiseRaidRollsReserveImportFrame", UIParent)
    frame:SetWidth(800)
    frame:SetHeight(560)
    frame:SetFrameStrata("FULLSCREEN_DIALOG")
    frame:SetClampedToScreen(true)
    frame:EnableMouse(true)
    frame:SetMovable(true)
    frame:RegisterForDrag("LeftButton")
    frame:SetScript("OnDragStart", function(self) self:StartMoving() end)
    frame:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end)
    frame:SetBackdrop({
        bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
        edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
        tile = true,
        tileSize = 32,
        edgeSize = 32,
        insets = { left = 11, right = 12, top = 12, bottom = 11 },
    })
    frame:SetPoint("CENTER", UIParent, "CENTER", 0, 0)

    frame.title = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    frame.title:SetPoint("TOP", frame, "TOP", 0, -19)
    frame.title:SetText("Import SoftRes / HardRes")

    frame.help = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    frame.help:SetPoint("TOPLEFT", frame, "TOPLEFT", 38, -60)
    frame.help:SetWidth(720)
    frame.help:SetJustifyH("LEFT")
    frame.help:SetText("Paste the complete BisBeard Base64 export below.")
    frame.help:SetTextColor(0.75, 0.75, 0.75)

    frame.editBackground = CreateFrame("Frame", nil, frame)
    frame.editBackground:SetPoint("TOPLEFT", frame, "TOPLEFT", 38, -85)
    frame.editBackground:SetWidth(724)
    frame.editBackground:SetHeight(370)
    frame.editBackground:SetBackdrop({
        bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
        tile = true,
        tileSize = 16,
        edgeSize = 8,
        insets = { left = 3, right = 3, top = 3, bottom = 3 },
    })
    frame.editBackground:SetBackdropColor(0.01, 0.01, 0.01, 0.98)
    frame.editBackground:SetBackdropBorderColor(0.55, 0.55, 0.55, 1.0)

    frame.scroll = CreateFrame("ScrollFrame", nil, frame.editBackground, "UIPanelScrollFrameTemplate")
    frame.scroll:SetPoint("TOPLEFT", frame.editBackground, "TOPLEFT", 8, -8)
    frame.scroll:SetPoint("BOTTOMRIGHT", frame.editBackground, "BOTTOMRIGHT", -28, 8)
    frame.scroll:EnableMouseWheel(true)
    frame.scroll:SetScript("OnMouseWheel", function(self, delta)
        local current = self:GetVerticalScroll()
        local range = self:GetVerticalScrollRange()
        local nextScroll = current - (delta * 45)
        if nextScroll < 0 then nextScroll = 0 end
        if nextScroll > range then nextScroll = range end
        self:SetVerticalScroll(nextScroll)
    end)

    frame.edit = CreateFrame("EditBox", nil, frame.scroll)
    frame.edit:SetWidth(675)
    frame.edit:SetHeight(350)
    frame.edit:SetMultiLine(true)
    frame.edit:SetAutoFocus(false)
    frame.edit:SetMaxLetters(100000)
    frame.edit:SetFontObject(GameFontHighlightSmall)
    frame.edit:SetTextColor(1.0, 1.0, 1.0)
    frame.edit:SetTextInsets(4, 4, 4, 4)
    frame.edit:SetScript("OnEscapePressed", function(self) self:ClearFocus(); frame:Hide() end)
    frame.scroll:SetScrollChild(frame.edit)

    frame.status = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    frame.status:SetPoint("TOPLEFT", frame, "TOPLEFT", 40, -468)
    frame.status:SetWidth(720)
    frame.status:SetJustifyH("LEFT")
    frame.status:SetText("")

    frame.importButton = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
    frame.importButton:SetWidth(210)
    frame.importButton:SetHeight(26)
    frame.importButton:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", 140, 28)
    frame.importButton:SetText("Import")
    frame.importButton:SetScript("OnClick", function()
        if DemiseRaidRollsSoftRes.ImportExport(frame.edit:GetText()) then
            frame.edit:ClearFocus()
            frame:Hide()
            UpdateOptionsControlState()
        end
    end)

    frame.cancelButton = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
    frame.cancelButton:SetWidth(210)
    frame.cancelButton:SetHeight(26)
    frame.cancelButton:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -140, 28)
    frame.cancelButton:SetText("Cancel")
    frame.cancelButton:SetScript("OnClick", function() frame.edit:ClearFocus(); frame:Hide() end)

    frame.closeButton = CreateFrame("Button", nil, frame, "UIPanelCloseButton")
    frame.closeButton:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -4, -4)

    frame:SetScript("OnShow", function()
        frame.edit:SetText(AscensionRaidRollsDB.reserveImportText or "")
        frame.status:SetText("")
        frame.edit:SetFocus()
        frame.edit:SetCursorPosition(0)
        frame.scroll:SetVerticalScroll(0)
    end)
    frame:Hide()
    DemiseRaidRollsSoftRes.importFrame = frame
    return frame
end

local function CreateOptionsFrame()
    if RuntimeState.optionsFrame then
        return
    end

    RuntimeState.optionsFrame = CreateFrame("Frame", "DemiseRaidRollsOptionsFrame", UIParent)
    RuntimeState.optionsFrame:SetWidth(390)
    RuntimeState.optionsFrame:SetHeight(585)
    RuntimeState.optionsFrame:SetFrameStrata("DIALOG")
    RuntimeState.optionsFrame:SetClampedToScreen(true)
    RuntimeState.optionsFrame:EnableMouse(true)
    RuntimeState.optionsFrame:SetMovable(true)
    RuntimeState.optionsFrame:RegisterForDrag("LeftButton")
    RuntimeState.optionsFrame:SetScript("OnDragStart", function(self)
        self:StartMoving()
    end)
    RuntimeState.optionsFrame:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
    end)
    RuntimeState.optionsFrame:SetBackdrop({
        bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
        edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
        tile = true,
        tileSize = 32,
        edgeSize = 32,
        insets = { left = 11, right = 12, top = 12, bottom = 11 },
    })
    RuntimeState.optionsFrame:SetPoint("CENTER", UIParent, "CENTER", 300, 0)

    RuntimeState.optionsFrame.title = RuntimeState.optionsFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    RuntimeState.optionsFrame.title:SetPoint("TOP", RuntimeState.optionsFrame, "TOP", 0, -18)
    RuntimeState.optionsFrame.title:SetText("Raid Rolls Options")

    RuntimeState.optionsFrame.closeButton = CreateFrame("Button", nil, RuntimeState.optionsFrame, "UIPanelCloseButton")
    RuntimeState.optionsFrame.closeButton:SetPoint("TOPRIGHT", RuntimeState.optionsFrame, "TOPRIGHT", -4, -4)

    RuntimeState.optionsFrame.plusOneTitle = RuntimeState.optionsFrame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    RuntimeState.optionsFrame.plusOneTitle:SetPoint("TOPLEFT", RuntimeState.optionsFrame, "TOPLEFT", 25, -55)
    RuntimeState.optionsFrame.plusOneTitle:SetText("MS/OS+1")

    RuntimeState.optionsFrame.plusOneCheck = CreateFrame("CheckButton", nil, RuntimeState.optionsFrame, "UICheckButtonTemplate")
    RuntimeState.optionsFrame.plusOneCheck:SetWidth(24)
    RuntimeState.optionsFrame.plusOneCheck:SetHeight(24)
    RuntimeState.optionsFrame.plusOneCheck:SetPoint("TOPLEFT", RuntimeState.optionsFrame, "TOPLEFT", 24, -76)
    RuntimeState.optionsFrame.plusOneCheck:SetScript("OnClick", function(self)
        if IsInRaid() and (not CanControlRolls or not CanControlRolls()) then
            self:SetChecked(IsMSOSPlusOneEnabled())
            return
        end
        AscensionRaidRollsDB.msosPlusOneEnabled = self:GetChecked() and true or false
        BroadcastLootHistory()
        UpdateUI()
        Print("MS/OS+1 " .. (AscensionRaidRollsDB.msosPlusOneEnabled and "enabled." or "disabled."))
    end)

    RuntimeState.optionsFrame.plusOneLabel = RuntimeState.optionsFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    RuntimeState.optionsFrame.plusOneLabel:SetPoint("LEFT", RuntimeState.optionsFrame.plusOneCheck, "RIGHT", 3, 0)
    RuntimeState.optionsFrame.plusOneLabel:SetText("Enable MS/OS+1 loot history")

    RuntimeState.optionsFrame.plusOneHelp = RuntimeState.optionsFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    RuntimeState.optionsFrame.plusOneHelp:SetPoint("TOPLEFT", RuntimeState.optionsFrame, "TOPLEFT", 30, -103)
    RuntimeState.optionsFrame.plusOneHelp:SetWidth(330)
    RuntimeState.optionsFrame.plusOneHelp:SetJustifyH("LEFT")
    RuntimeState.optionsFrame.plusOneHelp:SetText("Shows separate +X counters in MS and OS. A completed trade credits the selected roll type; both histories persist until cleared.")
    RuntimeState.optionsFrame.plusOneHelp:SetTextColor(0.70, 0.70, 0.70)

    RuntimeState.optionsFrame.historyText = RuntimeState.optionsFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    RuntimeState.optionsFrame.historyText:SetPoint("TOPLEFT", RuntimeState.optionsFrame, "TOPLEFT", 30, -142)
    RuntimeState.optionsFrame.historyText:SetTextColor(0.85, 0.85, 0.85)

    RuntimeState.optionsFrame.clearHistoryButton = CreateFrame("Button", nil, RuntimeState.optionsFrame, "UIPanelButtonTemplate")
    RuntimeState.optionsFrame.clearHistoryButton:SetWidth(145)
    RuntimeState.optionsFrame.clearHistoryButton:SetHeight(22)
    RuntimeState.optionsFrame.clearHistoryButton:SetPoint("TOPRIGHT", RuntimeState.optionsFrame, "TOPRIGHT", -25, -134)
    RuntimeState.optionsFrame.clearHistoryButton:SetText("Clear Loot History")
    RuntimeState.optionsFrame.clearHistoryButton:SetScript("OnClick", function()
        ClearLootHistory()
        if RuntimeState.optionsFrame and RuntimeState.optionsFrame.historyText then
            RuntimeState.optionsFrame.historyText:SetText("History: 0 items / 0 players")
        end
    end)

    RuntimeState.optionsFrame.separator = RuntimeState.optionsFrame:CreateTexture(nil, "ARTWORK")
    RuntimeState.optionsFrame.separator:SetTexture(1, 1, 1, 0.12)
    RuntimeState.optionsFrame.separator:SetHeight(1)
    RuntimeState.optionsFrame.separator:SetPoint("TOPLEFT", RuntimeState.optionsFrame, "TOPLEFT", 24, -176)
    RuntimeState.optionsFrame.separator:SetPoint("TOPRIGHT", RuntimeState.optionsFrame, "TOPRIGHT", -24, -176)

    RuntimeState.optionsFrame.reserveTitle = RuntimeState.optionsFrame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    RuntimeState.optionsFrame.reserveTitle:SetPoint("TOPLEFT", RuntimeState.optionsFrame, "TOPLEFT", 25, -192)
    RuntimeState.optionsFrame.reserveTitle:SetText("SoftRes / HardRes")

    RuntimeState.optionsFrame.reserveModeCheck = CreateFrame("CheckButton", nil, RuntimeState.optionsFrame, "UICheckButtonTemplate")
    RuntimeState.optionsFrame.reserveModeCheck:SetWidth(24)
    RuntimeState.optionsFrame.reserveModeCheck:SetHeight(24)
    RuntimeState.optionsFrame.reserveModeCheck:SetPoint("TOPLEFT", RuntimeState.optionsFrame, "TOPLEFT", 24, -213)
    RuntimeState.optionsFrame.reserveModeCheck:SetScript("OnClick", function(self)
        if IsInRaid() and (not CanControlRolls or not CanControlRolls()) then
            self:SetChecked(DemiseRaidRollsSoftRes.IsPriorityEnabled())
            return
        end
        AscensionRaidRollsDB.reservePriorityEnabled = self:GetChecked() and true or false
        DemiseRaidRollsSoftRes.BroadcastCurrentState()
        UpdateItemDisplay()
        UpdateUI()
        Print("SR > MS > OS priority " .. (AscensionRaidRollsDB.reservePriorityEnabled and "enabled." or "disabled."))
    end)

    RuntimeState.optionsFrame.reserveModeLabel = RuntimeState.optionsFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    RuntimeState.optionsFrame.reserveModeLabel:SetPoint("LEFT", RuntimeState.optionsFrame.reserveModeCheck, "RIGHT", 3, 0)
    RuntimeState.optionsFrame.reserveModeLabel:SetText("Use SR > MS > OS priority")

    RuntimeState.optionsFrame.reserveLimitLabel = RuntimeState.optionsFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    RuntimeState.optionsFrame.reserveLimitLabel:SetPoint("TOPLEFT", RuntimeState.optionsFrame, "TOPLEFT", 245, -219)
    RuntimeState.optionsFrame.reserveLimitLabel:SetText("SR allowed")

    RuntimeState.optionsFrame.reserveLimitEdit = CreateFrame("EditBox", nil, RuntimeState.optionsFrame, "InputBoxTemplate")
    RuntimeState.optionsFrame.reserveLimitEdit:SetWidth(35)
    RuntimeState.optionsFrame.reserveLimitEdit:SetHeight(22)
    RuntimeState.optionsFrame.reserveLimitEdit:SetPoint("LEFT", RuntimeState.optionsFrame.reserveLimitLabel, "RIGHT", 6, 0)
    RuntimeState.optionsFrame.reserveLimitEdit:SetAutoFocus(false)
    RuntimeState.optionsFrame.reserveLimitEdit:SetMaxLetters(2)
    if RuntimeState.optionsFrame.reserveLimitEdit.SetNumeric then RuntimeState.optionsFrame.reserveLimitEdit:SetNumeric(true) end
    local function SaveSoftResLimit()
        local value = math.floor(tonumber(RuntimeState.optionsFrame.reserveLimitEdit:GetText()) or tonumber(AscensionRaidRollsDB.softResLimit) or 2)
        value = math.max(1, math.min(10, value))
        AscensionRaidRollsDB.softResLimit = value
        RuntimeState.optionsFrame.reserveLimitEdit:SetText(tostring(value))
    end
    RuntimeState.optionsFrame.reserveLimitEdit:SetScript("OnEnterPressed", function(self) SaveSoftResLimit(); self:ClearFocus() end)
    RuntimeState.optionsFrame.reserveLimitEdit:SetScript("OnEditFocusLost", SaveSoftResLimit)

    RuntimeState.optionsFrame.reserveURLLabel = RuntimeState.optionsFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    RuntimeState.optionsFrame.reserveURLLabel:SetPoint("TOPLEFT", RuntimeState.optionsFrame, "TOPLEFT", 30, -247)
    RuntimeState.optionsFrame.reserveURLLabel:SetText("BisBeard URL")

    RuntimeState.optionsFrame.reserveURLEdit = CreateFrame("EditBox", nil, RuntimeState.optionsFrame)
    RuntimeState.optionsFrame.reserveURLEdit:SetWidth(240)
    RuntimeState.optionsFrame.reserveURLEdit:SetHeight(22)
    RuntimeState.optionsFrame.reserveURLEdit:SetPoint("LEFT", RuntimeState.optionsFrame.reserveURLLabel, "RIGHT", 8, 0)
    RuntimeState.optionsFrame.reserveURLEdit:SetAutoFocus(false)
    RuntimeState.optionsFrame.reserveURLEdit:SetMaxLetters(200)
    if RuntimeState.optionsFrame.reserveURLEdit.SetFontObject and GameFontHighlightSmall then
        RuntimeState.optionsFrame.reserveURLEdit:SetFontObject(GameFontHighlightSmall)
    end
    if RuntimeState.optionsFrame.reserveURLEdit.SetTextInsets then
        RuntimeState.optionsFrame.reserveURLEdit:SetTextInsets(6, 6, 0, 0)
    end
    RuntimeState.optionsFrame.reserveURLEdit:SetBackdrop({
        bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
        tile = true,
        tileSize = 16,
        edgeSize = 8,
        insets = { left = 2, right = 2, top = 2, bottom = 2 },
    })
    RuntimeState.optionsFrame.reserveURLEdit:SetBackdropColor(0.03, 0.03, 0.03, 0.92)
    RuntimeState.optionsFrame.reserveURLEdit:SetBackdropBorderColor(0.45, 0.45, 0.45, 1.0)
    local function SaveSoftResURL()
        AscensionRaidRollsDB.softResURL = Trim(RuntimeState.optionsFrame.reserveURLEdit:GetText() or "") or ""
        RuntimeState.optionsFrame.reserveURLEdit:SetText(AscensionRaidRollsDB.softResURL)
    end
    RuntimeState.optionsFrame.reserveURLEdit:SetScript("OnEnterPressed", function(self) SaveSoftResURL(); self:ClearFocus() end)
    RuntimeState.optionsFrame.reserveURLEdit:SetScript("OnEditFocusLost", SaveSoftResURL)

    RuntimeState.optionsFrame.reserveImportButton = CreateFrame("Button", nil, RuntimeState.optionsFrame, "UIPanelButtonTemplate")
    RuntimeState.optionsFrame.reserveImportButton:SetWidth(145)
    RuntimeState.optionsFrame.reserveImportButton:SetHeight(22)
    RuntimeState.optionsFrame.reserveImportButton:SetPoint("TOPLEFT", RuntimeState.optionsFrame, "TOPLEFT", 30, -281)
    RuntimeState.optionsFrame.reserveImportButton:SetText("Import Reservations")
    RuntimeState.optionsFrame.reserveImportButton:SetScript("OnClick", function()
        DemiseRaidRollsSoftRes.CreateImportFrame():Show()
    end)

    RuntimeState.optionsFrame.reserveCheckButton = CreateFrame("Button", nil, RuntimeState.optionsFrame, "UIPanelButtonTemplate")
    RuntimeState.optionsFrame.reserveCheckButton:SetWidth(160)
    RuntimeState.optionsFrame.reserveCheckButton:SetHeight(22)
    RuntimeState.optionsFrame.reserveCheckButton:SetPoint("TOPRIGHT", RuntimeState.optionsFrame, "TOPRIGHT", -30, -281)
    RuntimeState.optionsFrame.reserveCheckButton:SetText("Check Raid SoftRes")
    RuntimeState.optionsFrame.reserveCheckButton:SetScript("OnClick", CheckMissingReservations)

    RuntimeState.optionsFrame.reserveStatus = RuntimeState.optionsFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    RuntimeState.optionsFrame.reserveStatus:SetPoint("TOPLEFT", RuntimeState.optionsFrame, "TOPLEFT", 30, -312)
    RuntimeState.optionsFrame.reserveStatus:SetWidth(330)
    RuntimeState.optionsFrame.reserveStatus:SetJustifyH("LEFT")
    RuntimeState.optionsFrame.reserveStatus:SetText("No reservation list imported.")

    RuntimeState.optionsFrame.reserveSeparator = RuntimeState.optionsFrame:CreateTexture(nil, "ARTWORK")
    RuntimeState.optionsFrame.reserveSeparator:SetTexture(1, 1, 1, 0.12)
    RuntimeState.optionsFrame.reserveSeparator:SetHeight(1)
    RuntimeState.optionsFrame.reserveSeparator:SetPoint("TOPLEFT", RuntimeState.optionsFrame, "TOPLEFT", 24, -347)
    RuntimeState.optionsFrame.reserveSeparator:SetPoint("TOPRIGHT", RuntimeState.optionsFrame, "TOPRIGHT", -24, -347)

    RuntimeState.optionsFrame.lootTitle = RuntimeState.optionsFrame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    RuntimeState.optionsFrame.lootTitle:SetPoint("TOPLEFT", RuntimeState.optionsFrame, "TOPLEFT", 25, -363)
    RuntimeState.optionsFrame.lootTitle:SetText("Miscellaneous")

    RuntimeState.optionsFrame.masterLooterLabel = RuntimeState.optionsFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    RuntimeState.optionsFrame.masterLooterLabel:SetPoint("TOPLEFT", RuntimeState.optionsFrame, "TOPLEFT", 30, -432)
    RuntimeState.optionsFrame.masterLooterLabel:SetText("Autoloot recipient")

    RuntimeState.optionsFrame.masterLooterEdit = CreateFrame("EditBox", nil, RuntimeState.optionsFrame)
    RuntimeState.optionsFrame.masterLooterEdit:SetWidth(125)
    RuntimeState.optionsFrame.masterLooterEdit:SetHeight(22)
    RuntimeState.optionsFrame.masterLooterEdit:SetPoint("LEFT", RuntimeState.optionsFrame.masterLooterLabel, "RIGHT", 10, 0)
    RuntimeState.optionsFrame.masterLooterEdit:SetAutoFocus(false)
    RuntimeState.optionsFrame.masterLooterEdit:SetMaxLetters(24)
    if RuntimeState.optionsFrame.masterLooterEdit.SetFontObject and GameFontHighlightSmall then
        RuntimeState.optionsFrame.masterLooterEdit:SetFontObject(GameFontHighlightSmall)
    end
    if RuntimeState.optionsFrame.masterLooterEdit.SetTextInsets then
        RuntimeState.optionsFrame.masterLooterEdit:SetTextInsets(6, 6, 0, 0)
    end
    if RuntimeState.optionsFrame.masterLooterEdit.SetBackdrop then
        RuntimeState.optionsFrame.masterLooterEdit:SetBackdrop({
            bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
            edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
            tile = true,
            tileSize = 16,
            edgeSize = 8,
            insets = { left = 2, right = 2, top = 2, bottom = 2 },
        })
        RuntimeState.optionsFrame.masterLooterEdit:SetBackdropColor(0.03, 0.03, 0.03, 0.90)
        RuntimeState.optionsFrame.masterLooterEdit:SetBackdropBorderColor(0.45, 0.45, 0.45, 1.0)
    end
    RuntimeState.optionsFrame.masterLooterEdit:SetScript("OnEnterPressed", function(self)
        SaveMasterLooterSetting()
        self:ClearFocus()
    end)
    RuntimeState.optionsFrame.masterLooterEdit:SetScript("OnEditFocusLost", function()
        SaveMasterLooterSetting()
    end)
    RuntimeState.optionsFrame.masterLooterEdit:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:SetText("Autoloot recipient")
        GameTooltip:AddLine("When Auto Loot to ML is enabled, eligible Master Loot items are automatically assigned to this player.", 1, 1, 1, true)
        GameTooltip:AddLine("Use @ME for your current character, or enter the exact name of a raid member.", 0.82, 0.82, 0.82, true)
        GameTooltip:Show()
    end)
    RuntimeState.optionsFrame.masterLooterEdit:SetScript("OnLeave", function() GameTooltip:Hide() end)

    RuntimeState.optionsFrame.masterLooterTooltip = CreateFrame("Frame", nil, RuntimeState.optionsFrame)
    RuntimeState.optionsFrame.masterLooterTooltip:SetPoint("LEFT", RuntimeState.optionsFrame.masterLooterLabel, "LEFT", -2, 0)
    RuntimeState.optionsFrame.masterLooterTooltip:SetWidth(105)
    RuntimeState.optionsFrame.masterLooterTooltip:SetHeight(22)
    RuntimeState.optionsFrame.masterLooterTooltip:EnableMouse(true)
    RuntimeState.optionsFrame.masterLooterTooltip:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:SetText("Autoloot recipient")
        GameTooltip:AddLine("When Auto Loot to ML is enabled, eligible Master Loot items are automatically assigned to this player.", 1, 1, 1, true)
        GameTooltip:AddLine("Use @ME for your current character, or enter the exact name of a raid member.", 0.82, 0.82, 0.82, true)
        GameTooltip:Show()
    end)
    RuntimeState.optionsFrame.masterLooterTooltip:SetScript("OnLeave", function() GameTooltip:Hide() end)

    RuntimeState.optionsFrame.autoLootCheck = CreateFrame("CheckButton", nil, RuntimeState.optionsFrame, "UICheckButtonTemplate")
    RuntimeState.optionsFrame.autoLootCheck:SetWidth(24)
    RuntimeState.optionsFrame.autoLootCheck:SetHeight(24)
    RuntimeState.optionsFrame.autoLootCheck:SetPoint("TOPLEFT", RuntimeState.optionsFrame, "TOPLEFT", 24, -396)
    RuntimeState.optionsFrame.autoLootCheck:SetScript("OnClick", function(self)
        SetAutoMasterLootEnabled(self:GetChecked() and true or false)
    end)
    RuntimeState.optionsFrame.autoLootCheck:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:SetText("Auto Loot to ML")
        GameTooltip:AddLine("Automatically assigns eligible Master Loot items to the configured Autoloot recipient when the loot window opens.", 1, 1, 1, true)
        GameTooltip:Show()
    end)
    RuntimeState.optionsFrame.autoLootCheck:SetScript("OnLeave", function() GameTooltip:Hide() end)

    RuntimeState.optionsFrame.autoLootLabel = RuntimeState.optionsFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    RuntimeState.optionsFrame.autoLootLabel:SetPoint("LEFT", RuntimeState.optionsFrame.autoLootCheck, "RIGHT", 3, 0)
    RuntimeState.optionsFrame.autoLootLabel:SetText("Auto Loot to ML")

    RuntimeState.optionsFrame.muteWinnerCheck = CreateFrame("CheckButton", nil, RuntimeState.optionsFrame, "UICheckButtonTemplate")
    RuntimeState.optionsFrame.muteWinnerCheck:SetWidth(24)
    RuntimeState.optionsFrame.muteWinnerCheck:SetHeight(24)
    RuntimeState.optionsFrame.muteWinnerCheck:SetPoint("TOPLEFT", RuntimeState.optionsFrame, "TOPLEFT", 24, -464)
    RuntimeState.optionsFrame.muteWinnerCheck:SetScript("OnClick", function(self)
        if IsInRaid() and (not CanControlRolls or not CanControlRolls()) then
            self:SetChecked(AscensionRaidRollsDB.muteWinnerAnnouncement == true)
            return
        end
        AscensionRaidRollsDB.muteWinnerAnnouncement = self:GetChecked() and true or false
        Print("winner announcement " .. (AscensionRaidRollsDB.muteWinnerAnnouncement and "muted." or "enabled."))
    end)

    RuntimeState.optionsFrame.muteWinnerLabel = RuntimeState.optionsFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    RuntimeState.optionsFrame.muteWinnerLabel:SetPoint("LEFT", RuntimeState.optionsFrame.muteWinnerCheck, "RIGHT", 3, 0)
    RuntimeState.optionsFrame.muteWinnerLabel:SetText("Mute winner announcement")

	RuntimeState.optionsFrame.hideMinimapCheck = CreateFrame("CheckButton", nil, RuntimeState.optionsFrame, "UICheckButtonTemplate")
	RuntimeState.optionsFrame.hideMinimapCheck:SetWidth(24)
	RuntimeState.optionsFrame.hideMinimapCheck:SetHeight(24)
	RuntimeState.optionsFrame.hideMinimapCheck:SetPoint("TOPLEFT", RuntimeState.optionsFrame, "TOPLEFT", 24, -493)
	RuntimeState.optionsFrame.hideMinimapCheck:SetScript("OnClick", function(self)
		AscensionRaidRollsDB.hideMinimapIcon = self:GetChecked() and true or false
		if DemiseRaidRolls.UpdateMinimapVisibility then DemiseRaidRolls.UpdateMinimapVisibility() end
	end)
	RuntimeState.optionsFrame.hideMinimapLabel = RuntimeState.optionsFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	RuntimeState.optionsFrame.hideMinimapLabel:SetPoint("LEFT", RuntimeState.optionsFrame.hideMinimapCheck, "RIGHT", 3, 0)
	RuntimeState.optionsFrame.hideMinimapLabel:SetText("Hide minimap icon")

    RuntimeState.optionsFrame.troubleshootingButton = CreateFrame("Button", nil, RuntimeState.optionsFrame, "UIPanelButtonTemplate")
    RuntimeState.optionsFrame.troubleshootingButton:SetWidth(150)
    RuntimeState.optionsFrame.troubleshootingButton:SetHeight(24)
    RuntimeState.optionsFrame.troubleshootingButton:SetPoint("BOTTOM", RuntimeState.optionsFrame, "BOTTOM", 0, 22)
    RuntimeState.optionsFrame.troubleshootingButton:SetText("Troubleshooting")
    RuntimeState.optionsFrame.troubleshootingButton:SetScript("OnClick", function()
        DemiseRaidRolls.ShowTroubleshootingReport()
    end)

    -- Keep compatibility with the existing settings/control helpers while the
    -- actual widgets now live in the dedicated Options frame.
    RuntimeState.mainFrame.masterLooterEdit = RuntimeState.optionsFrame.masterLooterEdit
    RuntimeState.mainFrame.masterLooterLabel = RuntimeState.optionsFrame.masterLooterLabel
    RuntimeState.mainFrame.autoLootCheck = RuntimeState.optionsFrame.autoLootCheck
    RuntimeState.mainFrame.autoLootLabel = RuntimeState.optionsFrame.autoLootLabel

    RuntimeState.optionsFrame:SetScript("OnShow", function()
        UpdateOptionsControlState()
        RuntimeState.optionsFrame.masterLooterEdit:SetText(NormalizeMasterLooterSetting(AscensionRaidRollsDB.masterLooter or "@ME"))
        RuntimeState.optionsFrame.autoLootCheck:SetChecked(AscensionRaidRollsDB.autoMasterLoot == true)
        RuntimeState.optionsFrame.muteWinnerCheck:SetChecked(AscensionRaidRollsDB.muteWinnerAnnouncement == true)
		RuntimeState.optionsFrame.hideMinimapCheck:SetChecked(AscensionRaidRollsDB.hideMinimapIcon == true)
        RuntimeState.optionsFrame.reserveModeCheck:SetChecked(DemiseRaidRollsSoftRes.IsPriorityEnabled())
        RuntimeState.optionsFrame.reserveLimitEdit:SetText(tostring(AscensionRaidRollsDB.softResLimit or 2))
        RuntimeState.optionsFrame.reserveURLEdit:SetText(AscensionRaidRollsDB.softResURL or "")
    end)
    RuntimeState.optionsFrame:Hide()
end

local function CreateUI()
    RuntimeState.mainFrame = CreateFrame("Frame", "DemiseRaidRollsFrame", UIParent)
    RuntimeState.mainFrame:SetWidth(600)
    RuntimeState.mainFrame:SetHeight(565)
    RuntimeState.mainFrame:SetFrameStrata("DIALOG")
    RuntimeState.mainFrame:SetClampedToScreen(true)
    RuntimeState.mainFrame:EnableMouse(true)
    RuntimeState.mainFrame:SetMovable(true)
    RuntimeState.mainFrame:RegisterForDrag("LeftButton")
    RuntimeState.mainFrame:SetScript("OnDragStart", function(self)
        self:StartMoving()
    end)
    RuntimeState.mainFrame:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        SaveFramePosition()
    end)

    RuntimeState.mainFrame:SetBackdrop({
        bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
        edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
        tile = true,
        tileSize = 32,
        edgeSize = 32,
        insets = { left = 11, right = 12, top = 12, bottom = 11 },
    })

    RuntimeState.mainFrame.title = RuntimeState.mainFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    RuntimeState.mainFrame.title:SetPoint("TOP", RuntimeState.mainFrame, "TOP", 0, -17)
    RuntimeState.mainFrame.title:SetText("DemiseRaidRolls")

    RuntimeState.mainFrame.menuButton = CreateFrame("Button", nil, RuntimeState.mainFrame, "UIPanelButtonTemplate")
    RuntimeState.mainFrame.menuButton:SetWidth(66)
    RuntimeState.mainFrame.menuButton:SetHeight(20)
    RuntimeState.mainFrame.menuButton:SetPoint("TOPLEFT", RuntimeState.mainFrame, "TOPLEFT", 18, -14)
    RuntimeState.mainFrame.menuButton:SetText("Menu")
    RuntimeState.mainFrame.menuButton:SetScript("OnClick", function()
        if DemiseRaidRollsMenu and DemiseRaidRollsMenu.Show then
            DemiseRaidRollsMenu.Show()
        end
    end)

    RuntimeState.mainFrame.subtitle = RuntimeState.mainFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    RuntimeState.mainFrame.subtitle:SetPoint("TOP", RuntimeState.mainFrame.title, "BOTTOM", 0, -5)
    RuntimeState.mainFrame.subtitle:SetText("First roll counts  •  Click any roll to select the winner")

    RuntimeState.mainFrame.itemSlot = CreateFrame("Button", nil, RuntimeState.mainFrame)
    RuntimeState.mainFrame.itemSlot:SetWidth(42)
    RuntimeState.mainFrame.itemSlot:SetHeight(42)
    RuntimeState.mainFrame.itemSlot:SetPoint("TOPLEFT", RuntimeState.mainFrame, "TOPLEFT", 24, -57)
    RuntimeState.mainFrame.itemSlot:EnableMouse(true)
    RuntimeState.mainFrame.itemSlot:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    RuntimeState.mainFrame.itemSlot:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
        tile = true,
        tileSize = 8,
        edgeSize = 12,
        insets = { left = 3, right = 3, top = 3, bottom = 3 },
    })
    RuntimeState.mainFrame.itemSlot:SetBackdropColor(0.05, 0.05, 0.05, 0.85)
    RuntimeState.mainFrame.itemSlot:SetBackdropBorderColor(0.5, 0.5, 0.5, 1.0)

    RuntimeState.mainFrame.itemIcon = RuntimeState.mainFrame.itemSlot:CreateTexture(nil, "ARTWORK")
    RuntimeState.mainFrame.itemIcon:SetPoint("TOPLEFT", RuntimeState.mainFrame.itemSlot, "TOPLEFT", 4, -4)
    RuntimeState.mainFrame.itemIcon:SetPoint("BOTTOMRIGHT", RuntimeState.mainFrame.itemSlot, "BOTTOMRIGHT", -4, 4)
    RuntimeState.mainFrame.itemIcon:SetTexture("Interface\\Icons\\INV_Misc_QuestionMark")

    RuntimeState.mainFrame.itemText = RuntimeState.mainFrame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    RuntimeState.mainFrame.itemText:SetPoint("TOPLEFT", RuntimeState.mainFrame.itemSlot, "TOPRIGHT", 8, -2)
    RuntimeState.mainFrame.itemText:SetWidth(245)
    RuntimeState.mainFrame.itemText:SetJustifyH("LEFT")
    RuntimeState.mainFrame.itemText:SetText("|cffaaaaaaDrop an item here|r")

    RuntimeState.mainFrame.itemHint = RuntimeState.mainFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    RuntimeState.mainFrame.itemHint:SetPoint("TOPLEFT", RuntimeState.mainFrame.itemText, "BOTTOMLEFT", 0, -5)
    RuntimeState.mainFrame.itemHint:SetWidth(245)
    RuntimeState.mainFrame.itemHint:SetJustifyH("LEFT")
    RuntimeState.mainFrame.itemHint:SetText("Drag here or Shift + Right-click an item in your bags")
    RuntimeState.mainFrame.itemHint:SetTextColor(0.65, 0.65, 0.65)

    RuntimeState.mainFrame.itemSlot:SetScript("OnReceiveDrag", function()
        CaptureCursorItem()
    end)
    RuntimeState.mainFrame.itemSlot:SetScript("OnClick", function(self, button)
        if not CanControlRolls or not CanControlRolls() then
            Print("only the current Master Looter can change the roll item.")
            return
        end

        if button == "RightButton" then
            ClearCurrentItem()
        else
            CaptureCursorItem()
        end
    end)
    RuntimeState.mainFrame.itemSlot:SetScript("OnEnter", function(self)
        if not GameTooltip then
            return
        end
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        if RuntimeState.currentItemLink then
            GameTooltip:SetHyperlink(RuntimeState.currentItemLink)
        else
            GameTooltip:SetText("Drop an item here")
            GameTooltip:AddLine("Drag an item here, or Shift + Right-click it in your bags.", 1, 1, 1, true)
        end
        GameTooltip:Show()
    end)
    RuntimeState.mainFrame.itemSlot:SetScript("OnLeave", function()
        if GameTooltip then
            GameTooltip:Hide()
        end
    end)

    RuntimeState.mainFrame.durationLabel = RuntimeState.mainFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    RuntimeState.mainFrame.durationLabel:SetPoint("TOPLEFT", RuntimeState.mainFrame, "TOPLEFT", 327, -57)
    RuntimeState.mainFrame.durationLabel:SetText("Duration")

    RuntimeState.mainFrame.durationEdit = CreateFrame("EditBox", nil, RuntimeState.mainFrame, "InputBoxTemplate")
    RuntimeState.mainFrame.durationEdit:SetWidth(42)
    RuntimeState.mainFrame.durationEdit:SetHeight(24)
    RuntimeState.mainFrame.durationEdit:SetPoint("LEFT", RuntimeState.mainFrame.durationLabel, "RIGHT", 7, 0)
    RuntimeState.mainFrame.durationEdit:SetAutoFocus(false)
    if RuntimeState.mainFrame.durationEdit.SetNumeric then
        RuntimeState.mainFrame.durationEdit:SetNumeric(true)
    end
    RuntimeState.mainFrame.durationEdit:SetMaxLetters(3)
    RuntimeState.mainFrame.durationEdit:SetText(tostring(AscensionRaidRollsDB.rollDuration or DEFAULT_ROLL_DURATION))
    RuntimeState.mainFrame.durationEdit:SetScript("OnEnterPressed", function(self)
        GetConfiguredDuration()
        self:ClearFocus()
    end)
    RuntimeState.mainFrame.durationEdit:SetScript("OnEditFocusLost", function()
        GetConfiguredDuration()
    end)

    RuntimeState.mainFrame.durationSec = RuntimeState.mainFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    RuntimeState.mainFrame.durationSec:SetPoint("LEFT", RuntimeState.mainFrame.durationEdit, "RIGHT", 4, 0)
    RuntimeState.mainFrame.durationSec:SetText("sec")

    RuntimeState.mainFrame.startRollButton = CreateFrame("Button", nil, RuntimeState.mainFrame, "UIPanelButtonTemplate")
    RuntimeState.mainFrame.startRollButton:SetWidth(92)
    RuntimeState.mainFrame.startRollButton:SetHeight(24)
    RuntimeState.mainFrame.startRollButton:SetPoint("TOPRIGHT", RuntimeState.mainFrame, "TOPRIGHT", -20, -86)
    RuntimeState.mainFrame.startRollButton:SetText("Start Rolls")
    RuntimeState.mainFrame.startRollButton:SetScript("OnClick", function()
        if RuntimeState.rollTimerActive then
            FinishTimedRoll()
        else
            StartTimedRoll()
        end
    end)


    RuntimeState.mainFrame.timerBar = CreateFrame("StatusBar", nil, RuntimeState.mainFrame)
    RuntimeState.mainFrame.timerBar:SetWidth(365)
    RuntimeState.mainFrame.timerBar:SetHeight(18)
    RuntimeState.mainFrame.timerBar:SetPoint("TOPLEFT", RuntimeState.mainFrame, "TOPLEFT", 24, -106)
    RuntimeState.mainFrame.timerBar:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar")
    RuntimeState.mainFrame.timerBar:SetMinMaxValues(0, 1)
    RuntimeState.mainFrame.timerBar:SetValue(0)
    RuntimeState.mainFrame.timerBar:SetStatusBarColor(0.20, 0.75, 0.25)

    RuntimeState.mainFrame.timerBarBg = RuntimeState.mainFrame.timerBar:CreateTexture(nil, "BACKGROUND")
    RuntimeState.mainFrame.timerBarBg:SetAllPoints(RuntimeState.mainFrame.timerBar)
    RuntimeState.mainFrame.timerBarBg:SetTexture(0.08, 0.08, 0.08, 0.85)

    RuntimeState.mainFrame.timerText = RuntimeState.mainFrame.timerBar:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    RuntimeState.mainFrame.timerText:SetPoint("CENTER", RuntimeState.mainFrame.timerBar, "CENTER", 0, 0)
    RuntimeState.mainFrame.timerText:SetText("Timer ready")

    RuntimeState.mainFrame.viewerRollText = RuntimeState.mainFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    RuntimeState.mainFrame.viewerRollText:SetWidth(390)
    RuntimeState.mainFrame.viewerRollText:SetJustifyH("CENTER")
    RuntimeState.mainFrame.viewerRollText:SetText("Your roll: |cffaaaaaawaiting for your roll|r")
    RuntimeState.mainFrame.viewerRollText:Hide()

    RuntimeState.mainFrame.minimizeButton = CreateFrame("Button", nil, RuntimeState.mainFrame, "UIPanelButtonTemplate")
    RuntimeState.mainFrame.minimizeButton:SetWidth(76)
    RuntimeState.mainFrame.minimizeButton:SetHeight(20)
    RuntimeState.mainFrame.minimizeButton:SetPoint("TOPRIGHT", RuntimeState.mainFrame, "TOPRIGHT", -40, -13)
    RuntimeState.mainFrame.minimizeButton:SetText("Minimize")
    RuntimeState.mainFrame.minimizeButton:SetScript("OnClick", function()
        AscensionRaidRollsDB.viewerMinimized = AscensionRaidRollsDB.viewerMinimized ~= true
        UpdateControlState()
    end)
    RuntimeState.mainFrame.minimizeButton:Hide()

    -- Keep Tie Break close to the roll controls instead of in the footer.
    -- It becomes available only when the selected row belongs to a valid tie.
    RuntimeState.mainFrame.tieButton = CreateFrame("Button", nil, RuntimeState.mainFrame, "UIPanelButtonTemplate")
    RuntimeState.mainFrame.tieButton:SetWidth(92)
    RuntimeState.mainFrame.tieButton:SetHeight(20)
    RuntimeState.mainFrame.tieButton:SetPoint("TOPRIGHT", RuntimeState.mainFrame, "TOPRIGHT", -20, -113)
    RuntimeState.mainFrame.tieButton:SetText("Tie Break")
    RuntimeState.mainFrame.tieButton:SetScript("OnClick", function()
        StartTieBreak()
    end)
    SetButtonEnabled(RuntimeState.mainFrame.tieButton, false)

    RuntimeState.mainFrame.optionsButton = CreateFrame("Button", nil, RuntimeState.mainFrame, "UIPanelButtonTemplate")
    RuntimeState.mainFrame.optionsButton:SetWidth(92)
    RuntimeState.mainFrame.optionsButton:SetHeight(22)
    RuntimeState.mainFrame.optionsButton:SetPoint("TOPLEFT", RuntimeState.mainFrame, "TOPLEFT", 24, -132)
    RuntimeState.mainFrame.optionsButton:SetText("Options")
    RuntimeState.mainFrame.optionsButton:SetScript("OnClick", function()
        if RuntimeState.optionsFrame:IsShown() then
            RuntimeState.optionsFrame:Hide()
        else
            RuntimeState.optionsFrame:Show()
        end
    end)

    RuntimeState.mainFrame.timersButton = CreateFrame("Button", nil, RuntimeState.mainFrame, "UIPanelButtonTemplate")
    RuntimeState.mainFrame.timersButton:SetWidth(92)
    RuntimeState.mainFrame.timersButton:SetHeight(22)
    RuntimeState.mainFrame.timersButton:SetPoint("LEFT", RuntimeState.mainFrame.optionsButton, "RIGHT", 6, 0)
    RuntimeState.mainFrame.timersButton:SetText("Timers")
    RuntimeState.mainFrame.timersButton:SetScript("OnClick", function()
        if DemiseRaidRolls.TradeTimers and DemiseRaidRolls.TradeTimers.Toggle then
            DemiseRaidRolls.TradeTimers.Toggle()
        end
    end)

    CreateOptionsFrame()

    RuntimeState.mainFrame.msCount = RuntimeState.mainFrame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    RuntimeState.mainFrame.msCount:SetPoint("TOPLEFT", RuntimeState.mainFrame, "TOPLEFT", 24, -163)
    RuntimeState.mainFrame.msCount:SetTextColor(1.0, 0.78, 0.20)
    RuntimeState.mainFrame.msCount:SetText("MS  (1-100)")

    RuntimeState.mainFrame.osCount = RuntimeState.mainFrame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    RuntimeState.mainFrame.osCount:SetPoint("TOPLEFT", RuntimeState.mainFrame, "TOPLEFT", 316, -163)
    RuntimeState.mainFrame.osCount:SetTextColor(0.35, 0.72, 1.0)
    RuntimeState.mainFrame.osCount:SetText("OS  (1-99)")

    RuntimeState.msPanel = CreateRollPanel(RuntimeState.mainFrame, "TOPLEFT", 18)
    RuntimeState.osPanel = CreateRollPanel(RuntimeState.mainFrame, "TOPLEFT", 310)

    DemiseRaidRolls.ApplyHighContrast()

    RuntimeState.mainFrame.separator = RuntimeState.mainFrame:CreateTexture(nil, "ARTWORK")
    RuntimeState.mainFrame.separator:SetTexture(1, 1, 1, 0.08)
    RuntimeState.mainFrame.separator:SetWidth(1)
    RuntimeState.mainFrame.separator:SetPoint("TOP", RuntimeState.mainFrame, "TOP", 0, -181)
    RuntimeState.mainFrame.separator:SetPoint("BOTTOM", RuntimeState.mainFrame, "BOTTOM", 0, 76)

    RuntimeState.mainFrame.winnerText = RuntimeState.mainFrame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    RuntimeState.mainFrame.winnerText:SetPoint("BOTTOM", RuntimeState.mainFrame, "BOTTOM", 0, 55)
    RuntimeState.mainFrame.winnerText:SetWidth(470)
    RuntimeState.mainFrame.winnerText:SetJustifyH("CENTER")
    RuntimeState.mainFrame.winnerText:SetText("Selected: |cff888888click a roll to choose a winner|r")

    -- Keep the four footer action buttons uniform and use the full width.
    -- Tie Break now lives directly under Start Rolls.
    local footerButtonWidth = 135
    local footerButtonHeight = 24
    local footerButtonGap = 6

    RuntimeState.mainFrame.clearButton = CreateFrame("Button", nil, RuntimeState.mainFrame, "UIPanelButtonTemplate")
    RuntimeState.mainFrame.clearButton:SetWidth(footerButtonWidth)
    RuntimeState.mainFrame.clearButton:SetHeight(footerButtonHeight)
    RuntimeState.mainFrame.clearButton:SetPoint("BOTTOMLEFT", RuntimeState.mainFrame, "BOTTOMLEFT", 18, 18)
    RuntimeState.mainFrame.clearButton:SetText("Reset")
    RuntimeState.mainFrame.clearButton:SetScript("OnClick", function()
        ResetRollSessionByController()
    end)

    RuntimeState.mainFrame.msRollButton = CreateFrame("Button", nil, RuntimeState.mainFrame, "UIPanelButtonTemplate")
    RuntimeState.mainFrame.msRollButton:SetWidth(footerButtonWidth)
    RuntimeState.mainFrame.msRollButton:SetHeight(footerButtonHeight)
    RuntimeState.mainFrame.msRollButton:SetPoint("LEFT", RuntimeState.mainFrame.clearButton, "RIGHT", footerButtonGap, 0)
    RuntimeState.mainFrame.msRollButton:SetText("Roll MS")
    RuntimeState.mainFrame.msRollButton:SetScript("OnClick", function()
        ExecutePlayerRoll(100)
    end)

    RuntimeState.mainFrame.osRollButton = CreateFrame("Button", nil, RuntimeState.mainFrame, "UIPanelButtonTemplate")
    RuntimeState.mainFrame.osRollButton:SetWidth(footerButtonWidth)
    RuntimeState.mainFrame.osRollButton:SetHeight(footerButtonHeight)
    RuntimeState.mainFrame.osRollButton:SetPoint("LEFT", RuntimeState.mainFrame.msRollButton, "RIGHT", footerButtonGap, 0)
    RuntimeState.mainFrame.osRollButton:SetText("Roll OS")
    RuntimeState.mainFrame.osRollButton:SetScript("OnClick", function()
        ExecutePlayerRoll(99)
    end)

    RuntimeState.mainFrame.tradeButton = CreateFrame("Button", nil, RuntimeState.mainFrame, "UIPanelButtonTemplate")
    RuntimeState.mainFrame.tradeButton:SetWidth(footerButtonWidth)
    RuntimeState.mainFrame.tradeButton:SetHeight(footerButtonHeight)
    RuntimeState.mainFrame.tradeButton:SetPoint("LEFT", RuntimeState.mainFrame.osRollButton, "RIGHT", footerButtonGap, 0)
    RuntimeState.mainFrame.tradeButton:SetText("Trade")
    RuntimeState.mainFrame.tradeButton:SetScript("OnClick", function()
        TradeWinner()
    end)

    RuntimeState.mainFrame.closeButton = CreateFrame("Button", nil, RuntimeState.mainFrame, "UIPanelCloseButton")
    RuntimeState.mainFrame.closeButton:SetPoint("TOPRIGHT", RuntimeState.mainFrame, "TOPRIGHT", -4, -4)

    DemiseRaidRolls.MainFrame = RuntimeState.mainFrame
    if DemiseRaidRolls.RaidCouncil and DemiseRaidRolls.RaidCouncil.AttachMainFrame then
        DemiseRaidRolls.RaidCouncil.AttachMainFrame(RuntimeState.mainFrame)
    end

    local point = AscensionRaidRollsDB.point or "CENTER"
    local relativePoint = AscensionRaidRollsDB.relativePoint or "CENTER"
    local x = AscensionRaidRollsDB.x or 0
    local y = AscensionRaidRollsDB.y or 0
    RuntimeState.mainFrame:SetPoint(point, UIParent, relativePoint, x, y)

    RuntimeState.mainFrame:SetScript("OnShow", function()
        AscensionRaidRollsDB.shown = true
    end)
    RuntimeState.mainFrame:SetScript("OnHide", function()
        AscensionRaidRollsDB.shown = false
    end)

    -- Never restore a previously visible frame at login or /reload. Opening is
    -- restricted to an explicit minimap action or an active ML roll session.
    AscensionRaidRollsDB.shown = false
    RuntimeState.mainFrame:Hide()

    UpdateItemDisplay()
    CancelRollSession()
    GetConfiguredDuration()
    UpdateUI()
end

local function AddTestRolls()
    ClearRolls()
    AddRoll("Arthas", 97, 1, 100, true)
    AddRoll("Jaina", 84, 1, 100, true)
    AddRoll("Anduin", 84, 1, 100, true)
    AddRoll("Thrall", 42, 1, 100, true)
    AddRoll("Valeera", 99, 1, 99, true)
    AddRoll("Uther", 73, 1, 99, true)
    AddRoll("Malfurion", 18, 1, 99, true)
    AddRoll("Arthas", 100, 1, 100, true)
    AddRoll("Jaina", 98, 1, 99, true)
end

local function HandleSlashCommand(message)
    message = Trim(message or "") or ""
    local lower = string.lower(message)

    if lower == "" or lower == "toggle" then
        ToggleMainFrame()
    elseif lower == "show" then
        RuntimeState.mainFrame:Show()
    elseif lower == "hide" then
        RuntimeState.mainFrame:Hide()
    elseif lower == "roll" or lower == "rollui" or lower == "panel" then
        RuntimeState.mainFrame:Show()
    elseif lower == "ms" then
        ExecutePlayerRoll(100)
    elseif lower == "os" then
        ExecutePlayerRoll(99)
    elseif lower == "clear" or lower == "reset" then
        local resetOK, resetMode = ResetRollSessionByController()
        if resetOK then
            if resetMode == "local" then
                Print("local roll log cleared.")
            else
                Print("shared roll list and active timer cleared.")
            end
        end
    elseif lower == "test" then
        AddTestRolls()
        RuntimeState.mainFrame:Show()
        Print("test data loaded. Jaina and Anduin are tied at 84 MS; select either row to test Tie Break.")
    elseif lower == "announce" then
        AnnounceWinner()
    elseif lower == "tie" or lower == "tiebreak" then
        StartTieBreak()
    elseif lower == "trade" then
        TradeWinner()
    elseif lower:match("^ml%s+.+$") then
        local value = Trim(message:match("^%S+%s+(.+)$") or "")
        value = NormalizeMasterLooterSetting(value)
        AscensionRaidRollsDB.masterLooter = value
        if RuntimeState.mainFrame and RuntimeState.mainFrame.masterLooterEdit then
            RuntimeState.mainFrame.masterLooterEdit:SetText(value)
        end
        Print("Master Looter recipient set to " .. tostring(ResolveMasterLooterTarget()) .. ".")
    elseif lower == "autoloot on" then
        SetAutoMasterLootEnabled(true)
    elseif lower == "autoloot off" then
        SetAutoMasterLootEnabled(false)
    elseif lower == "start" then
        StartTimedRoll()
    elseif lower:match("^duration%s+%d+$") then
        if not CanControlRolls or not CanControlRolls() then
            Print("only the current Master Looter can change the shared roll duration.")
            return
        end
        local value = tonumber(lower:match("^duration%s+(%d+)$"))
        if value then
            AscensionRaidRollsDB.rollDuration = value
            GetConfiguredDuration()
            Print("roll duration set to " .. tostring(AscensionRaidRollsDB.rollDuration) .. " seconds.")
        end
    elseif lower == "version" or lower == "ver" then
        Print("version " .. tostring(ADDON_VERSION) .. ". Latest version seen from other ARR users this session: " .. tostring(latestSeenVersion) .. ".")
        BroadcastVersion()
    elseif lower == "options" then
        if RuntimeState.optionsFrame:IsShown() then
            RuntimeState.optionsFrame:Hide()
        else
            RuntimeState.optionsFrame:Show()
        end
    elseif lower == "lootreset" then
        ClearLootHistory()
    elseif lower == "debug" then
        Print("RANDOM_ROLL_RESULT = " .. tostring(RANDOM_ROLL_RESULT))
        Print("pattern = " .. tostring(RuntimeState.rollPattern))
        Print("raid members = " .. tostring(GetNumRaidMembers and GetNumRaidMembers() or 0))
        Print("item = " .. tostring(RuntimeState.currentItemLink))
        Print("timer active = " .. tostring(RuntimeState.rollTimerActive) .. ", session open = " .. tostring(RuntimeState.rollSessionOpen))
        Print("sync session = " .. tostring(syncSessionID) .. ", owner = " .. tostring(syncOwner) .. ", controller = " .. tostring(CanControlRolls and CanControlRolls() or false))
        local actualMaster, lootMethod = nil, nil
        if GetActualMasterLooterName then
            actualMaster, lootMethod = GetActualMasterLooterName()
        end
        Print("active Master Looter = " .. tostring(actualMaster) .. ", loot method = " .. tostring(lootMethod))
        Print("Master Loot recipient = " .. tostring(AscensionRaidRollsDB.masterLooter or "@ME") .. ", auto = " .. tostring(AscensionRaidRollsDB.autoMasterLoot == true))
        local winner = GetWinner()
        if winner then
            Print("top valid roll = " .. winner.name .. " / " .. winner.roll .. " / " .. winner.type)
        else
            Print("top valid roll = none")
        end
        Print("top winner slots = " .. tostring(RuntimeState.currentTopRolls or 1))
        if RuntimeState.currentItemLink then
            local scannedTop = DemiseRaidRolls.TradeableItems.Count(RuntimeState.currentItemLink, RuntimeState.currentItemID, true)
            Print("Top X rescan result = " .. tostring(scannedTop))
        end
        Print("tie-break active = " .. tostring(RuntimeState.tieBreakActive) .. ", type = " .. tostring(RuntimeState.tieBreakType) .. ", round = " .. tostring(RuntimeState.tieBreakRound))
        if RuntimeState.selectedRoll then
            Print("selected = " .. RuntimeState.selectedRoll.name .. " / " .. RuntimeState.selectedRoll.roll .. " / " .. RuntimeState.selectedRoll.type)
        else
            Print("selected = none")
        end
    else
        Print("commands: /rr, /rr show, /rr hide, /rr options, /rr ms, /rr os, /rr clear, /rr lootreset, /rr test, /rr start, /rr duration <sec>, /rr announce, /rr tie, /rr trade, /rr ml <@ME|player>, /rr autoloot <on|off>, /rr version, /rr debug")
    end
end

local eventFrame = CreateFrame("Frame")
eventFrame:RegisterEvent("ADDON_LOADED")
eventFrame:RegisterEvent("CHAT_MSG_ADDON")
eventFrame:RegisterEvent("CHAT_MSG_SYSTEM")
eventFrame:RegisterEvent("RAID_ROSTER_UPDATE")
eventFrame:RegisterEvent("GUILD_ROSTER_UPDATE")
eventFrame:RegisterEvent("PARTY_LOOT_METHOD_CHANGED")
eventFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
eventFrame:RegisterEvent("TRADE_SHOW")
eventFrame:RegisterEvent("TRADE_CLOSED")
eventFrame:RegisterEvent("LOOT_OPENED")
eventFrame:RegisterEvent("LOOT_SLOT_CLEARED")
eventFrame:RegisterEvent("LOOT_CLOSED")
eventFrame:RegisterEvent("LOOT_BIND_CONFIRM")

eventFrame:SetScript("OnEvent", function(self, event, ...)
    if event == "ADDON_LOADED" then
        local loadedAddon = ...
        if loadedAddon ~= ADDON_NAME then
            return
        end

        AscensionRaidRollsDB = AscensionRaidRollsDB or {}
        if AscensionRaidRollsDB.masterLooter == nil then
            AscensionRaidRollsDB.masterLooter = "@ME"
        end
        if AscensionRaidRollsDB.autoMasterLoot == nil then
            AscensionRaidRollsDB.autoMasterLoot = false
        end
        if AscensionRaidRollsDB.muteWinnerAnnouncement == nil then
            AscensionRaidRollsDB.muteWinnerAnnouncement = false
        end
        AscensionRaidRollsDB.highContrast = true
        if AscensionRaidRollsDB.msosPlusOneEnabled == nil then
            AscensionRaidRollsDB.msosPlusOneEnabled = false
        end
        if AscensionRaidRollsDB.reservePriorityEnabled == nil then
            AscensionRaidRollsDB.reservePriorityEnabled = false
        end
        if AscensionRaidRollsDB.softResLimit == nil then
            AscensionRaidRollsDB.softResLimit = 2
        end
        if AscensionRaidRollsDB.softResURL == nil then
            AscensionRaidRollsDB.softResURL = ""
        end
        if type(AscensionRaidRollsDB.reserveData) ~= "table" then
            AscensionRaidRollsDB.reserveData = { metadata = {}, roster = {}, byItem = {}, hardItems = {} }
        end
        if type(AscensionRaidRollsDB.lootHistory) ~= "table" then
            AscensionRaidRollsDB.lootHistory = { MS = {}, OS = {} }
        elseif type(AscensionRaidRollsDB.lootHistory.MS) ~= "table" or type(AscensionRaidRollsDB.lootHistory.OS) ~= "table" then
            local legacyHistory = AscensionRaidRollsDB.lootHistory
            local migratedHistory = { MS = {}, OS = {} }
            local playerKey, count
            for playerKey, count in pairs(legacyHistory) do
                if type(count) == "number" and count > 0 then
                    migratedHistory.MS[playerKey] = count
                end
            end
            AscensionRaidRollsDB.lootHistory = migratedHistory
        end

        -- Some 3.3.5-derived clients expose prefix registration while others
        -- deliver CHAT_MSG_ADDON without it. Use it when available only.
        if RegisterAddonMessagePrefix then
            pcall(RegisterAddonMessagePrefix, SYNC_PREFIX)
        end

        RuntimeState.rollPattern, RuntimeState.rollCaptureOrder = BuildRollPattern()
        RefreshRaidMembers()
        CreateUI()
        if DemiseRaidRollsMenu and DemiseRaidRollsMenu.Create then
            DemiseRaidRollsMenu.Create()
            DemiseRaidRollsMenu.ResetSession()
        end
        DemiseRaidRolls.CreateMinimapButton(ToggleMainFrame)
        InstallBagItemShortcut()
        DemiseRaidRollsSoftRes.InstallTooltipHooks()
        UpdateControlState()

        SLASH_DEMISERAIDROLLS1 = "/rr"
        SLASH_DEMISERAIDROLLS2 = "/raidrolls"
        SlashCmdList["DEMISERAIDROLLS"] = HandleSlashCommand

        Print("loaded. Choose Raid Rolls or Raid Council from the module menu.")

        BroadcastVersion()

        if (GetNumRaidMembers and GetNumRaidMembers() or 0) > 0 and CanControlRolls and CanControlRolls() then
            BroadcastRaidCouncilMode("RAID")
        elseif (GetNumRaidMembers and GetNumRaidMembers() or 0) > 0 then
            RequestSyncState()
        end

    elseif event == "CHAT_MSG_ADDON" then
        local prefix, message, channel, sender = ...
        HandleAddonSync(prefix, message, channel, sender)

    elseif event == "RAID_ROSTER_UPDATE" then
        RefreshRaidMembers()
        ClearRemoteRaidStateOutsideRaid()
        UpdateUI()
        BroadcastVersion()
        if CanControlRolls and CanControlRolls() then
            BroadcastRaidCouncilMode("RAID")
        elseif not RuntimeState.rollSessionStarted and not syncStateRequested then
            RequestSyncState()
        end

    elseif event == "GUILD_ROSTER_UPDATE" then
        BroadcastVersion()

    elseif event == "PARTY_LOOT_METHOD_CHANGED" then
        RefreshRaidMembers()
        UpdateUI()
        if CanControlRolls and CanControlRolls() then
            BroadcastRaidCouncilMode("RAID")
        elseif not syncStateRequested then
            RequestSyncState()
        end

    elseif event == "PLAYER_ENTERING_WORLD" then
        RefreshRaidMembers()
        ClearRemoteRaidStateOutsideRaid()
        UpdateUI()
        BroadcastVersion()
        if (GetNumRaidMembers and GetNumRaidMembers() or 0) > 0 and CanControlRolls and CanControlRolls() then
            BroadcastRaidCouncilMode("RAID")
        elseif (GetNumRaidMembers and GetNumRaidMembers() or 0) > 0 and not RuntimeState.rollSessionStarted and not syncStateRequested then
            RequestSyncState()
        end

    elseif event == "TRADE_SHOW" then
        PlacePendingTradeItem()
    elseif event == "TRADE_CLOSED" then
        ClearPendingTradeItem()
    elseif event == "LOOT_OPENED" then
        StartAutoMasterLoot()
    elseif event == "LOOT_SLOT_CLEARED" then
        HandleAutoMasterLootSlotCleared()
    elseif event == "LOOT_BIND_CONFIRM" then
        local slot = ...
        HandleAutoMasterLootBindConfirm(slot)
    elseif event == "LOOT_CLOSED" then
        StopAutoMasterLoot()
    elseif event == "CHAT_MSG_SYSTEM" then
        if not RuntimeState.mainFrame then
            return
        end

        local message = ...
        if type(message) ~= "string" then
            return
        end

        -- During any remote synchronized session, the Master Looter is
        -- authoritative. Viewers ignore their local CHAT_MSG_SYSTEM copy and
        -- only display ROLL messages accepted by the host. This remains true
        -- after the timer closes, preventing late local rolls from appearing.
        -- With no remote session (for example when the ML does not use ARR),
        -- the viewer falls back to local roll tracking instead.
        if IsRemoteSyncedSession and IsRemoteSyncedSession() then
            return
        end

        local playerName, roll, minimum, maximum = ParseRollMessage(message)
        if playerName and roll and minimum and maximum then
            AddRoll(playerName, roll, minimum, maximum, false)
        end
    end
end)


eventFrame:SetScript("OnUpdate", function(self, elapsed)
    if RuntimeState.rollTimerActive then
        RuntimeState.timerAccumulator = RuntimeState.timerAccumulator + (elapsed or 0)
        if RuntimeState.timerAccumulator >= 0.05 then
            RuntimeState.timerAccumulator = 0
            UpdateRollTimer()
        end
    end

    if RuntimeState.autoMasterLootProcessing then
        UpdateAutoMasterLoot(elapsed)
    end
end)
    rollType = rollType == "OS" and "OS" or "MS"
