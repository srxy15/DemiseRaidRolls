-- Shared addon namespaces. This file must be loaded first.
DemiseRaidRolls = DemiseRaidRolls or {}
DemiseRaidRollsSoftRes = DemiseRaidRollsSoftRes or {}
DemiseRaidRolls.GITHUB_URL = "https://github.com/LaSainteChips/AscensionRaidLootCompanion"
DemiseRaidRolls.OFFICIAL_VERSION = "2.0.3"
DemiseRaidRolls.TEST_BUILD = "11"

-- Blizzard's 3.3.5a class palette, independent from CoA/custom class tables.
-- Source: wowgaming/3.3.5-interface-files, Constants.lua (RAID_CLASS_COLORS).
local classColors = {
	WARRIOR = { r = 0.78, g = 0.61, b = 0.43 },
	PALADIN = { r = 0.96, g = 0.55, b = 0.73 },
	HUNTER = { r = 0.67, g = 0.83, b = 0.45 },
	ROGUE = { r = 1.0, g = 0.96, b = 0.41 },
	PRIEST = { r = 1.0, g = 1.0, b = 1.0 },
	DEATHKNIGHT = { r = 0.77, g = 0.12, b = 0.23 },
	SHAMAN = { r = 0.0, g = 0.44, b = 0.87 },
	MAGE = { r = 0.41, g = 0.8, b = 0.94 },
	WARLOCK = { r = 0.58, g = 0.51, b = 0.79 },
	DRUID = { r = 1.0, g = 0.49, b = 0.04 },
}

function DemiseRaidRolls.GetClassColor(classFile)
	local color = classFile and classColors[classFile]
	if color then return color.r, color.g, color.b end
	return 1, 1, 1
end

function DemiseRaidRolls.GetClassColorCode(classFile)
	local r, g, b = DemiseRaidRolls.GetClassColor(classFile)
	return string.format("|cff%02x%02x%02x", math.floor(r * 255), math.floor(g * 255), math.floor(b * 255))
end

function DemiseRaidRolls.GetVersion()
	local version = DemiseRaidRolls.OFFICIAL_VERSION or "0.0.0"
	local testBuild = tostring(DemiseRaidRolls.TEST_BUILD or "")
	if testBuild ~= "" then return version .. "." .. testBuild end
	return version
end

local function TroubleshootingBoolean(value)
	return value and "Yes" or "No"
end

local function TroubleshootingMasterLooter()
	if not GetLootMethod then return "Unavailable" end
	local method, partyIndex, raidIndex = GetLootMethod()
	if method ~= "master" then return "None (loot method: " .. tostring(method or "unknown") .. ")" end
	if raidIndex and raidIndex > 0 and GetRaidRosterInfo then return tostring(GetRaidRosterInfo(raidIndex) or "Unknown") end
	if partyIndex == 0 then return tostring(UnitName("player") or "Unknown") end
	if partyIndex and partyIndex > 0 then return tostring(UnitName("party" .. partyIndex) or "Unknown") end
	return "Unknown"
end

local function TroubleshootingGroupComposition()
	local members = {}
	local raidCount = GetNumRaidMembers and GetNumRaidMembers() or 0
	local partyCount = GetNumPartyMembers and GetNumPartyMembers() or 0
	local index
	if raidCount > 0 and GetRaidRosterInfo then
		for index = 1, raidCount do
			local name, _, subgroup, _, class = GetRaidRosterInfo(index)
			if name then members[#members + 1] = tostring(name) .. " (" .. tostring(class or "Unknown") .. ", group " .. tostring(subgroup or "?") .. ")" end
		end
		return "Raid (" .. tostring(raidCount) .. "): " .. table.concat(members, ", ")
	end
	local playerName = UnitName and UnitName("player") or "Unknown"
	members[#members + 1] = tostring(playerName) .. " (player)"
	for index = 1, partyCount do
		local unit = "party" .. index
		local name = UnitName and UnitName(unit)
		local class = UnitClass and UnitClass(unit)
		if name then members[#members + 1] = tostring(name) .. " (" .. tostring(class or "Unknown") .. ")" end
	end
	if partyCount > 0 then return "Party (" .. tostring(partyCount + 1) .. "): " .. table.concat(members, ", ") end
	return "Solo: " .. members[1]
end

function DemiseRaidRolls.BuildTroubleshootingReport()
	local db = AscensionRaidRollsDB or {}
	local state = DemiseRaidRolls.RuntimeState or {}
	local council = DemiseRaidCouncil
	local menu = DemiseRaidRollsMenu
	local version = DemiseRaidRolls.GetVersion and DemiseRaidRolls.GetVersion() or "Unknown"
	local activeModule = menu and menu.GetActiveModule and menu.GetActiveModule() or nil
	activeModule = activeModule or (db.raidCouncilEnabled and "council" or "rolls")
	local lines = {
		"DemiseRaidRolls - Troubleshooting Report",
		"Addon version: " .. tostring(version),
		"Active module: " .. (activeModule == "council" and "Raid Council" or "Raid Rolls"),
		"Character: " .. tostring(UnitName and UnitName("player") or "Unknown"),
		"Detected Master Looter: " .. TroubleshootingMasterLooter(),
		"Group composition: " .. TroubleshootingGroupComposition(),
		"",
	}
	if activeModule == "council" then
		lines[#lines + 1] = "Session state: " .. (council and council.started and "Council rolls active" or "Council rolls inactive")
		lines[#lines + 1] = "Active/queued items: " .. tostring(council and type(council.items) == "table" and #council.items or 0)
		lines[#lines + 1] = "Council members: " .. tostring(council and council.CouncilCount and council:CouncilCount() or 0)
		lines[#lines + 1] = "Options: Auto Loot to ML=" .. TroubleshootingBoolean(db.autoMasterLoot)
			.. " | Mute winner announcement=" .. TroubleshootingBoolean(db.muteWinnerAnnouncement)
			.. " | Trade winner on announce=" .. TroubleshootingBoolean(db.councilTradeOnAnnounce)
	else
		lines[#lines + 1] = "Session state: " .. (state.rollTimerActive and "Roll active" or (state.rollSessionOpen and "Roll session open" or "Roll session closed"))
		lines[#lines + 1] = "Current item: " .. tostring(state.currentItemLink or "None")
		lines[#lines + 1] = "Active rolls: " .. tostring(type(state.rollsMS) == "table" and #state.rollsMS or 0) .. " MS | " .. tostring(type(state.rollsOS) == "table" and #state.rollsOS or 0) .. " OS"
		lines[#lines + 1] = "Options: MS/OS+1=" .. TroubleshootingBoolean(db.msosPlusOneEnabled)
			.. " | SR priority=" .. TroubleshootingBoolean(db.reservePriorityEnabled)
			.. " | Auto Loot to ML=" .. TroubleshootingBoolean(db.autoMasterLoot)
			.. " | Mute winner announcement=" .. TroubleshootingBoolean(db.muteWinnerAnnouncement)
	end
	lines[#lines + 1] = ""
	lines[#lines + 1] = "Issue description:"
	lines[#lines + 1] = "[Describe what happened and what you expected.]"
	lines[#lines + 1] = ""
	lines[#lines + 1] = "Steps to reproduce:"
	lines[#lines + 1] = "1. "
	lines[#lines + 1] = "2. "
	lines[#lines + 1] = "3. "
	lines[#lines + 1] = ""
	lines[#lines + 1] = "Lua error (paste the complete error below):"
	lines[#lines + 1] = "[No Lua error / paste error here]"
	return table.concat(lines, "\n"), #lines
end

function DemiseRaidRolls.ShowTroubleshootingReport()
	local frame = DemiseRaidRolls.troubleshootingFrame
	if not frame then
		frame = CreateFrame("Frame", "DemiseRaidRollsTroubleshootingFrame", UIParent)
		frame:SetWidth(650); frame:SetHeight(500); frame:SetPoint("CENTER"); frame:SetFrameStrata("FULLSCREEN_DIALOG")
		frame:SetClampedToScreen(true); frame:EnableMouse(true); frame:SetMovable(true); frame:RegisterForDrag("LeftButton")
		frame:SetScript("OnDragStart", function(self) self:StartMoving() end)
		frame:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end)
		frame:SetBackdrop({ bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background", edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border", tile = true, tileSize = 32, edgeSize = 32, insets = { left = 11, right = 12, top = 12, bottom = 11 } })
		local title = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
		title:SetPoint("TOP", 0, -18); title:SetText("Troubleshooting Report")
		local help = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
		help:SetPoint("TOPLEFT", 28, -48); help:SetText("Press Ctrl+C to copy this report, then send it with a screenshot if possible.")
		local close = CreateFrame("Button", nil, frame, "UIPanelCloseButton"); close:SetPoint("TOPRIGHT", -4, -4)
		local scroll = CreateFrame("ScrollFrame", nil, frame, "UIPanelScrollFrameTemplate")
		scroll:SetPoint("TOPLEFT", 28, -70); scroll:SetPoint("BOTTOMRIGHT", -48, 54)
		local edit = CreateFrame("EditBox", nil, scroll)
		edit:SetWidth(555); edit:SetMultiLine(true); edit:SetAutoFocus(false); edit:SetFontObject("GameFontHighlightSmall")
		edit:SetTextInsets(8, 8, 8, 8)
		edit:SetBackdrop({ bgFile = "Interface\\Tooltips\\UI-Tooltip-Background", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", tile = true, tileSize = 16, edgeSize = 8, insets = { left = 2, right = 2, top = 2, bottom = 2 } })
		edit:SetBackdropColor(0.02, 0.02, 0.02, 0.98); edit:SetBackdropBorderColor(0.5, 0.5, 0.5, 1)
		edit:SetScript("OnEscapePressed", function(self) self:ClearFocus(); frame:Hide() end)
		scroll:SetScrollChild(edit)
		local selectButton = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
		selectButton:SetWidth(150); selectButton:SetHeight(24); selectButton:SetPoint("BOTTOM", 0, 22); selectButton:SetText("Select All")
		selectButton:SetScript("OnClick", function() edit:SetFocus(); edit:HighlightText() end)
		frame.edit = edit
		DemiseRaidRolls.troubleshootingFrame = frame
	end
	local report, lineCount = DemiseRaidRolls.BuildTroubleshootingReport()
	frame.edit:SetHeight(math.max(360, (lineCount or 1) * 16 + 20))
	frame.edit:SetText(report)
	frame:Show()
	frame.edit:SetFocus()
	frame.edit:HighlightText()
end

SLASH_ARLCTROUBLESHOOT1 = "/arlctroubleshoot"
SlashCmdList["ARLCTROUBLESHOOT"] = function()
	DemiseRaidRolls.ShowTroubleshootingReport()
end
