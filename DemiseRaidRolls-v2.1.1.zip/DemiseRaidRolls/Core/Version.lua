-- Version comparison is independent from the raid-roll runtime.
DemiseRaidRolls.Version = DemiseRaidRolls.Version or {}

function DemiseRaidRolls.Version.Parse(version)
    if type(version) ~= "string" then
        return 0, 0, 0, 0
    end
    local major, minor, patch, test = version:match("^(%d+)%.(%d+)%.(%d+)%.?(%d*)")
    return tonumber(major) or 0, tonumber(minor) or 0, tonumber(patch) or 0, tonumber(test) or 0
end

function DemiseRaidRolls.Version.IsNewer(candidate, current)
    local c1, c2, c3, c4 = DemiseRaidRolls.Version.Parse(candidate)
    local a1, a2, a3, a4 = DemiseRaidRolls.Version.Parse(current)
    if c1 ~= a1 then return c1 > a1 end
    if c2 ~= a2 then return c2 > a2 end
    if c3 ~= a3 then return c3 > a3 end
    return c4 > a4
end
