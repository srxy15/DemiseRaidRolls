DemiseRaidRolls.RuntimeState = DemiseRaidRolls.RuntimeState or {
    rollsMS = {}, rollsOS = {}, raidMembers = {}, firstRollByPlayer = {}, sequence = 0,
    minimapDragging = false, currentTopRolls = 1,
    awardedPlayersForRoll = {}, currentRollAwardOrder = {},
    syncedLootHistory = { MS = {}, OS = {} }, syncedPlusOneEnabled = false,
    syncedLootHistoryRevision = 0,
    autoMasterLootProcessing = false, autoMasterLootAccumulator = 0,
    autoMasterLootWaiting = false, autoMasterLootWaitingSince = 0,
    autoMasterLootAssignedCount = 0,
    rollTimerActive = false, rollSessionStarted = false, rollSessionOpen = true,
    rollStartTime = 0, rollEndTime = 0, activeDuration = 15,
    timerAlerted = {}, timerAccumulator = 0,
    tieBreakActive = false, tieBreakPlayers = {}, tieBreakRoundRolls = {}, tieBreakRound = 0,
}
