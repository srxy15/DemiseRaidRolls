DemiseRaidRollsMenu = DemiseRaidRollsMenu or {}
local Menu = DemiseRaidRollsMenu
Menu.sessionModuleChosen = false
Menu.activeModule = nil

local function Version()
	return (DemiseRaidRolls.GetVersion and DemiseRaidRolls.GetVersion()) or "2.1.1"
end

local function GoldButton(parent, width, text)
	local button = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
	button:SetWidth(width)
	button:SetHeight(24)
	button:SetText(text)
	if button:GetFontString() then button:GetFontString():SetTextColor(1.0, 0.82, 0.15) end
	return button
end

local function CanChooseModule()
	if DemiseRaidRolls and DemiseRaidRolls.RaidCouncil and DemiseRaidRolls.RaidCouncil.CanManage then
		return DemiseRaidRolls.RaidCouncil.CanManage()
	end
	return not (GetNumRaidMembers and GetNumRaidMembers() > 0)
end

function Menu.Refresh()
	local frame = Menu.frame
	if not frame then return end
	local council = DemiseRaidRolls and DemiseRaidRolls.RaidCouncil
	local canChoose = CanChooseModule()
	local synchronized = council and council.IsModeSynchronized and council.IsModeSynchronized()
	local councilActive = council and council.IsEnabled and council.IsEnabled()
	local rollsEnabled = canChoose or not synchronized or not councilActive
	local councilEnabled = canChoose or (synchronized and councilActive)
	if rollsEnabled then frame.rollsButton:Enable() else frame.rollsButton:Disable() end
	if councilEnabled then frame.councilButton:Enable() else frame.councilButton:Disable() end
	frame.rollsButton:SetAlpha(rollsEnabled and 1 or 0.45)
	frame.councilButton:SetAlpha(councilEnabled and 1 or 0.45)
	frame.help:SetText(canChoose and "Choose a loot distribution module" or (synchronized and "The Master Looter controls the active raid module" or "Raid Rolls is available in local fallback mode"))
end

function Menu.Select(moduleName)
	local council = DemiseRaidRolls and DemiseRaidRolls.RaidCouncil
	if not council or not council.SetEnabled then
		Menu.Refresh()
		return false
	end

	local councilEnabled = moduleName == "council"
	if not CanChooseModule() then
		local synchronized = council.IsModeSynchronized and council.IsModeSynchronized()
		if synchronized and council.IsEnabled() == councilEnabled then
			Menu.sessionModuleChosen = true
			Menu.activeModule = moduleName
			Menu.Close()
			return true
		end
		if not synchronized and not councilEnabled then
			Menu.sessionModuleChosen = true
			Menu.activeModule = "rolls"
			Menu.Hide()
			if DemiseRaidCouncil and DemiseRaidCouncil.frame then DemiseRaidCouncil.frame:Hide() end
			if DemiseRaidCouncil and DemiseRaidCouncil.rframe then DemiseRaidCouncil.rframe:Hide() end
			if DemiseRaidRolls and DemiseRaidRolls.MainFrame then DemiseRaidRolls.MainFrame:Show() end
			return true
		end
		Menu.Refresh()
		return false
	end

	if council.SetEnabled(councilEnabled) == false then return false end
	Menu.sessionModuleChosen = true
	Menu.activeModule = moduleName
	if DemiseRaidRolls.BroadcastRaidCouncilMode and GetNumRaidMembers and GetNumRaidMembers() > 0 then
		DemiseRaidRolls.BroadcastRaidCouncilMode("RAID")
	end
	if Menu.frame then Menu.frame:Hide() end
	return true
end

function Menu.Show()
	if not Menu.frame then return end
	if DemiseRaidRollsOptionsFrame then DemiseRaidRollsOptionsFrame:Hide() end
	if DemiseRaidCouncil and DemiseRaidCouncil.optionsFrame then DemiseRaidCouncil.optionsFrame:Hide() end
	if DemiseRaidRolls and DemiseRaidRolls.MainFrame then DemiseRaidRolls.MainFrame:Hide() end
	if DemiseRaidCouncil and DemiseRaidCouncil.frame then DemiseRaidCouncil.frame:Hide() end
	if DemiseRaidCouncil and DemiseRaidCouncil.rframe then DemiseRaidCouncil.rframe:Hide() end
	Menu.Refresh()
	Menu.frame:Show()
end

function Menu.Hide()
	if Menu.frame then Menu.frame:Hide() end
end

function Menu.Close()
	Menu.Hide()
	if not Menu.sessionModuleChosen then return end
	local council = DemiseRaidRolls and DemiseRaidRolls.RaidCouncil
	local synchronized = council and council.IsModeSynchronized and council.IsModeSynchronized()
	if council and council.IsEnabled and council.IsEnabled() and (CanChooseModule() or synchronized) then
		if DemiseRaidCouncil and DemiseRaidCouncil.frame then
			DemiseRaidCouncil.frame:Show()
			DemiseRaidCouncil:RefreshCouncil()
		end
		if DemiseRaidCouncil and DemiseRaidCouncil.started and DemiseRaidCouncil.ShowRaiderList then
			DemiseRaidCouncil:ShowRaiderList()
		end
	elseif DemiseRaidRolls and DemiseRaidRolls.MainFrame then
		DemiseRaidRolls.MainFrame:Show()
	end
end

function Menu.MarkModuleChosen(moduleName)
	Menu.sessionModuleChosen = true
	if moduleName == "rolls" or moduleName == "council" then
		Menu.activeModule = moduleName
	end
end

function Menu.HasSessionModule()
	return Menu.sessionModuleChosen == true
end

function Menu.GetActiveModule()
	if not Menu.sessionModuleChosen then return nil end
	return Menu.activeModule
end

function Menu.ResetSession()
	Menu.sessionModuleChosen = false
	Menu.activeModule = nil
	Menu.Hide()
	if DemiseRaidRolls and DemiseRaidRolls.MainFrame then DemiseRaidRolls.MainFrame:Hide() end
	if DemiseRaidCouncil and DemiseRaidCouncil.frame then DemiseRaidCouncil.frame:Hide() end
	if DemiseRaidCouncil and DemiseRaidCouncil.rframe then DemiseRaidCouncil.rframe:Hide() end
end

function Menu.Create()
	if Menu.frame then return Menu.frame end
	local frame = CreateFrame("Frame", "DemiseRaidRollsMenuFrame", UIParent)
	frame:SetWidth(390)
	frame:SetHeight(205)
	frame:SetPoint("CENTER", UIParent, "CENTER", 0, 80)
	frame:SetFrameStrata("DIALOG")
	frame:SetClampedToScreen(true)
	frame:SetBackdrop({
		bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
		edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
		tile = true, tileSize = 32, edgeSize = 32,
		insets = { left = 11, right = 12, top = 12, bottom = 11 },
	})
	frame:EnableMouse(true)
	frame:SetMovable(true)
	frame:RegisterForDrag("LeftButton")
	frame:SetScript("OnDragStart", function(self) self:StartMoving() end)
	frame:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end)

	local title = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
	title:SetPoint("TOP", 0, -22)
	title:SetText("DemiseRaidRolls")

	local author = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	author:SetPoint("TOP", title, "BOTTOM", 0, -5)
	author:SetText("by LaSainteChips")

	local version = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	version:SetPoint("TOP", author, "BOTTOM", 0, -3)
	version:SetText("Version " .. tostring(Version()))
	version:SetTextColor(0.72, 0.72, 0.72)

	local help = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	help:SetPoint("TOP", version, "BOTTOM", 0, -10)
	help:SetTextColor(0.72, 0.72, 0.72)
	frame.help = help

	local rolls = GoldButton(frame, 145, "Raid Rolls")
	rolls:SetPoint("BOTTOMLEFT", 42, 55)
	rolls:SetScript("OnClick", function() Menu.Select("rolls") end)
	frame.rollsButton = rolls

	local council = GoldButton(frame, 145, "Raid Council")
	council:SetPoint("BOTTOMRIGHT", -42, 55)
	council:SetScript("OnClick", function() Menu.Select("council") end)
	frame.councilButton = council

	local troubleshooting = GoldButton(frame, 145, "Troubleshooting")
	troubleshooting:SetPoint("BOTTOMLEFT", 42, 20)
	troubleshooting:SetScript("OnClick", function()
		DemiseRaidRolls.ShowTroubleshootingReport()
	end)
	frame.troubleshootingButton = troubleshooting

	local checkVersion = GoldButton(frame, 145, "Check Version")
	checkVersion:SetPoint("BOTTOMRIGHT", -42, 20)
	checkVersion:SetScript("OnClick", function()
		if DemiseRaidRolls and DemiseRaidRolls.CheckVersion then
			DemiseRaidRolls.CheckVersion()
		end
	end)
	frame.checkVersionButton = checkVersion

	local close = CreateFrame("Button", nil, frame, "UIPanelCloseButton")
	close:SetPoint("TOPRIGHT", -4, -4)
	close:SetScript("OnClick", Menu.Close)

	Menu.frame = frame
	Menu.Refresh()
	frame:Hide()
	return frame
end
