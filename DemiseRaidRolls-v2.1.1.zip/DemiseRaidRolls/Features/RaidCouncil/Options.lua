local A = DemiseRaidCouncil
local BACKDROP = {
    bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
    edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
    tile = true, tileSize = 32, edgeSize = 32,
    insets = { left = 11, right = 12, top = 12, bottom = 11 },
}

local function DB()
    AscensionRaidRollsDB = AscensionRaidRollsDB or {}
    return AscensionRaidRollsDB
end

function A:IsHighContrast()
    return true
end

function A:SecondaryTextColor()
	return 1, 1, 1
end

function A:ChoiceTextColor(choice)
    if A:IsHighContrast() then
        if choice == "BiS" then return 1.0, 0.90, 0.20 end
        if choice == "Upgrade" then return 0.35, 1.0, 0.50 end
        if choice == "Offspec" then return 0.50, 0.82, 1.0 end
		if choice == "Pass" then return 1.0, 0.35, 0.35 end
    end
    local color = A.CHOICE_COLOR[choice] or { 0.8, 0.8, 0.8 }
    return color[1], color[2], color[3]
end

local function StyleEditBox(edit)
    edit:SetBackdrop({ bgFile = "Interface\\Tooltips\\UI-Tooltip-Background", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", tile = true, tileSize = 16, edgeSize = 8, insets = { left = 2, right = 2, top = 2, bottom = 2 } })
    edit:SetBackdropColor(0.03, 0.03, 0.03, 0.96); edit:SetBackdropBorderColor(0.45, 0.45, 0.45, 1)
    if edit.SetTextInsets then edit:SetTextInsets(7, 7, 0, 0) end
    edit:SetFontObject("GameFontHighlightSmall")
end

function A:ApplyHighContrast()
    local enabled = true
    if A.frame then
        A.frame:SetBackdropColor(1, 1, 1, enabled and 1 or 0.78)
        if A.frame.panel then
            A.frame.panel:SetBackdropColor(0.035, 0.035, 0.035, enabled and 0.96 or 0.72)
            local border = enabled and 0.72 or 0.45
            A.frame.panel:SetBackdropBorderColor(border, border, border, 1)
        end
    end
    if A.optionsFrame then A.optionsFrame:SetBackdropColor(1, 1, 1, enabled and 1 or 0.92) end
    if DemiseRaidRolls.ApplyFontPalette then
        local excluded = {}
        -- Council rows are refreshed dynamically and apply their own contrast
        -- colours. Excluding the panel prevents the generic palette from
        -- restoring an obsolete colour captured during an earlier refresh.
        if A.frame and A.frame.panel then excluded[A.frame.panel] = true end
        DemiseRaidRolls.ApplyFontPalette(A.frame, enabled, excluded)
        DemiseRaidRolls.ApplyFontPalette(A.optionsFrame, enabled)
        DemiseRaidRolls.ApplyFontPalette(A.rmPopupRef, enabled)
        DemiseRaidRolls.ApplyFontPalette(A.histPopupRef, enabled)
        DemiseRaidRolls.ApplyFontPalette(A.rframe, enabled)
        DemiseRaidRolls.ApplyFontPalette(A.notePopup, enabled)
    end
end

function A:ToggleOptions()
    if not A.optionsFrame then
        local p = CreateFrame("Frame", "DemiseRaidCouncilOptionsFrame", UIParent)
        p:SetWidth(360); p:SetHeight(325); p:SetPoint("CENTER"); p:SetFrameStrata("DIALOG")
        p:SetBackdrop(BACKDROP); p:SetMovable(true); p:EnableMouse(true); p:RegisterForDrag("LeftButton")
        p:SetScript("OnDragStart", function(self) self:StartMoving() end)
        p:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end)
        local title = p:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
        title:SetPoint("TOP", 0, -18); title:SetText("Raid Council Options")
        local close = CreateFrame("Button", nil, p, "UIPanelCloseButton"); close:SetPoint("TOPRIGHT", -4, -4)
        local misc = p:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        misc:SetPoint("TOPLEFT", 25, -58); misc:SetText("Miscellaneous")
        p.autoLoot = CreateFrame("CheckButton", nil, p, "UICheckButtonTemplate")
        p.autoLoot:SetPoint("TOPLEFT", 24, -79); p.autoLoot:SetWidth(24); p.autoLoot:SetHeight(24)
        local autoLabel = p:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        autoLabel:SetPoint("LEFT", p.autoLoot, "RIGHT", 3, 0); autoLabel:SetText("Auto Loot to ML")
        p.autoLoot:SetScript("OnClick", function(self) if DemiseRaidRolls.SetAutoMasterLootEnabled then DemiseRaidRolls.SetAutoMasterLootEnabled(self:GetChecked() and true or false) else DB().autoMasterLoot = self:GetChecked() and true or false end end)
        local recipientLabel = p:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        recipientLabel:SetPoint("TOPLEFT", 30, -113); recipientLabel:SetText("Autoloot recipient")
        p.recipient = CreateFrame("EditBox", nil, p)
        p.recipient:SetWidth(145); p.recipient:SetHeight(22); p.recipient:SetPoint("LEFT", recipientLabel, "RIGHT", 10, 0)
        p.recipient:SetAutoFocus(false); p.recipient:SetMaxLetters(24); StyleEditBox(p.recipient)
        local function SaveRecipient()
            local value = string.gsub(p.recipient:GetText() or "", "^%s*(.-)%s*$", "%1")
            if value == "" then value = "@ME" end
            DB().masterLooter = value; p.recipient:SetText(value)
        end
        p.recipient:SetScript("OnEnterPressed", function(self) SaveRecipient(); self:ClearFocus() end)
        p.recipient:SetScript("OnEditFocusLost", SaveRecipient)
        p.recipient:SetScript("OnEnter", function(self) GameTooltip:SetOwner(self, "ANCHOR_RIGHT"); GameTooltip:SetText("Autoloot recipient"); GameTooltip:AddLine("Use @ME for your current character, or enter the exact name of a raid member.", 1, 1, 1, true); GameTooltip:Show() end)
        p.recipient:SetScript("OnLeave", function() GameTooltip:Hide() end)
        p.mute = CreateFrame("CheckButton", nil, p, "UICheckButtonTemplate")
        p.mute:SetPoint("TOPLEFT", 24, -142); p.mute:SetWidth(24); p.mute:SetHeight(24)
        local muteLabel = p:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        muteLabel:SetPoint("LEFT", p.mute, "RIGHT", 3, 0); muteLabel:SetText("Mute winner announcement")
        p.mute:SetScript("OnClick", function(self) DB().muteWinnerAnnouncement = self:GetChecked() and true or false end)
        p.tradeOnAnnounce = CreateFrame("CheckButton", nil, p, "UICheckButtonTemplate")
        p.tradeOnAnnounce:SetPoint("TOPLEFT", 24, -171); p.tradeOnAnnounce:SetWidth(24); p.tradeOnAnnounce:SetHeight(24)
        local tradeLabel = p:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        tradeLabel:SetPoint("LEFT", p.tradeOnAnnounce, "RIGHT", 3, 0); tradeLabel:SetText("Trade winner on announce")
        p.tradeOnAnnounce:SetScript("OnClick", function(self) DB().councilTradeOnAnnounce = self:GetChecked() and true or false end)
        p.tradeOnAnnounce:SetScript("OnEnter", function(self)
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:SetText("Trade winner on announce")
            GameTooltip:AddLine("When enabled, Announce also opens a trade with the winner and places the awarded item in the trade window when it is found in your bags.", 1, 1, 1, true)
            GameTooltip:Show()
        end)
        p.tradeOnAnnounce:SetScript("OnLeave", function() GameTooltip:Hide() end)
		p.hideMinimap = CreateFrame("CheckButton", nil, p, "UICheckButtonTemplate")
		p.hideMinimap:SetPoint("TOPLEFT", 24, -204); p.hideMinimap:SetWidth(24); p.hideMinimap:SetHeight(24)
		local minimapLabel = p:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
		minimapLabel:SetPoint("LEFT", p.hideMinimap, "RIGHT", 3, 0); minimapLabel:SetText("Hide minimap icon")
		p.hideMinimap:SetScript("OnClick", function(self)
			DB().hideMinimapIcon = self:GetChecked() and true or false
			if DemiseRaidRolls.UpdateMinimapVisibility then DemiseRaidRolls.UpdateMinimapVisibility() end
		end)
        p.troubleshooting = CreateFrame("Button", nil, p, "UIPanelButtonTemplate")
        p.troubleshooting:SetWidth(150); p.troubleshooting:SetHeight(24); p.troubleshooting:SetPoint("BOTTOM", 0, 22)
        p.troubleshooting:SetText("Troubleshooting")
        p.troubleshooting:SetScript("OnClick", function() DemiseRaidRolls.ShowTroubleshootingReport() end)
        p:SetScript("OnShow", function(self) self.autoLoot:SetChecked(DB().autoMasterLoot == true); self.recipient:SetText(DB().masterLooter or "@ME"); self.mute:SetChecked(DB().muteWinnerAnnouncement == true); self.tradeOnAnnounce:SetChecked(DB().councilTradeOnAnnounce == true); self.hideMinimap:SetChecked(DB().hideMinimapIcon == true); A:ApplyHighContrast() end)
        p:Hide(); A.optionsFrame = p
    end
    if A.optionsFrame:IsShown() then A.optionsFrame:Hide() else A.optionsFrame:Show() end
end
