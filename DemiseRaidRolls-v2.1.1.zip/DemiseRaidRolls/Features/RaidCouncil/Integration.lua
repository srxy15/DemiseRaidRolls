DemiseRaidRolls.RaidCouncil = DemiseRaidRolls.RaidCouncil or {}
local RC = DemiseRaidRolls.RaidCouncil
local mainFrame
local syncedEnabled
local syncedOwner

local function DB()
	AscensionRaidRollsDB = AscensionRaidRollsDB or {}
	return AscensionRaidRollsDB
end

local function Print(message)
	if DEFAULT_CHAT_FRAME then DEFAULT_CHAT_FRAME:AddMessage("|cff00ff96Demise Raid Council:|r " .. tostring(message)) end
end

local function ApplySharedWindowPosition(frame)
	if not frame then return end
	local db = DB()
	frame:ClearAllPoints()
	frame:SetPoint(db.point or "CENTER", UIParent, db.relativePoint or "CENTER", db.x or 0, db.y or 0)
end

local function EnsureDemiseRaidCouncil()
	if not DemiseRaidCouncil then return false, "DemiseRaidCouncil module is unavailable." end
	AscensionRaidCouncilDB = AscensionRaidCouncilDB or {}
	AscensionRaidCouncilDB.council = AscensionRaidCouncilDB.council or {}
	AscensionRaidCouncilDB.voteSeconds = AscensionRaidCouncilDB.voteSeconds or 60
	DemiseRaidCouncil.council = AscensionRaidCouncilDB.council
	DemiseRaidCouncil.me = DemiseRaidCouncil.me or DemiseRaidCouncil:Short(UnitName("player"))
	DemiseRaidCouncil:CreateCouncilFrame()
	DemiseRaidCouncil:CreateRaiderFrame()
	if DemiseRaidCouncil.WarmRaiderRows then
		DemiseRaidCouncil:WarmRaiderRows()
	end
	if DemiseRaidCouncil.ApplyHighContrast then
		DemiseRaidCouncil:ApplyHighContrast()
	end
	return DemiseRaidCouncil.frame ~= nil, DemiseRaidCouncil.frame and nil or "DemiseRaidCouncil could not create its council window."
end

function RC.IsEnabled()
	if syncedOwner ~= nil then
		return syncedEnabled == true
	end
	return DB().raidCouncilEnabled == true
end

function RC.IsModeSynchronized()
	return syncedOwner ~= nil
end

function RC.CanManage()
	if DemiseRaidRolls.CanControlRolls then
		return DemiseRaidRolls.CanControlRolls() == true
	end
	return not (GetNumRaidMembers and GetNumRaidMembers() > 0)
end

local function ApplyWindowMode(enabled, showWindow)
	if DemiseRaidRollsMenu and DemiseRaidRollsMenu.MarkModuleChosen then
		DemiseRaidRollsMenu.MarkModuleChosen(enabled and "council" or "rolls")
	end
	if DemiseRaidRollsMenu and DemiseRaidRollsMenu.Hide then DemiseRaidRollsMenu.Hide() end
	if enabled then
		local ok, ready, reason = pcall(EnsureDemiseRaidCouncil)
		if not ok then Print("Initialization error: " .. tostring(ready)); return true end
		if not ready then Print(reason or "Initialization failed."); return true end
		RC.initialApplied = true
		if mainFrame then mainFrame:Hide() end
		ApplySharedWindowPosition(DemiseRaidCouncil.frame)
		if showWindow then
			DemiseRaidCouncil.frame:Show()
			DemiseRaidCouncil:RefreshCouncil()
		end
	else
		RC.initialApplied = nil
		if DemiseRaidCouncil.frame then DemiseRaidCouncil.frame:Hide() end
		if DemiseRaidCouncil.rframe then DemiseRaidCouncil.rframe:Hide() end
		if mainFrame then
			ApplySharedWindowPosition(mainFrame)
			if showWindow then mainFrame:Show() end
		end
	end
	return true
end

function RC.SetEnabled(enabled)
	if not RC.CanManage() then return false end
	DB().raidCouncilEnabled = enabled == true
	syncedEnabled = nil
	syncedOwner = nil
	-- Local module selection comes from the user-facing menu, opened through
	-- the minimap icon, so displaying the selected module is intentional.
	return ApplyWindowMode(enabled == true, true)
end

function RC.ApplySyncedMode(enabled, owner)
	syncedEnabled = enabled == true
	syncedOwner = owner
	-- Mode synchronization is passive and must never pop a window by itself.
	return ApplyWindowMode(syncedEnabled, false)
end

function RC.ClearSyncedMode()
	if syncedOwner == nil then return false end
	syncedEnabled = nil
	syncedOwner = nil
	ApplyWindowMode(DB().raidCouncilEnabled == true, false)
	return true
end

function RC.AttachMainFrame(frame)
	mainFrame = frame
end

function RC.ApplyMainWindow()
	if DemiseRaidRollsMenu and DemiseRaidRollsMenu.frame and DemiseRaidRollsMenu.frame:IsShown() then
		if mainFrame and mainFrame:IsShown() then mainFrame:Hide() end
		return true
	end
	if not RC.IsEnabled() then return false end
	if not RC.initialApplied then
		local ok, ready, reason = pcall(EnsureDemiseRaidCouncil)
		if not ok then Print("Initialization error: " .. tostring(ready)); return false end
		if not ready then Print(reason or "Initialization failed."); return false end
		RC.initialApplied = true
		ApplySharedWindowPosition(DemiseRaidCouncil.frame)
	end
	if mainFrame and mainFrame:IsShown() then mainFrame:Hide() end
	return true
end
