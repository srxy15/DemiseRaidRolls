local A = DemiseRaidCouncil

local VERIFY_DELAY = 0.75
local MAX_VERIFY_ATTEMPTS = 8
local PENDING_TIMEOUT = 600

local function FindGroupUnit(playerName)
	if A:NamesEqual(playerName, A.me) then return "player" end
	local raidCount = GetNumRaidMembers and GetNumRaidMembers() or 0
	local i
	for i = 1, raidCount do
		if A:NamesEqual(GetRaidRosterInfo(i), playerName) then return "raid" .. i end
	end
	local partyCount = GetNumPartyMembers and GetNumPartyMembers() or 0
	for i = 1, partyCount do
		if A:NamesEqual(UnitName("party" .. i), playerName) then return "party" .. i end
	end
	return nil
end

local function ItemID(value)
	return type(value) == "string" and tonumber(string.match(value, "item:(%d+)")) or nil
end

local function MatchesItem(link, item)
	if not link or not item then return false end
	local wantedLink = item.link
	local wantedID = ItemID(item.itemString or wantedLink)
	return link == wantedLink or (wantedID and ItemID(link) == wantedID) or false
end

local function FindItemInBags(item)
	if not GetContainerNumSlots or not GetContainerItemLink then return nil, nil end
	local bag, slot
	for bag = 0, 4 do
		for slot = 1, (GetContainerNumSlots(bag) or 0) do
			local bagLink = GetContainerItemLink(bag, slot)
			if MatchesItem(bagLink, item) then
				local locked = false
				if GetContainerItemInfo then
					local _, _, isLocked = GetContainerItemInfo(bag, slot)
					locked = isLocked and true or false
				end
				if not locked then return bag, slot end
			end
		end
	end
	return nil, nil
end

local function CountItemInBags(item)
	if not GetContainerNumSlots or not GetContainerItemLink then return 0 end
	local count = 0
	local bag, slot
	for bag = 0, 4 do
		for slot = 1, (GetContainerNumSlots(bag) or 0) do
			if MatchesItem(GetContainerItemLink(bag, slot), item) then
				local stackCount = 1
				if GetContainerItemInfo then
					local _, itemCount = GetContainerItemInfo(bag, slot)
					stackCount = tonumber(itemCount) or 1
				end
				count = count + stackCount
			end
		end
	end
	return count
end

local function TradeContainsItem(pending)
	if not pending or not GetTradePlayerItemLink then return false end
	local slot
	for slot = 1, 6 do
		if MatchesItem(GetTradePlayerItemLink(slot), pending.item) then return true end
	end
	return false
end

local function TradeRecipientMatches(playerName)
	local recipient
	if TradeFrameRecipientNameText and TradeFrameRecipientNameText.GetText then recipient = TradeFrameRecipientNameText:GetText() end
	return not recipient or recipient == "" or A:NamesEqual(recipient, playerName)
end

local function ClearPendingTrade()
	A.pendingAwardTrade = nil
	A.verifyingAwardTrade = nil
end

local function CompleteAwardTrade(pending)
	if not pending or pending.completed then return end
	pending.completed = true
	ClearPendingTrade()
	if A.OnAwardTradeCompleted then A:OnAwardTradeCompleted(pending) end
end

local function PlacePendingItem()
	local pending = A.pendingAwardTrade
	if not pending or not pending.autoPlace then return end
	if pending.requestedAt and (GetTime() - pending.requestedAt) > 15 then ClearPendingTrade(); return end
	if not PickupContainerItem or not ClickTradeButton then
		A:Print("The client cannot place the awarded item automatically. The trade is still open.")
		return
	end
	local bag, bagSlot = FindItemInBags(pending.item)
	if bag == nil then A:Print("The awarded item was not found in your bags. The trade is still open."); return end
	local tradeSlot, slot
	for slot = 1, 6 do
		if not GetTradePlayerItemLink or not GetTradePlayerItemLink(slot) then tradeSlot = slot; break end
	end
	if not tradeSlot then A:Print("No free item slot is available in the trade window."); return end
	if ClearCursor then ClearCursor() end
	PickupContainerItem(bag, bagSlot)
	ClickTradeButton(tradeSlot)
	if CursorHasItem and CursorHasItem() then
		if ClearCursor then ClearCursor() end
		A:Print("The awarded item could not be placed automatically. You can still add it manually.")
		return
	end
	pending.itemWasPlaced = TradeContainsItem(pending)
end

function A:PrepareAwardTrade(playerName, item, itemIndex, choice)
	A.pendingAwardTrade = {
		player = playerName, item = item, itemIndex = itemIndex, choice = choice,
		requestedAt = GetTime(), bagCountBefore = CountItemInBags(item),
		itemWasPlaced = false, autoPlace = false,
	}
end

function A:CompleteSelfAward(playerName, item, itemIndex, choice)
	if CountItemInBags(item) < 1 then
		A:Print("The awarded item was not found in your bags, so its distribution was not recorded.")
		return false
	end
	if A.OnAwardTradeCompleted then
		A:OnAwardTradeCompleted({ player = playerName, item = item, itemIndex = itemIndex, choice = choice })
	end
	return true
end

function A:TradeAwardedItem(playerName, item, itemIndex, choice)
	if not A:IsML() then A:Print("Only the current Master Looter can initiate the award trade."); return end
	if A:NamesEqual(playerName, A.me) then A:Print("The winner is you, so no trade was opened."); return end
	local unit = FindGroupUnit(playerName)
	if not unit then A:Print("Could not find " .. tostring(playerName) .. " in the current raid or party."); return end
	if not InitiateTrade then A:Print("InitiateTrade is unavailable on this client."); return end
	A:PrepareAwardTrade(playerName, item, itemIndex, choice)
	A.pendingAwardTrade.autoPlace = true
	InitiateTrade(unit)
end

local eventFrame = CreateFrame("Frame")
eventFrame:RegisterEvent("TRADE_SHOW")
eventFrame:RegisterEvent("TRADE_ACCEPT_UPDATE")
eventFrame:RegisterEvent("TRADE_PLAYER_ITEM_CHANGED")
eventFrame:RegisterEvent("UI_INFO_MESSAGE")
eventFrame:RegisterEvent("TRADE_CLOSED")
eventFrame:SetScript("OnEvent", function(_, event, arg1, arg2)
	local pending = A.pendingAwardTrade
	if event == "TRADE_SHOW" then
		if pending and TradeRecipientMatches(pending.player) then PlacePendingItem() end
		return
	end
	if event == "TRADE_ACCEPT_UPDATE" or event == "TRADE_PLAYER_ITEM_CHANGED" then
		if pending and TradeRecipientMatches(pending.player) then
			pending.itemWasPlaced = TradeContainsItem(pending)
			if event == "TRADE_ACCEPT_UPDATE" then pending.bothAccepted = tonumber(arg1) == 1 and tonumber(arg2) == 1 end
		end
		return
	end
	if event == "UI_INFO_MESSAGE" then
		local message = tostring(arg2 or arg1 or "")
		local tradeComplete = tostring(_G.ERR_TRADE_COMPLETE or "Trade complete.")
		local context = pending or A.verifyingAwardTrade
		if context and context.itemWasPlaced and message == tradeComplete then CompleteAwardTrade(context) end
		return
	end
	if event == "TRADE_CLOSED" then
		if pending then
			pending.verifyAttempts = 0
			pending.nextVerifyAt = GetTime() + VERIFY_DELAY
			A.verifyingAwardTrade = pending
			A.pendingAwardTrade = nil
		end
	end
end)

eventFrame:SetScript("OnUpdate", function()
	local pending = A.pendingAwardTrade
	if pending and pending.requestedAt and (GetTime() - pending.requestedAt) > PENDING_TIMEOUT then A.pendingAwardTrade = nil end
	local verifying = A.verifyingAwardTrade
	if not verifying or GetTime() < (verifying.nextVerifyAt or 0) then return end
	verifying.verifyAttempts = (verifying.verifyAttempts or 0) + 1
	if CountItemInBags(verifying.item) < (verifying.bagCountBefore or 0) then
		CompleteAwardTrade(verifying)
	elseif verifying.verifyAttempts >= MAX_VERIFY_ATTEMPTS then
		A.verifyingAwardTrade = nil
	else
		verifying.nextVerifyAt = GetTime() + VERIFY_DELAY
	end
end)
