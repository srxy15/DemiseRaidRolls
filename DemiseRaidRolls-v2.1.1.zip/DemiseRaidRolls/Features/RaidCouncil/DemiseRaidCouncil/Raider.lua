local A = DemiseRaidCouncil

local GOLD = { 1.0, 0.78, 0.20 }
local THIN = {
	bgFile = "Interface\\Buttons\\WHITE8X8",
	edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
	tile = true,
	tileSize = 16,
	edgeSize = 10,
	insets = { left = 2, right = 2, top = 2, bottom = 2 },
}

local HEADER_H = 38
local ROW_H = 56
local MIN_WIDTH = 350
local MAX_WIDTH = 600
local NAME_LEFT = 56
local NAME_RIGHT = 36
local GAP = 4

local function SaveTopLeftPosition(frame)
	local left = frame and frame:GetLeft()
	local top = frame and frame:GetTop()
	if not left or not top then return end
	local frameScale = frame.GetEffectiveScale and frame:GetEffectiveScale() or 1
	local parentScale = UIParent.GetEffectiveScale and UIParent:GetEffectiveScale() or 1
	left = left * frameScale / parentScale
	top = top * frameScale / parentScale
	frame:ClearAllPoints()
	frame:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", left, top)
	AscensionRaidCouncilDB.raiderPos = {
		point = "TOPLEFT",
		rel = "BOTTOMLEFT",
		x = left,
		y = top,
	}
end

local function RestoreSavedTopLeftPosition(frame)
	local saved = AscensionRaidCouncilDB and AscensionRaidCouncilDB.raiderPos
	if not frame or not saved then return end
	frame:ClearAllPoints()
	frame:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", saved.x or 0, saved.y or 0)
end

function A:CreateRaiderFrame()
	if A.rframe then
		return
	end
	local f = CreateFrame("Frame", "DemiseRaidCouncilRaiderFrame", UIParent)
	f:SetFrameStrata("HIGH")
	f:SetWidth(MIN_WIDTH)
	f:SetHeight(HEADER_H + GAP + ROW_H)
	if AscensionRaidCouncilDB.raiderPos then
		f:SetPoint(
			AscensionRaidCouncilDB.raiderPos.point,
			UIParent,
			AscensionRaidCouncilDB.raiderPos.rel,
			AscensionRaidCouncilDB.raiderPos.x,
			AscensionRaidCouncilDB.raiderPos.y
		)
	else
		f:SetPoint("TOP", UIParent, "TOP", 0, -160)
	end
	f:SetMovable(true)
	-- This frame changes height whenever a player answers an item. Frame clamping
	-- can silently move a resized frame, making its header jump between answers.
	-- The explicit TOPLEFT anchor below keeps the header fixed instead.
	f:SetClampedToScreen(false)
	f:Hide()

	local header = CreateFrame("Frame", nil, f)
	header:SetPoint("TOPLEFT", 0, 0)
	header:SetPoint("TOPRIGHT", 0, 0)
	header:SetHeight(HEADER_H)
	header:SetBackdrop(THIN)
	header:SetBackdropColor(0.035, 0.035, 0.035, 0.96)
	header:SetBackdropBorderColor(0.48, 0.48, 0.48, 0.95)
	header:EnableMouse(true)
	header:RegisterForDrag("LeftButton")
	header:SetScript("OnDragStart", function() f:StartMoving() end)
	header:SetScript("OnDragStop", function()
		f:StopMovingOrSizing()
		SaveTopLeftPosition(f)
	end)
	f.header = header

	local title = header:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
	title:SetPoint("TOP", 0, -4)
	title:SetText("Demise Raid Council Loot Frame")
	title:SetTextColor(GOLD[1], GOLD[2], GOLD[3])
	f.title = title

	local anchor = CreateFrame("Button", nil, header)
	anchor:SetWidth(18)
	anchor:SetHeight(18)
	anchor:SetPoint("TOPLEFT", header, "TOPLEFT", 3, -2)
	anchor:SetBackdrop(THIN)
	anchor:SetBackdropColor(0, 0, 0, 0.9)
	anchor:SetBackdropBorderColor(0.50, 0.50, 0.50, 1)
	local moveTexture = anchor:CreateTexture(nil, "ARTWORK")
	moveTexture:SetTexture("Interface\\AddOns\\DemiseRaidRolls\\Assets\\Move")
	moveTexture:SetPoint("TOPLEFT", 2, -2)
	moveTexture:SetPoint("BOTTOMRIGHT", -2, 2)
	anchor:SetHighlightTexture("Interface\\Buttons\\ButtonHilight-Square")
	anchor:RegisterForDrag("LeftButton")
	anchor:SetScript("OnDragStart", function()
		f:StartMoving()
	end)
	anchor:SetScript("OnDragStop", function()
		f:StopMovingOrSizing()
		SaveTopLeftPosition(f)
	end)
	anchor:SetScript("OnEnter", function(self)
		GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
		GameTooltip:SetText("Demise Raid Council - drag to move")
		GameTooltip:Show()
	end)
	anchor:SetScript("OnLeave", function()
		GameTooltip:Hide()
	end)
	anchor:Hide()
	f.anchor = anchor

	local timerBar = CreateFrame("StatusBar", nil, header)
	timerBar:SetHeight(13)
	timerBar:SetPoint("BOTTOMLEFT", header, "BOTTOMLEFT", 3, 3)
	timerBar:SetPoint("BOTTOMRIGHT", header, "BOTTOMRIGHT", -3, 3)
	timerBar:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar")
	timerBar:SetMinMaxValues(0, 1)
	timerBar:SetValue(0)
	timerBar:SetStatusBarColor(0.20, 0.75, 0.25)
	local timerBg = timerBar:CreateTexture(nil, "BACKGROUND")
	timerBg:SetAllPoints(timerBar)
	timerBg:SetTexture(0.08, 0.08, 0.08, 0.85)
	local timerText = timerBar:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	timerText:SetPoint("CENTER", timerBar, "CENTER", 0, 0)
	timerText:SetText("Timer ready")
	timerBar:Hide()
	f.timerBar = timerBar
	f.timerText = timerText

	A.rframe = f
	A.rrows = {}
	A.editMode = false
	if A.ApplyScales then
		A:ApplyScales()
	end
	-- Migrate every legacy CENTER/TOP/BOTTOM position only after the configured
	-- scale has been applied, then keep that upper-left screen position forever.
	SaveTopLeftPosition(f)
end

local function GetRaiderRow(i)
	local A = DemiseRaidCouncil
	local row = A.rrows[i]
	if row then
		return row
	end
	row = CreateFrame("Frame", nil, A.rframe)
	row:SetWidth(MIN_WIDTH)
	row:SetHeight(ROW_H)
	row:SetBackdrop(THIN)
	row:SetBackdropColor(0.05, 0.05, 0.05, 0.92)
	row:SetBackdropBorderColor(0.48, 0.48, 0.48, 0.95)

	row.icon = CreateFrame("Button", nil, row)
	row.icon:SetWidth(40)
	row.icon:SetHeight(40)
	row.icon:SetPoint("TOPLEFT", 8, -8)
	row.iconTex = row.icon:CreateTexture(nil, "ARTWORK")
	row.iconTex:SetAllPoints()
	row.iconTex:SetTexCoord(0.07, 0.93, 0.07, 0.93)
	row.icon:SetScript("OnEnter", A.ItemTooltip)
	row.icon:SetScript("OnLeave", A.HideTooltip)

	row.text = row:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
	row.text:SetPoint("TOPLEFT", NAME_LEFT, -7)
	row.text:SetJustifyH("LEFT")
	row.text:SetWidth(MIN_WIDTH - NAME_LEFT - NAME_RIGHT)

	row.buttons = {}
	local widths = { 50, 76, 70, 50 }
	local x = NAME_LEFT
	for j = 1, table.getn(A.CHOICES) do
		local choice = A.CHOICES[j]
		local display = A:ChoiceLabel(choice)
		local b = A.GoldButton(row, widths[j], 20, display, "GameFontNormal")
		b.label:SetTextColor(1.0, 0.82, 0.15)
		b:SetPoint("BOTTOMLEFT", x, 6)
		x = x + widths[j] + 4
		row.buttons[j] = b
	end

	row.note = CreateFrame("Button", nil, row)
	row.note:SetWidth(22)
	row.note:SetHeight(22)
	row.note:SetPoint("BOTTOMLEFT", x, 5)
	row.note:SetBackdrop(THIN)
	row.note:SetBackdropColor(0.08, 0.08, 0.08, 0.96)
	row.note:SetBackdropBorderColor(0.48, 0.48, 0.48, 0.95)
	row.noteTex = row.note:CreateTexture(nil, "ARTWORK")
	row.noteTex:SetTexture("Interface\\Icons\\INV_Scroll_03")
	row.noteTex:SetPoint("TOPLEFT", 3, -3)
	row.noteTex:SetPoint("BOTTOMRIGHT", -3, 3)
	row.note:SetHighlightTexture("Interface\\Buttons\\ButtonHilight-Square")
	row.note:SetScript("OnEnter", function(self)
		GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
		GameTooltip:SetText(self.hasNote and "Edit note" or "Add note")
		GameTooltip:Show()
	end)
	row.note:SetScript("OnLeave", function() GameTooltip:Hide() end)

	A.rrows[i] = row
	return row
end

local warmupDriver = CreateFrame("Frame")
warmupDriver:Hide()
warmupDriver.elapsed = 0
warmupDriver:SetScript("OnUpdate", function(self, elapsed)
	self.elapsed = self.elapsed + (elapsed or 0)
	if self.elapsed < 0.08 then return end
	self:Hide()
	local frame = A.rframe
	if not frame then return end
	frame:SetAlpha(1)
	if A.started then
		A:RefreshRaider()
		return
	end
	for _, row in ipairs(A.rrows or {}) do row:Hide() end
	frame.timerBar:Hide()
	frame:Hide()
end)

-- Build and render the fixed row pool when Raid Council is selected instead
-- of loading its templates, fonts and status-bar textures on Start Rolls.
-- A tiny alpha keeps the warm-up visually imperceptible while still making the
-- 3.3.5 renderer prepare the regions; a fully transparent frame may be culled.
function A:WarmRaiderRows()
	A:CreateRaiderFrame()
	if A.raiderRowsWarmed or A.started then return end
	A.raiderRowsWarmed = true
	local frame = A.rframe
	frame:SetHeight(HEADER_H + GAP + (ROW_H + GAP) * 5)
	local i
	for i = 1, 5 do
		local row = GetRaiderRow(i)
		row:ClearAllPoints()
		row:SetPoint("TOPLEFT", 0, -(HEADER_H + GAP + (i - 1) * (ROW_H + GAP)))
		row.iconTex:SetTexture("Interface\\Icons\\INV_Misc_QuestionMark")
		row.text:SetText("Council item")
		row:Hide()
	end
	frame.timerBar:Hide()
	frame:Hide()
end

-- Small popup where the raider writes a note (max 100 characters) for one item.
function A:CreateNotePopup()
	if A.notePopup then
		return A.notePopup
	end
	local p = CreateFrame("Frame", "DemiseRaidCouncilNoteEditor", UIParent)
	p:SetFrameStrata("DIALOG")
	p:SetWidth(320)
	p:SetHeight(120)
	p:SetPoint("CENTER", UIParent, "CENTER", 0, 120)
	p:SetBackdrop({
		bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
		edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
		tile = true,
		tileSize = 32,
		edgeSize = 32,
		insets = { left = 11, right = 12, top = 12, bottom = 11 },
	})
	p:EnableMouse(true)
	p:Hide()

	local title = p:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
	title:SetPoint("TOPLEFT", 12, -12)
	title:SetTextColor(GOLD[1], GOLD[2], GOLD[3])
	p.title = title

	local itemHover = CreateFrame("Button", nil, p)
	itemHover:SetPoint("TOPLEFT", 10, -8)
	itemHover:SetWidth(296)
	itemHover:SetHeight(22)
	itemHover:SetScript("OnEnter", function(self)
		if self.link then
			GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
			GameTooltip:SetHyperlink(self.link)
			GameTooltip:Show()
		end
	end)
	itemHover:SetScript("OnLeave", function() GameTooltip:Hide() end)
	p.itemHover = itemHover

	local eb = CreateFrame("EditBox", "DemiseRaidCouncilNoteEdit", p)
	eb:SetPoint("TOPLEFT", 16, -34)
	eb:SetWidth(280)
	eb:SetHeight(24)
	eb:SetAutoFocus(true)
	eb:SetMaxLetters(A.NOTE_MAX or 100)
	eb:SetBackdrop(THIN)
	eb:SetBackdropColor(0.03, 0.03, 0.03, 0.96)
	eb:SetBackdropBorderColor(0.45, 0.45, 0.45, 1)
	if eb.SetTextInsets then eb:SetTextInsets(7, 7, 0, 0) end
	eb:SetFontObject("GameFontHighlightSmall")
	p.edit = eb

	local counter = p:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
	counter:SetPoint("TOPRIGHT", -14, -62)
	counter:SetTextColor(1, 1, 1)
	p.counter = counter

	local function UpdateCounter()
		counter:SetText(string.len(eb:GetText() or "") .. "/" .. (A.NOTE_MAX or 100))
	end
	eb:SetScript("OnTextChanged", UpdateCounter)

	local save = A.GoldButton(p, 110, 22, "Save Note")
	save.label:SetTextColor(1.0, 0.82, 0.15)
	save:SetPoint("BOTTOMLEFT", 12, 12)
	local function Save()
		local txt = string.gsub(eb:GetText() or "", "^%s*(.-)%s*$", "%1")
		txt = string.sub(txt, 1, A.NOTE_MAX or 100)
		local idx = p.itemIndex
		if idx then
			A.notes[idx] = A.notes[idx] or {}
			if txt == "" then
				A.notes[idx][A.me] = nil
			else
				A.notes[idx][A.me] = txt
			end
			A:BroadcastNote(idx, txt)
		end
		eb:ClearFocus()
		p:Hide()
		A:RefreshRaider()
	end
	save:SetScript("OnClick", Save)
	eb:SetScript("OnEnterPressed", Save)

	local close = A.GoldButton(p, 90, 22, "Cancel")
	close.label:SetTextColor(1.0, 0.82, 0.15)
	close:SetPoint("BOTTOMRIGHT", -12, 12)
	close:SetScript("OnClick", function()
		eb:ClearFocus()
		p:Hide()
	end)
	eb:SetScript("OnEscapePressed", function()
		eb:ClearFocus()
		p:Hide()
	end)

	A.notePopup = p
	return p
end

function A:OpenNotePopup(idx, item)
	local p = A:CreateNotePopup()
	p.itemIndex = idx
	p.title:SetText("Note for " .. (item and item.link or "item"))
	p.itemHover.link = item and item.link or nil
	local existing = (A.notes[idx] and A.notes[idx][A.me]) or ""
	p.edit:SetText(existing)
	p.counter:SetText(string.len(existing) .. "/" .. (A.NOTE_MAX or 100))
	p:Show()
	p.edit:SetFocus()
end

function A:RefreshRaider()
	local f = A.rframe
	if not f then
		return
	end
	for _, r in ipairs(A.rrows) do
		r:Hide()
	end

	local open = A.VotingOpen and A:VotingOpen()
	local shown = 0
	local y = HEADER_H + GAP
	local maximumItemTextWidth = 0
	if open then
		for i, item in ipairs(A.items) do
			local itemIndex = i
			if shown < 5 and not (A.choices[itemIndex] and A.choices[itemIndex][A.me]) then
				shown = shown + 1
				local row = GetRaiderRow(shown)
				row:ClearAllPoints()
				row:SetPoint("TOPLEFT", 0, -y)
				row:Show()
				row.icon.link = item.link
				row.iconTex:SetTexture(item.texture)
				row.text:SetWidth(MAX_WIDTH - NAME_LEFT - NAME_RIGHT)
				local quantityText = A:ItemQuantity(item) > 1 and (" |cffffffffx" .. A:ItemQuantity(item) .. "|r") or ""
				row.text:SetText((item.link or "") .. quantityText)
				maximumItemTextWidth = math.max(maximumItemTextWidth, row.text:GetStringWidth() or 0)
				local hasNote = A.notes[itemIndex] and A.notes[itemIndex][A.me]
				row.note.hasNote = hasNote and true or false
				row.noteTex:SetVertexColor(hasNote and 1.0 or 0.72, hasNote and 0.82 or 0.72, hasNote and 0.15 or 0.72)
				row.note:SetScript("OnClick", function()
					A:OpenNotePopup(itemIndex, item)
				end)
				for j, choice in ipairs(A.CHOICES) do
					local choiceIndex = j
					local selectedChoice = choice
					row.buttons[choiceIndex]:SetScript("OnClick", function()
						if not A:VotingOpen() then
							A:RefreshRaider()
							return
						end
						A.choices[itemIndex] = A.choices[itemIndex] or {}
						A.choices[itemIndex][A.me] = selectedChoice
						A:BroadcastChoice(itemIndex, selectedChoice)
						if selectedChoice ~= "Pass" then
							local gear = A:EquippedFor(item.itemString)
							A.gear[itemIndex] = A.gear[itemIndex] or {}
							A.gear[itemIndex][A.me] = gear
							A:BroadcastGear(itemIndex, gear)
						end
						if A.notePopup and A.notePopup.itemIndex == itemIndex then
							A.notePopup:Hide()
						end
						A:RefreshRaider()
						A:RefreshCouncil()
					end)
				end
				y = y + ROW_H + GAP
			end
		end
	end

	local targetWidth = math.max(MIN_WIDTH, math.min(MAX_WIDTH, math.ceil(maximumItemTextWidth + NAME_LEFT + NAME_RIGHT + 8)))
	f:SetWidth(targetWidth)
	local rowIndex
	for rowIndex = 1, shown do
		local row = A.rrows[rowIndex]
		row:SetWidth(targetWidth)
		row.text:SetWidth(targetWidth - NAME_LEFT - NAME_RIGHT)
	end

	if A.RefreshTimerText then
		A:RefreshTimerText()
	end
	if f.anchor then
		if A.editMode or open then
			f.anchor:Show()
		else
			f.anchor:Hide()
		end
	end
	f:SetHeight(math.max(y - GAP, HEADER_H))
	-- Width and height are dynamic, but the header must never be re-centered or
	-- shifted when the first answered item disappears from the list.
	RestoreSavedTopLeftPosition(f)
	if shown == 0 and not A.editMode then
		f:Hide()
	end
end

function A:ShowRaiderList()
	A:CreateRaiderFrame()
	A.rframe:Show()
	A:RefreshRaider()
end

function A:HideRaiderList()
	if A.rframe and not A.editMode then
		A.rframe:Hide()
	end
end

function A:ToggleRaiderEdit()
	A:CreateRaiderFrame()
	A.editMode = not A.editMode
	if A.editMode then
		A.rframe.anchor:Show()
		A.rframe:Show()
		A:RefreshRaider()
		A:Print("Edit mode ON - drag the anchor in the top left corner.")
	else
		A.rframe.anchor:Hide()
		A:Print("Edit mode OFF.")
		A:RefreshRaider()
		if not A.started then
			A.rframe:Hide()
		end
	end
end
