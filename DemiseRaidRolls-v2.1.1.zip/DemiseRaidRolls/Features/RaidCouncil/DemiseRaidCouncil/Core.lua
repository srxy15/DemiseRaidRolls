--[[ DemiseRaidCouncil - Loot Council for WoW 3.3.5a (Project Ascension / CoA)
     Helt manuellt och eventbaserat. Ingen OnUpdate-loop anvands. ]]

DemiseRaidCouncil = {}
local A = DemiseRaidCouncil

A.PREFIX = "ARRLC"
A.VERSION = (DemiseRaidRolls.GetVersion and DemiseRaidRolls.GetVersion()) or "2.1.1"
A.AUTHOR = "LaSainteChips"
A.CHOICES = { "BiS", "Upgrade", "Offspec", "Pass" }
A.CHOICE_COLOR = {
	BiS = { 1.0, 0.82, 0.0 },
	Upgrade = { 0.2, 0.9, 0.4 },
	Offspec = { 0.4, 0.7, 1.0 },
	Pass = { 1.0, 0.35, 0.35 },
}

function A:ChoiceLabel(choice)
	return choice == "Offspec" and "Off Spec" or choice
end

A.items = {} -- { {itemString, link, texture, name, adder, quantity, awardedCount, awardedPlayers} }
A.choices = {} -- [index][player] = "BiS"|...
A.upvotes = {} -- [index][player] = { [rmName]=true }
A.rmVoted = {} -- [index][rmName] = true
A.passes = {} -- [index][rmName] = true (radsmedlem som passat)
A.winners = {} -- [index] = player
A.traded = {} -- [index] = true
A.notes = {} -- [index][player] = note text
A.gear = {} -- [index][player] = "itemString,itemString"
A.started = false

A.council = {} -- lista med namn (inkl. masterlooter)
A.me = nil

function A:Print(msg)
	DEFAULT_CHAT_FRAME:AddMessage("|cff00ff96DemiseRaidCouncil:|r " .. tostring(msg))
end

function A:Short(name)
	if not name then
		return nil
	end
	name = string.gsub(name, "%-.*$", "")
	return name
end

function A:NameKey(name)
	local short = A:Short(name)
	if not short then
		return nil
	end
	return string.lower(short)
end

function A:NamesEqual(a, b)
	local aKey = A:NameKey(a)
	local bKey = A:NameKey(b)
	return aKey and bKey and aKey == bKey
end

function A:PlayerClassColor(name)
	local classFile
	for i = 1, (GetNumRaidMembers and GetNumRaidMembers() or 0) do
		local rosterName, _, _, _, _, rosterClass = GetRaidRosterInfo(i)
		if A:NamesEqual(rosterName, name) then classFile = rosterClass; break end
	end
	if not classFile and A:NamesEqual(name, A.me) then
		local _, playerClass = UnitClass("player")
		classFile = playerClass
	end
	if not classFile then
		for i = 1, (GetNumPartyMembers and GetNumPartyMembers() or 0) do
			if A:NamesEqual(UnitName("party" .. i), name) then
				local _, partyClass = UnitClass("party" .. i)
				classFile = partyClass
				break
			end
		end
	end
	return DemiseRaidRolls.GetClassColor(classFile)
end

function A:InGroup()
	if GetNumRaidMembers and GetNumRaidMembers() > 0 then
		return true
	end
	if GetNumPartyMembers and GetNumPartyMembers() > 0 then
		return true
	end
	return false
end

function A:IsRaidLeader()
	if IsPartyLeader and IsPartyLeader() then
		return true
	end
	if UnitInRaid("player") then
		for i = 1, GetNumRaidMembers() do
			local name, rank = GetRaidRosterInfo(i)
			if A:NamesEqual(name, A.me) and rank and rank >= 1 then
				return true
			end
		end
	end
	return false
end

function A:MasterLooterName()
	if not A:InGroup() then
		return A.me
	end
	local method, partyIdx, raidIdx = GetLootMethod()
	if method ~= "master" then
		return nil
	end
	if partyIdx == 0 or raidIdx == 0 then
		return A.me
	end
	if raidIdx and raidIdx > 0 then
		return A:Short(GetRaidRosterInfo(raidIdx) or UnitName("raid" .. raidIdx))
	end
	if partyIdx and partyIdx > 0 then
		return A:Short(UnitName("party" .. partyIdx))
	end
	return nil
end

function A:IsML()
	if A.isLeaderFallback == true then
		return true
	end
	if A:IsRaidLeader() then
		return true
	end
	if not A:InGroup() then
		return true
	end
	local method, partyIdx, raidIdx = GetLootMethod()
	if method ~= "master" then
		return false
	end
	if partyIdx == 0 then
		return true
	end
	if raidIdx then
		return A:NamesEqual(UnitName("raid" .. raidIdx), A.me)
	end
	return false
end

function A:IsCouncil()
	if A:IsML() then
		return true
	end
	for _, n in ipairs(A.council) do
		if A:NamesEqual(n, A.me) then
			return true
		end
	end
	return false
end

function A:IsCurrentGroupMember(name)
	if not name or name == "" then
		return false
	end
	local raidCount = GetNumRaidMembers and GetNumRaidMembers() or 0
	if raidCount > 0 then
		local i
		for i = 1, raidCount do
			if A:NamesEqual(GetRaidRosterInfo(i), name) then
				return true
			end
		end
		return false
	end
	local partyCount = GetNumPartyMembers and GetNumPartyMembers() or 0
	if partyCount > 0 then
		if A:NamesEqual(UnitName("player"), name) then
			return true
		end
		local i
		for i = 1, partyCount do
			if A:NamesEqual(UnitName("party" .. i), name) then
				return true
			end
		end
		return false
	end
	-- Preserve unrestricted standalone testing outside a group.
	return true
end

function A:CouncilCount()
	local n = 0
	for _, name in ipairs(A.council) do
		if A:IsCurrentGroupMember(name) then
			n = n + 1
		end
	end
	return n
end

function A:VoterList()
	local list, seen = {}, {}
	local ml = A:MasterLooterName() or A.mlName
	if ml and ml ~= "" and A:IsCurrentGroupMember(ml) then
		table.insert(list, ml)
		seen[A:NameKey(ml)] = true
	end
	for _, n in ipairs(A.council) do
		local key = A:NameKey(n)
		if key and not seen[key] and A:IsCurrentGroupMember(n) then
			table.insert(list, n)
			seen[key] = true
		end
	end
	return list
end

function A:RequiredCount()
	return table.getn(A:VoterList())
end

function A:CountVoted(idx)
	local t = A.rmVoted[idx]
	if not t then
		return 0
	end
	local n = 0
	for _, name in ipairs(A:VoterList()) do
		if t[A:NameKey(name)] then
			n = n + 1
		end
	end
	return n
end

function A:UpvoteCount(idx, player)
	local n = 0
	local t = A.upvotes[idx] and A.upvotes[idx][player]
	if t then
		for _, voter in ipairs(A:VoterList()) do
			if t[A:NameKey(voter)] then
				n = n + 1
			end
		end
	end
	return n
end

function A:ItemQuantity(itemOrIndex)
	local item = type(itemOrIndex) == "number" and A.items[itemOrIndex] or itemOrIndex
	return math.max(1, math.floor(tonumber(item and item.quantity) or 1))
end

function A:AwardCount(itemOrIndex)
	local item = type(itemOrIndex) == "number" and A.items[itemOrIndex] or itemOrIndex
	return math.max(0, math.floor(tonumber(item and item.awardedCount) or 0))
end

function A:IsFullyDistributed(itemOrIndex)
	return A:AwardCount(itemOrIndex) >= A:ItemQuantity(itemOrIndex)
end

function A:VoterSelectionCount(idx, voter)
	local key = A:NameKey(voter)
	if not key then return 0 end
	local count = 0
	for _, byVoter in pairs(A.upvotes[idx] or {}) do
		if byVoter[key] then count = count + 1 end
	end
	return count
end

function A:ItemStringFrom(link)
	if not link then
		return nil
	end
	return string.match(link, "item[%-?%d:]+")
end

local QMARK = "Interface\\Icons\\INV_Misc_QuestionMark"

function A:BuildItem(itemString)
	local name, link, _, _, _, _, _, _, _, texture = GetItemInfo(itemString)
	if link then
		return { itemString = itemString, link = link, name = name, texture = texture }
	end
	A:QueueResolve()
	return {
		itemString = itemString,
		link = itemString,
		name = itemString,
		texture = QMARK,
		needsInfo = true,
	}
end

function A:AnnouncementItemLink(item)
	if not item then return "[Item]" end
	local candidate = item.link
	if type(candidate) == "string" and string.find(candidate, "|Hitem:", 1, true) then return candidate end
	local name, resolved = GetItemInfo(item.itemString or candidate)
	if resolved and string.find(resolved, "|Hitem:", 1, true) then return resolved end
	local itemString = item.itemString or candidate
	if type(itemString) == "string" then
		local payload = string.match(itemString, "item[%-?%d:]+")
		if payload then return "|H" .. payload .. "|h[" .. tostring(name or item.name or "Item") .. "]|h" end
	end
	return item.name and ("[" .. item.name .. "]") or "[Item]"
end

local resolver = CreateFrame("Frame")
resolver:Hide()
resolver.acc = 0
resolver:SetScript("OnUpdate", function(self, elapsed)
	self.acc = (self.acc or 0) + (elapsed or 0.1)
	if self.acc < 0.5 then
		return
	end
	self.acc = 0
	local pending, changed = 0, false
	for _, it in ipairs(A.items) do
		if it.needsInfo then
			local name, link, _, _, _, _, _, _, _, texture = GetItemInfo(it.itemString)
			if link then
				it.link = link
				it.name = name
				it.texture = texture
				it.needsInfo = nil
				changed = true
			else
				pending = pending + 1
			end
		end
	end
	if changed then
		A:RefreshCouncil()
		A:RefreshRaider()
	end
	if pending == 0 then
		self:Hide()
	end
end)

function A:QueueResolve()
	resolver.acc = 0
	resolver:Show()
end

function A:Announce(msg)
	if not A:InGroup() then
		A:Print(msg)
		return
	end
	local channel
	if UnitInRaid("player") and (A:IsRaidLeader() or (IsRaidOfficer and IsRaidOfficer())) then
		channel = "RAID_WARNING"
	elseif UnitInRaid("player") then
		channel = "RAID"
	else
		channel = "PARTY"
	end

	-- Keep the complete GetItemInfo hyperlink intact. The visible separator is
	-- doubled because a lone pipe is parsed as an invalid chat escape code.
	local linkedMessage = tostring(msg or "")
	linkedMessage = string.gsub(linkedMessage, " | ", " || ")
	local sent = pcall(SendChatMessage, linkedMessage, channel)
	if not sent then
		-- Some custom Ascension item strings can still be rejected. Fall back to
		-- a safe visible label instead of raising a Lua error.
		local safeMessage = string.gsub(linkedMessage, "|H.-|h(.-)|h", "%1")
		safeMessage = string.gsub(safeMessage, "||", "\001")
		safeMessage = string.gsub(safeMessage, "|", "")
		safeMessage = string.gsub(safeMessage, "\001", "||")
		pcall(SendChatMessage, safeMessage, channel)
	end
end

A.MAX_ITEMS = 50

function A:AddItemLocal(itemString, adder, quantity)
	quantity = math.max(1, math.floor(tonumber(quantity) or 1))
	local now = GetTime and GetTime() or 0
	for _, it in ipairs(A.items) do
		local currentID = type(it.itemString) == "string" and string.match(it.itemString, "item:(%d+)")
		local addedID = type(itemString) == "string" and string.match(itemString, "item:(%d+)")
		if it.itemString == itemString or (currentID and addedID and currentID == addedID) then
			it.quantity = math.max(A:ItemQuantity(it), quantity)
			it.addedAt = now
			A:RefreshCouncil()
			return
		end
	end
	if table.getn(A.items) >= A.MAX_ITEMS then
		A:Print("Item limit reached (" .. A.MAX_ITEMS .. ").")
		return
	end
	local item = A:BuildItem(itemString)
	item.adder = adder
	item.addedAt = now
	item.quantity = quantity
	item.awardedCount = 0
	item.awardedPlayers = {}
	table.insert(A.items, item)
	A:RefreshCouncil()
end

function A:RemoveItemLocal(idx)
	if not A.items[idx] then
		return
	end
	table.remove(A.items, idx)
	table.remove(A.choices, idx)
	table.remove(A.upvotes, idx)
	table.remove(A.rmVoted, idx)
	table.remove(A.passes, idx)
	table.remove(A.winners, idx)
	table.remove(A.traded, idx)
	table.remove(A.notes, idx)
	table.remove(A.gear, idx)
	A:RefreshCouncil()
end

function A:RecalcVoted(idx)
	local voted = {}
	A.passes = A.passes or {}
	for key in pairs(A.passes[idx] or {}) do
		voted[key] = true
	end
	local selections = {}
	for _, byVoter in pairs(A.upvotes[idx] or {}) do
		for key in pairs(byVoter) do selections[key] = (selections[key] or 0) + 1 end
	end
	local required = A:ItemQuantity(idx)
	for key, count in pairs(selections) do
		if count >= required then voted[key] = true end
	end
	A.rmVoted[idx] = voted
end

function A:ClearSession()
	A.items = {}
	A.choices = {}
	A.upvotes = {}
	A.rmVoted = {}
	A.passes = {}
	A.winners = {}
	A.traded = {}
	A.notes = {}
	A.gear = {}
	A.started = false
	if A.StopTimer then
		A:StopTimer()
	end
	A:RefreshCouncil()
	A:RefreshRaider()
end

local ticker = CreateFrame("Frame")
ticker:Hide()
ticker.acc = 0
ticker:SetScript("OnUpdate", function(self, elapsed)
	self.acc = (self.acc or 0) + (elapsed or 0.1)
	if self.acc < 0.25 then
		return
	end
	self.acc = 0
	if not A.voteEnd then
		self:Hide()
		return
	end
	local left = A.voteEnd - GetTime()
	if left <= 0 then
		A.voteEnd = nil
		A.started = false
		self:Hide()
		A:HideRaiderList()
		A:RefreshRaider()
		A:RefreshCouncil()
		A:Print("Council roll window expired.")
		if A:NamesEqual(A.mlName, A.me) then
			A:Announce("DemiseRaidCouncil: council rolls are closed.")
		end
	else
		if left <= 10 and not A.warned10 then
			A.warned10 = true
			if A:NamesEqual(A.mlName, A.me) then
				A:Announce("DemiseRaidCouncil: 10 seconds remain for council rolls.")
			end
		end
		A:RefreshTimerText()
	end
end)

function A:TimeLeft()
	if not A.voteEnd then
		return nil
	end
	local left = A.voteEnd - GetTime()
	if left < 0 then
		left = 0
	end
	return left
end

function A:StartTimer(duration)
	duration = tonumber(duration) or 0
	A.voteDuration = duration
	A.warned10 = false
	if duration > 0 then
		A.voteEnd = GetTime() + duration
		ticker.acc = 0
		ticker:Show()
	else
		A.voteEnd = nil
		ticker:Hide()
	end
	A:RefreshTimerText()
end

function A:StopTimer()
	A.voteEnd = nil
	A.voteDuration = nil
	ticker:Hide()
	A:RefreshTimerText()
end

function A:VotingOpen()
	if not A.started then
		return false
	end
	local left = A:TimeLeft()
	if left and left <= 0 then
		return false
	end
	return true
end

A.NOTE_MAX = 100

local EQUIP_SLOTS = {
	INVTYPE_HEAD = { 1 },
	INVTYPE_NECK = { 2 },
	INVTYPE_SHOULDER = { 3 },
	INVTYPE_BODY = { 4 },
	INVTYPE_CHEST = { 5 },
	INVTYPE_ROBE = { 5 },
	INVTYPE_WAIST = { 6 },
	INVTYPE_LEGS = { 7 },
	INVTYPE_FEET = { 8 },
	INVTYPE_WRIST = { 9 },
	INVTYPE_HAND = { 10 },
	INVTYPE_FINGER = { 11, 12 },
	INVTYPE_TRINKET = { 13, 14 },
	INVTYPE_CLOAK = { 15 },
	INVTYPE_WEAPON = { 16, 17 },
	INVTYPE_2HWEAPON = { 16, 17 },
	INVTYPE_WEAPONMAINHAND = { 16 },
	INVTYPE_WEAPONOFFHAND = { 17 },
	INVTYPE_SHIELD = { 17 },
	INVTYPE_HOLDABLE = { 17 },
	INVTYPE_RANGED = { 18 },
	INVTYPE_RANGEDRIGHT = { 18 },
	INVTYPE_THROWN = { 18 },
	INVTYPE_RELIC = { 18 },
	INVTYPE_TABARD = { 19 },
}

-- Tier tokens do not expose an equip location. Map only explicitly supported
-- token names to their intended armor slot. Ordinary equippable items always
-- retain Blizzard's slot metadata.
local TOKEN_NAME_SLOTS = {
	["molten headpiece"] = { 1 },
	["molten tunic"] = { 5 },
	["molten spaulders"] = { 3 },
	["molten legguards"] = { 7 },
	["molten girdle"] = { 6 },
	["molten boots"] = { 8 },
	["molten handguards"] = { 10 },
	["molten wristguards"] = { 9 },
	["chromatic headpiece"] = { 1 },
	["chromatic tunic"] = { 5 },
	["chromatic spaulders"] = { 3 },
	["chromatic legguards"] = { 7 },
	["chromatic girdle"] = { 6 },
	["chromatic boots"] = { 8 },
	["chromatic handguards"] = { 10 },
	["chromatic wristguards"] = { 9 },
	["diadem of the desert prince"] = { 1 },
	["husk of the old god"] = { 5 },
	["bindings of the lost nomad"] = { 8 },
	["spaulders of the imperial guard"] = { 3 },
	["hardened qiraji chitin"] = { 7 },
}

local function InferTokenSlots(itemName)
	local lowerName = itemName and string.lower(itemName)
	if not lowerName or lowerName == "" then return nil end
	return TOKEN_NAME_SLOTS[lowerName]
end

-- Returns a "~" separated list of the item strings the player has equipped in
-- the same slot(s) as the given item.
function A:EquippedFor(itemString)
	if not itemString then
		return ""
	end
	local itemName, _, _, _, _, _, _, _, equipLoc = GetItemInfo(itemString)
	local slots = equipLoc and EQUIP_SLOTS[equipLoc]
	if not slots then
		slots = InferTokenSlots(itemName)
	end
	if not slots then
		return ""
	end
	local out = {}
	for _, slot in ipairs(slots) do
		local link = GetInventoryItemLink("player", slot)
		local str = link and A:ItemStringFrom(link)
		if str then
			table.insert(out, str)
		end
	end
	return table.concat(out, "~")
end

function A:GearList(idx, player)
	local raw = A.gear[idx] and A.gear[idx][player]
	if not raw or raw == "" then
		return {}
	end
	local out = {}
	for str in string.gmatch(raw, "[^~]+") do
		local _, link = GetItemInfo(str)
		table.insert(out, { itemString = str, link = link or str })
		if not link then
			A:QueueResolve()
		end
	end
	return out
end

function A:TryAddLink(link)
	if not link then
		return false
	end
	if DemiseRaidRollsMenu and DemiseRaidRollsMenu.GetActiveModule
		and DemiseRaidRollsMenu.GetActiveModule() ~= "council" then
		return false
	end
	if not A:InGroup() then
		A:Print("Join a party or raid before adding items to the council queue.")
		return false
	end
	if not A:IsCouncil() then
		A:Print("Only the master looter / council members can add items.")
		return false
	end
	if A.started then
		A:Print("Council rolls are already open - use /arrcouncil clear to reset the queue.")
		return false
	end
	local itemString = A:ItemStringFrom(link)
	if not itemString then
		return false
	end
	local now = GetTime()
	if A.lastAddString == itemString and A.lastAddTime and (now - A.lastAddTime) < 1 then
		return false
	end
	A.lastAddString = itemString
	A.lastAddTime = now
	local itemID = tonumber(string.match(itemString, "item:(%d+)"))
	local quantity = 1
	if DemiseRaidRolls and DemiseRaidRolls.TradeableItems and DemiseRaidRolls.TradeableItems.Count then
		quantity = DemiseRaidRolls.TradeableItems.Count(link, itemID)
	end
	A:BroadcastAdd(itemString, quantity)
	return true
end

function A:TryAddCursorItem()
	if not GetCursorInfo then return false end
	local kind, data1, data2 = GetCursorInfo()
	if kind ~= "item" then return false end
	local link = type(data2) == "string" and data2 or nil
	if (not link or link == "") and data1 and GetItemInfo then
		local _, resolved = GetItemInfo(data1)
		link = resolved
	end
	if A:TryAddLink(link) then
		if ClearCursor then ClearCursor() end
		return true
	end
	return false
end

local function TryAddFromContainer(bag, slot)
	if not IsShiftKeyDown() then
		return
	end
	if not bag or not slot then
		return
	end
	A:TryAddLink(GetContainerItemLink(bag, slot))
end

local function ContainerClickHook(a1, a2)
	local self, button
	if type(a1) == "table" then
		self, button = a1, a2
	else
		self, button = this, a1
	end
	if button ~= "RightButton" or not IsShiftKeyDown() then
		return
	end
	if not self or not self.GetID then
		return
	end
	local parent = self:GetParent()
	local bag = self.bagID or (parent and parent:GetID())
	TryAddFromContainer(bag, self:GetID())
end

if ContainerFrameItemButton_OnClick then
	hooksecurefunc("ContainerFrameItemButton_OnClick", ContainerClickHook)
end
if ContainerFrameItemButton_OnModifiedClick then
	hooksecurefunc("ContainerFrameItemButton_OnModifiedClick", ContainerClickHook)
end
if HandleModifiedItemClick then
	hooksecurefunc("HandleModifiedItemClick", function(link)
		if IsShiftKeyDown() then
			A:TryAddLink(link)
		end
	end)
end

local ev = CreateFrame("Frame")
ev:RegisterEvent("ADDON_LOADED")
ev:RegisterEvent("PLAYER_LOGIN")
ev:RegisterEvent("CHAT_MSG_ADDON")
ev:RegisterEvent("RAID_ROSTER_UPDATE")
ev:RegisterEvent("PARTY_MEMBERS_CHANGED")
ev:SetScript("OnEvent", function(self, event, ...)
	if event == "ADDON_LOADED" then
		local name = ...
		if name == "DemiseRaidRolls" then
			if RegisterAddonMessagePrefix then
				RegisterAddonMessagePrefix(A.PREFIX)
			end
			AscensionRaidCouncilDB = AscensionRaidCouncilDB or {}
			AscensionRaidCouncilDB.council = AscensionRaidCouncilDB.council or {}
			AscensionRaidCouncilDB.raiderPos = AscensionRaidCouncilDB.raiderPos or nil
			AscensionRaidCouncilDB.voteSeconds = AscensionRaidCouncilDB.voteSeconds or 60
			A.council = AscensionRaidCouncilDB.council
		end
	elseif event == "PLAYER_LOGIN" then
		A.me = A:Short(UnitName("player"))
		A:CreateCouncilFrame()
		A:CreateRaiderFrame()
		
		A:RequestCouncilSync()
		A:Print("Raid Council v" .. A.VERSION .. " by " .. A.AUTHOR .. " loaded. /arrcouncil for the council window, /arrcounciledit to move the raider list.")

	elseif event == "CHAT_MSG_ADDON" then
		A:OnAddonMessage(...)
	elseif event == "RAID_ROSTER_UPDATE" or event == "PARTY_MEMBERS_CHANGED" then
		if A.RefreshCouncil then
			A:RefreshCouncil()
		end
		if A.RefreshRMList then
			A:RefreshRMList()
		end
		local now = GetTime()
		if not A.lastSync or (now - A.lastSync) > 5 then
			A.lastSync = now
			if A:IsML() then
				A:BroadcastCouncil()
			else
				A:RequestCouncilSync()
			end
		end
	end
end)

SLASH_DEMISERAIDCOUNCIL1 = "/arrcouncil"
SlashCmdList["DEMISERAIDCOUNCIL"] = function(msg)
	msg = msg or ""
	local lower = string.lower(msg)
	if lower == "clear" then
		A:BroadcastEnd()
		A:ClearSession()
		return
	end
	if string.find(lower, "^add") then
		local link = string.match(msg, "|c.-|h.-|h|r")
		if link then
			A:TryAddLink(link)
		else
			A:Print("Usage: /arrcouncil add [shift-click the item link]")
		end
		return
	end
	if lower == "sync" then
		if A:IsML() then
			A:BroadcastCouncil()
			A:Print("Council list broadcast to the raid.")
		else
			A:RequestCouncilSync()
			A:Print("Requested the council list from the raid leader.")
		end
		return
	end
	if lower == "lead" then
		A.isLeaderFallback = not A.isLeaderFallback
		A:Print("Leader mode: " .. (A.isLeaderFallback and "ON" or "OFF"))
		A:RefreshCouncil()
		return
	end
	A:ToggleCouncilFrame()
end

SLASH_DEMISERAIDCOUNCILEDIT1 = "/arrcounciledit"
SlashCmdList["DEMISERAIDCOUNCILEDIT"] = function()
	A:ToggleRaiderEdit()
end
