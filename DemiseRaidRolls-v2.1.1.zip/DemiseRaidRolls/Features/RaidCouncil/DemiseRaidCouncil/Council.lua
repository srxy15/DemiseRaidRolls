local A = DemiseRaidCouncil

local GOLD = { 1.0, 0.78, 0.20 }
local FRAME_W, FRAME_H = 760, 520
local VIEWER_W, VIEWER_H = 520, 250

local SOLID = {
	bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
	edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
	tile = true,
	tileSize = 32,
	edgeSize = 32,
	insets = { left = 11, right = 12, top = 12, bottom = 11 },
}
local THIN = {
	bgFile = "Interface\\Buttons\\WHITE8X8",
	edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
	tile = true,
	tileSize = 16,
	edgeSize = 10,
	insets = { left = 2, right = 2, top = 2, bottom = 2 },
}
local function GoldButton(parent, w, h, text, fontObj)
	local b = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
	b:SetWidth(w)
	b:SetHeight(h)
	b:SetText(text)
	local fs = b:GetFontString()
	if fontObj then
		local object = getglobal and getglobal(fontObj) or nil
		if object then
			if b.SetNormalFontObject then b:SetNormalFontObject(object) end
			if b.SetHighlightFontObject then b:SetHighlightFontObject(object) end
			if b.SetDisabledFontObject then b:SetDisabledFontObject(object) end
			fs:SetFontObject(object)
		else
			fs:SetFontObject(fontObj)
		end
	end
	fs:SetTextColor(1, 0.95, 0.8)
	b.label = fs
	function b:Tint(r, g, bl)
		local n, p, hl = self:GetNormalTexture(), self:GetPushedTexture(), self:GetHighlightTexture()
		if n then
			n:SetVertexColor(r, g, bl)
		end
		if p then
			p:SetVertexColor(r, g, bl)
		end
		if hl then
			hl:SetVertexColor(r, g, bl)
		end
	end
	function b:SetRed(on)
		if on then
			self:Tint(1, 0.35, 0.3)
			self.label:SetTextColor(1, 0.85, 0.8)
		else
			self:Tint(1, 1, 1)
			self.label:SetTextColor(1, 0.95, 0.8)
		end
	end

	function b:SetGrey(on)
		if on then
			self:Tint(0.62, 0.62, 0.62)
			self.label:SetTextColor(0.78, 0.78, 0.78)
		else
			self:Tint(1, 1, 1)
			self.label:SetTextColor(1, 0.95, 0.8)
		end
	end

	function b:SetEnabledLook(on)
		if on then
			self:Enable()
		else
			self:Disable()
		end
	end
	return b
end
A.GoldButton = GoldButton

local function CouncilButton(parent, w, h, text, fontObj)
	local b = GoldButton(parent, w, h, text, fontObj)
	function b:SetRed(on)
		self:Tint(1, 1, 1)
		self.label:SetTextColor(1.0, 0.82, 0.15)
	end
	function b:SetGrey(on)
		if on then
			self:Tint(0.62, 0.62, 0.62)
			self.label:SetTextColor(0.78, 0.78, 0.78)
		else
			self:Tint(1, 1, 1)
			self.label:SetTextColor(1.0, 0.82, 0.15)
		end
	end
	b:SetRed(false)
	return b
end

local function StyleEditBox(edit)
	edit:SetBackdrop(THIN)
	edit:SetBackdropColor(0.03, 0.03, 0.03, 0.96)
	edit:SetBackdropBorderColor(0.45, 0.45, 0.45, 1)
	if edit.SetTextInsets then edit:SetTextInsets(7, 7, 0, 0) end
	edit:SetFontObject("GameFontHighlightSmall")
end

local function MakeOpaque(frame)
	local background = frame:CreateTexture(nil, "BACKGROUND")
	background:SetTexture("Interface\\Buttons\\WHITE8X8")
	background:SetVertexColor(0.025, 0.025, 0.025, 1)
	background:SetPoint("TOPLEFT", frame, "TOPLEFT", 12, -12)
	background:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -12, 12)
	frame.opaqueBackground = background
end

local function AnchorPopupScrollBar(scroll, parent, topOffset, bottomOffset)
	local scrollBar = getglobal(scroll:GetName() .. "ScrollBar")
	if not scrollBar then
		return
	end
	scrollBar:ClearAllPoints()
	scrollBar:SetPoint("TOPRIGHT", parent, "TOPRIGHT", -12, topOffset)
	scrollBar:SetPoint("BOTTOMRIGHT", parent, "BOTTOMRIGHT", -12, bottomOffset)
end

local function ItemTooltip(self)
	if self.link then
		GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
		GameTooltip:SetHyperlink(self.link)
		GameTooltip:Show()
	end
end
local function HideTooltip()
	GameTooltip:Hide()
end
A.ItemTooltip = ItemTooltip
A.HideTooltip = HideTooltip

A.expanded = {}

local MAX_RM = 20
local COUNCIL_STAR = "Interface\\TargetingFrame\\UI-RaidTargetingIcon_1"

local function IsConfiguredCouncilMember(name)
	for i, existing in ipairs(A.council) do
		if A:NamesEqual(existing, name) then
			return true, i
		end
	end
	return false, nil
end

local function RaidRosterNames()
	local names = {}
	local count = GetNumRaidMembers and GetNumRaidMembers() or 0
	for i = 1, count do
		local name = UnitName("raid" .. i)
		if name and name ~= "" then
			table.insert(names, A:Short(name))
		end
	end
	return names
end

local function CurrentMasterLooterName()
	return A:MasterLooterName()
end

local function CreateRMPopup(parent)
	local p = CreateFrame("Frame", "DemiseRaidCouncilRMPopup", parent)
	p:SetFrameStrata("HIGH")
	p:SetWidth(260)
	p:SetHeight(360)
	p:SetPoint("TOPLEFT", parent, "TOPLEFT", 16, -96)
	p:SetBackdrop(SOLID)
	MakeOpaque(p)
	p:SetFrameLevel(parent:GetFrameLevel() + 10)
	p:EnableMouse(true)
	p:Hide()

	local label = p:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
	label:SetPoint("TOPLEFT", 12, -12)
	label:SetTextColor(GOLD[1], GOLD[2], GOLD[3])
	p.label = label

	local eb = CreateFrame("EditBox", "DemiseRaidCouncilRMEdit", p)
	eb:SetPoint("TOPLEFT", 16, -32)
	eb:SetWidth(150)
	eb:SetHeight(24)
	eb:SetAutoFocus(false)
	StyleEditBox(eb)
	p.edit = eb

	local add = CouncilButton(p, 66, 22, "Add")
	add:SetPoint("LEFT", eb, "RIGHT", 8, 0)
	p.addButton = add

	local scroll = CreateFrame("ScrollFrame", "DemiseRaidCouncilRMScroll", p, "UIPanelScrollFrameTemplate")
	scroll:SetPoint("TOPLEFT", 12, -62)
	scroll:SetPoint("BOTTOMRIGHT", -30, 12)
	AnchorPopupScrollBar(scroll, p, -66, 30)
	local child = CreateFrame("Frame", nil, scroll)
	child:SetWidth(200)
	child:SetHeight(10)
	scroll:SetScrollChild(child)
	p.scroll = scroll
	p.content = child
	p.rmRows = {}
	p.rmHeaders = {}

	local function Save()
		AscensionRaidCouncilDB.council = A.council
		A:BroadcastCouncil()
		A:RefreshRMList()
		A:RefreshCouncil()
	end

	local function AddName()
		local n = string.gsub(eb:GetText() or "", "^%s*(.-)%s*$", "%1")
		eb:SetText("")
		if n == "" then
			return
		end
		if A:CouncilCount() >= MAX_RM then
			A:Print("Max " .. MAX_RM .. " council members.")
			return
		end
		for _, existing in ipairs(A.council) do
			if string.lower(existing) == string.lower(n) then
				return
			end
		end
		table.insert(A.council, n)
		Save()
	end

	add:SetScript("OnClick", AddName)
	eb:SetScript("OnEnterPressed", AddName)
	eb:SetScript("OnEscapePressed", function()
		eb:ClearFocus()
		p:Hide()
	end)

	A.rmPopupRef = p
	return p
end

local function GetRMRow(i)
	local p = A.rmPopupRef
	local row = p.rmRows[i]
	if row then
		return row
	end
	row = CreateFrame("Frame", nil, p.content)
	row:SetWidth(196)
	row:SetHeight(22)
	row.bg = row:CreateTexture(nil, "BACKGROUND")
	row.bg:SetTexture("Interface\\Buttons\\WHITE8X8")
	row.bg:SetAllPoints(row)
	row.bg:SetVertexColor(0.045, 0.045, 0.045, 0.92)
	row.text = row:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
	row.text:SetPoint("LEFT", 30, 0)
	row.text:SetPoint("RIGHT", -28, 0)
	row.text:SetJustifyH("LEFT")
	row.text:SetTextColor(1, 1, 1)
	row.select = CreateFrame("Button", nil, row)
	row.select:SetWidth(20)
	row.select:SetHeight(20)
	row.select:SetPoint("LEFT", 4, 0)
	row.select:SetNormalTexture(COUNCIL_STAR)
	row.select:SetHighlightTexture("Interface\\Buttons\\ButtonHilight-Square")
	row.select:SetScript("OnEnter", function(self)
		GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
		if self.locked then
			GameTooltip:SetText("Master Looter")
			GameTooltip:AddLine("The Master Looter is always a council member.", 1, 1, 1, true)
		else
			GameTooltip:SetText(self.active and "Remove from council" or "Add to council")
			GameTooltip:AddLine("Council members can view responses and cast decisions.", 1, 1, 1, true)
		end
		GameTooltip:Show()
	end)
	row.select:SetScript("OnLeave", function() GameTooltip:Hide() end)
	row.del = CouncilButton(row, 20, 18, "-")
	row.del:SetPoint("RIGHT", -4, 0)
	p.rmRows[i] = row
	return row
end

local function GetRMHeader(i)
	local p = A.rmPopupRef
	local header = p.rmHeaders[i]
	if header then
		return header
	end
	header = p.content:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
	header:SetWidth(196)
	header:SetHeight(18)
	header:SetJustifyH("LEFT")
	header:SetTextColor(GOLD[1], GOLD[2], GOLD[3])
	p.rmHeaders[i] = header
	return header
end

function A:RefreshRMList()
	local p = A.rmPopupRef
	if not p then
		return
	end
	for _, r in ipairs(p.rmRows) do
		r:Hide()
	end
	for _, header in ipairs(p.rmHeaders) do
		header:Hide()
	end
	local raidNames = RaidRosterNames()
	local inRaid = table.getn(raidNames) > 0
	if inRaid then
		p.edit:Hide()
		p.addButton:Hide()
	else
		p.edit:Show()
		p.addButton:Show()
	end
	p.scroll:ClearAllPoints()
	p.scroll:SetPoint("TOPLEFT", 12, inRaid and -27 or -62)
	p.scroll:SetPoint("BOTTOMRIGHT", -30, 12)
	AnchorPopupScrollBar(p.scroll, p, inRaid and -31 or -66, 30)

	local displayNames = A.council
	local councilNames, regularNames = {}, {}
	local masterLooter = inRaid and CurrentMasterLooterName() or nil
	if inRaid then
		for _, name in ipairs(raidNames) do
			local selected = IsConfiguredCouncilMember(name)
			if masterLooter and A:NamesEqual(name, masterLooter) then
				-- The Master Looter has a dedicated, implicit category.
			elseif selected then
				table.insert(councilNames, name)
			else
				table.insert(regularNames, name)
			end
		end
		displayNames = {}
		if masterLooter then table.insert(displayNames, masterLooter) end
		for _, name in ipairs(councilNames) do table.insert(displayNames, name) end
		for _, name in ipairs(regularNames) do table.insert(displayNames, name) end
	end
	local y = 2
	local rowIndex = 0
	local headerIndex = 0
	local function AddHeader(text)
		headerIndex = headerIndex + 1
		local header = GetRMHeader(headerIndex)
		header:ClearAllPoints()
		header:SetPoint("TOPLEFT", 2, -y)
		header:SetText(text)
		header:Show()
		y = y + 20
	end
	local masterCount = masterLooter and 1 or 0
	local councilHeaderAdded = false
	local raidHeaderAdded = false
	for i, name in ipairs(displayNames) do
		if inRaid and i == masterCount + 1 then
			y = y + 4
			AddHeader("Council members (" .. table.getn(councilNames) .. ")")
			councilHeaderAdded = true
		end
		if inRaid and i == masterCount + table.getn(councilNames) + 1 then
			y = y + 4
			AddHeader("Raid members (" .. table.getn(regularNames) .. ")")
			raidHeaderAdded = true
		end
		local councilIndex = i
		rowIndex = rowIndex + 1
		local r = GetRMRow(rowIndex)
		r:ClearAllPoints()
		r:SetPoint("TOPLEFT", 0, -y)
		r:Show()
		r.text:SetText(name)
		local cr, cg, cb = A:PlayerClassColor(name)
		r.text:SetTextColor(cr, cg, cb)
		if inRaid then
			local rosterName = name
			local isMasterLooter = masterLooter and A:NamesEqual(rosterName, masterLooter)
			local active = isMasterLooter or IsConfiguredCouncilMember(rosterName)
			r.text:ClearAllPoints()
			r.text:SetPoint("LEFT", 30, 0)
			r.text:SetPoint("RIGHT", -4, 0)
			r.select.active = active
			r.select.locked = isMasterLooter
			local texture = r.select:GetNormalTexture()
			if texture then
				texture:SetVertexColor(active and 1 or 0.35, active and 0.82 or 0.35, active and 0 or 0.35, active and 1 or 0.7)
			end
			r.select:SetScript("OnClick", function()
				if isMasterLooter then
					A:Print("The Master Looter is always a council member.")
					return
				end
				local selected, selectedIndex = IsConfiguredCouncilMember(rosterName)
				if selected then
					table.remove(A.council, selectedIndex)
				elseif A:CouncilCount() < MAX_RM then
					table.insert(A.council, rosterName)
				else
					A:Print("Max " .. MAX_RM .. " council members.")
					return
				end
				AscensionRaidCouncilDB.council = A.council
				A:BroadcastCouncil()
				A:RefreshRMList()
				A:RefreshCouncil()
			end)
			r.select:Show()
			r.del:Hide()
		else
			r.select:Hide()
			r.text:ClearAllPoints()
			r.text:SetPoint("LEFT", 8, 0)
			r.text:SetPoint("RIGHT", -28, 0)
			r.del:Show()
			r.del:SetEnabledLook(true)
			r.del:SetScript("OnClick", function()
				table.remove(A.council, councilIndex)
				AscensionRaidCouncilDB.council = A.council
				A:BroadcastCouncil()
				A:RefreshRMList()
				A:RefreshCouncil()
			end)
		end
		y = y + 24
	end
	if inRaid and not councilHeaderAdded then
		y = y + 4
		AddHeader("Council members (" .. table.getn(councilNames) .. ")")
	end
	if inRaid and not raidHeaderAdded then
		y = y + 4
		AddHeader("Raid members (" .. table.getn(regularNames) .. ")")
	end
	p.content:SetHeight(y + 4)
	p.label:SetText(inRaid and "Council Master" or ("Council members (" .. A:CouncilCount() .. "/" .. MAX_RM .. ")"))
end

local function StepToScale(v)
	v = tonumber(v) or 5
	if v < 1 then
		v = 1
	elseif v > 10 then
		v = 10
	end
	return 0.6 + (v - 1) * 0.1
end

function A:GetScaleStep(which)
	AscensionRaidCouncilDB = AscensionRaidCouncilDB or {}
	local v = AscensionRaidCouncilDB[which]
	if not v then
		v = 5
	end
	return v
end

function A:ApplyScales()
	if A.frame then
		A.frame:SetScale(StepToScale(A:GetScaleStep("councilScale")))
	end
	if A.rframe then
		A.rframe:SetScale(StepToScale(A:GetScaleStep("raiderScale")))
	end
end

local function MakeScaleSlider(parent, name, label, key, yOff)
	local s = CreateFrame("Slider", name, parent, "OptionsSliderTemplate")
	s:SetPoint("TOPLEFT", 18, yOff)
	s:SetWidth(210)
	s:SetMinMaxValues(1, 10)
	s:SetValueStep(1)
	getglobal(name .. "Low"):SetText("1")
	getglobal(name .. "High"):SetText("10")
	local text = getglobal(name .. "Text")
	text:SetText(label .. ": " .. A:GetScaleStep(key))
	s.pending = A:GetScaleStep(key)
	s:SetScript("OnValueChanged", function(self)
		local v = self.GetValue and self:GetValue() or this:GetValue()
		v = math.floor(v + 0.5)
		s.pending = v
		text:SetText(label .. ": " .. v)
	end)
	s.key = key
	s.labelText = text
	s.labelPrefix = label
	return s
end

function A:CreateSettingsPopup(parent)
	local p = CreateFrame("Frame", "DemiseRaidCouncilSettings", parent)
	p:SetFrameStrata("HIGH")
	p:SetWidth(260)
	p:SetHeight(170)
	p:SetPoint("TOPLEFT", parent, "TOPLEFT", 16, -96)
	p:SetBackdrop(SOLID)
	p:SetBackdropColor(0.04, 0.04, 0.04, 0.98)
	p:SetBackdropBorderColor(0.55, 0.55, 0.55, 1)
	p:SetFrameLevel(parent:GetFrameLevel() + 10)
	p:EnableMouse(true)
	p:Hide()

	local title = p:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
	title:SetPoint("TOPLEFT", 12, -12)
	title:SetText("Settings")
	title:SetTextColor(GOLD[1], GOLD[2], GOLD[3])

	p.council = MakeScaleSlider(p, "DemiseRaidCouncilScaleCouncil", "Council window size", "councilScale", -46)
	p.raider = MakeScaleSlider(p, "DemiseRaidCouncilScaleRaider", "Vote boxes size", "raiderScale", -96)

	local apply = CouncilButton(p, 90, 22, "Apply")
	apply:SetPoint("BOTTOMLEFT", 12, 12)
	apply:SetScript("OnClick", function()
		AscensionRaidCouncilDB.councilScale = p.council.pending or A:GetScaleStep("councilScale")
		AscensionRaidCouncilDB.raiderScale = p.raider.pending or A:GetScaleStep("raiderScale")
		A:ApplyScales()
	end)

	local close = CouncilButton(p, 90, 22, "Close")
	close:SetPoint("BOTTOMRIGHT", -12, 12)
	close:SetScript("OnClick", function()
		p:Hide()
	end)

	A.settingsPopupRef = p
	return p
end

function A:RefreshSettings()
	local p = A.settingsPopupRef
	if not p then
		return
	end
	p.council.pending = A:GetScaleStep("councilScale")
	p.raider.pending = A:GetScaleStep("raiderScale")
	p.council:SetValue(A:GetScaleStep("councilScale"))
	p.raider:SetValue(A:GetScaleStep("raiderScale"))
end

function A:HistoryList()
	AscensionRaidCouncilDB = AscensionRaidCouncilDB or {}
	AscensionRaidCouncilDB.history = AscensionRaidCouncilDB.history or {}
	return AscensionRaidCouncilDB.history
end

function A:HistoryDeleted()
	AscensionRaidCouncilDB = AscensionRaidCouncilDB or {}
	AscensionRaidCouncilDB.histDeleted = AscensionRaidCouncilDB.histDeleted or {}
	return AscensionRaidCouncilDB.histDeleted
end

function A:NewHistoryId(player)
	local t = time and time() or 0
	return (A:NameKey(player) or "x") .. "-" .. t .. "-" .. math.random(1000, 999999)
end

function A:AddHistoryEntry(e)
	if not e or not e.id then
		return false
	end
	if A:HistoryDeleted()[e.id] then
		return false
	end
	local h = A:HistoryList()
	for _, old in ipairs(h) do
		if old.id == e.id then
			return false
		end
	end
	table.insert(h, e)
	table.sort(h, function(a1, b1)
		return (a1.time or 0) < (b1.time or 0)
	end)
	return true
end

function A:RemoveHistoryId(id)
	if not id then
		return false
	end
	A:HistoryDeleted()[id] = true
	local h = A:HistoryList()
	for i, e in ipairs(h) do
		if e.id == id then
			table.remove(h, i)
			return true
		end
	end
	return false
end

function A:HistorySig()
	local sum = 0
	for _, e in ipairs(A:HistoryList()) do
		local id = e.id or ""
		for i = 1, string.len(id) do
			sum = (sum + string.byte(id, i) * i)
			if sum > 1000000000 then
				sum = sum - 1000000000
			end
		end
	end
	return table.getn(A:HistoryList()), sum
end

function A:ClearHistory()
	local history = A:HistoryList()
	local deleted = A:HistoryDeleted()
	local ids = {}
	for _, entry in ipairs(history) do
		if entry.id then
			deleted[entry.id] = true
			table.insert(ids, entry.id)
		end
	end
	AscensionRaidCouncilDB.history = {}
	A.histExpanded = {}
	A.histItemExpanded = {}
	if A.CanSyncHistory and A:CanSyncHistory() then
		for _, id in ipairs(ids) do
			A:SendQueued("Y^" .. id)
		end
	end
	A:RefreshHistory()
	A:Print("Award logs cleared.")
end

function A:AddHistory(player, item, choice)
	local e = {
		id = A:NewHistoryId(player),
		player = player,
		link = item and item.link or "",
		name = item and (item.name or item.link) or "",
		choice = choice or "",
		time = time and time() or 0,
	}
	A:AddHistoryEntry(e)
	if A.BroadcastHistoryEntry then
		A:BroadcastHistoryEntry(e)
	end
	if A.RefreshHistory then
		A:RefreshHistory()
	end
end

function A:OnAwardTradeCompleted(pending)
	if not pending then return end
	local itemIndex = tonumber(pending.itemIndex)
	if not itemIndex or A.items[itemIndex] ~= pending.item then
		itemIndex = nil
		for index, item in ipairs(A.items) do
			if item == pending.item
				or (pending.item and item.itemString and item.itemString == pending.item.itemString)
				or (pending.item and item.link and item.link == pending.item.link) then
				itemIndex = index
				break
			end
		end
	end
	local item = itemIndex and A.items[itemIndex] or pending.item
	if not item then return end
	item.awardedPlayers = item.awardedPlayers or {}
	local playerKey = A:NameKey(pending.player)
	if playerKey and item.awardedPlayers[playerKey] then
		A:Print("This player has already received a copy from this council lot.")
		return
	end
	if A:IsFullyDistributed(item) then
		A:Print("Every copy in this council lot has already been distributed.")
		return
	end
	if playerKey then item.awardedPlayers[playerKey] = true end
	item.awardedCount = A:AwardCount(item) + 1
	if itemIndex then
		A.traded = A.traded or {}
		A.traded[itemIndex] = item.awardedCount
		A.expanded = A.expanded or {}
		if A:IsFullyDistributed(item) then A.expanded[itemIndex] = nil end
		A:BroadcastTraded(itemIndex, item.awardedCount)
	end
	A:AddHistory(pending.player, item, pending.choice)
	A:Print("Loot distributed (" .. tostring(item.awardedCount) .. "/" .. tostring(A:ItemQuantity(item)) .. "): " .. (item.link or "") .. " -> " .. tostring(pending.player) .. " | " .. A:ChoiceLabel(pending.choice))
	A:RefreshCouncil()
end

A.histExpanded = {}
A.histItemExpanded = {}
A.histEdit = true
A.histSearch = ""

function A:BuildHistoryExport()
	local lines = { "Player - Item - Reason - Date" }
	for _, entry in ipairs(A:HistoryList()) do
		local itemName = entry.name or entry.link or "Unknown item"
		if entry.link and GetItemInfo then
			local resolvedName = GetItemInfo(entry.link)
			if resolvedName then itemName = resolvedName end
		end
		itemName = string.match(itemName, "%[(.-)%]") or itemName
		itemName = string.gsub(itemName, "|c%x%x%x%x%x%x%x%x", "")
		itemName = string.gsub(itemName, "|r", "")
		itemName = string.gsub(itemName, "[\r\n]", " ")
		local awardedAt = "Date unknown"
		if entry.time and entry.time > 0 and date then awardedAt = date("%Y-%m-%d %H:%M", entry.time) end
		lines[#lines + 1] = tostring(entry.player or "Unknown")
			.. " - " .. tostring(itemName)
			.. " - " .. tostring(A:ChoiceLabel(entry.choice or ""))
			.. " - " .. tostring(awardedAt)
	end
	return table.concat(lines, "\n"), #lines
end

function A:ShowHistoryExport()
	local frame = A.historyExportFrame
	if not frame then
		frame = CreateFrame("Frame", "DemiseRaidCouncilHistoryExport", UIParent)
		frame:SetWidth(620); frame:SetHeight(430); frame:SetPoint("CENTER"); frame:SetFrameStrata("FULLSCREEN_DIALOG")
		frame:SetClampedToScreen(true); frame:EnableMouse(true); frame:SetMovable(true); frame:RegisterForDrag("LeftButton")
		frame:SetScript("OnDragStart", function(self) self:StartMoving() end)
		frame:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end)
		frame:SetBackdrop(SOLID); MakeOpaque(frame)
		local title = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
		title:SetPoint("TOP", 0, -18); title:SetText("Export Award Logs")
		local help = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
		help:SetPoint("TOP", 0, -48); help:SetWidth(560); help:SetJustifyH("CENTER")
		help:SetText("Click Copy, then press Ctrl+C.")
		frame.help = help
		local close = CreateFrame("Button", nil, frame, "UIPanelCloseButton"); close:SetPoint("TOPRIGHT", -4, -4)
		local scroll = CreateFrame("ScrollFrame", "DemiseRaidCouncilHistoryExportScroll", frame, "UIPanelScrollFrameTemplate")
		scroll:SetPoint("TOPLEFT", 28, -70); scroll:SetPoint("BOTTOMRIGHT", -48, 54)
		local content = CreateFrame("Frame", nil, scroll)
		content:SetWidth(525); content:SetHeight(300)
		content:SetBackdrop(THIN)
		content:SetBackdropColor(0.02, 0.02, 0.02, 0.98)
		content:SetBackdropBorderColor(0.45, 0.45, 0.45, 1)
		local background = content:CreateTexture(nil, "BACKGROUND")
		background:SetTexture("Interface\\Buttons\\WHITE8X8"); background:SetVertexColor(0.02, 0.02, 0.02, 0.98)
		background:SetAllPoints(content)
		local text = content:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
		text:SetPoint("TOPLEFT", 8, -8); text:SetWidth(509); text:SetJustifyH("LEFT"); text:SetJustifyV("TOP")
		scroll:SetScrollChild(content)
		local copyEdit = CreateFrame("EditBox", nil, frame)
		copyEdit:SetWidth(1); copyEdit:SetHeight(1); copyEdit:SetPoint("BOTTOMLEFT", 20, 20)
		copyEdit:SetMultiLine(true); copyEdit:SetAutoFocus(false); copyEdit:SetAlpha(0); copyEdit:EnableMouse(false)
		copyEdit:SetScript("OnEscapePressed", function(self) self:ClearFocus(); frame:Hide() end)
		local copyButton = CouncilButton(frame, 150, 24, "Copy")
		copyButton:SetPoint("BOTTOM", 0, 20)
		copyButton:SetScript("OnClick", function()
			copyEdit:ClearFocus()
			copyEdit:SetText(frame.exportText or "")
			copyEdit:SetFocus()
			copyEdit:HighlightText()
			content:SetBackdropBorderColor(0.25, 1.0, 0.4, 1)
			copyButton.label:SetText("Selected")
			copyButton.label:SetTextColor(0.25, 1.0, 0.4)
			frame.help:SetText("Text selected - press Ctrl+C now.")
			frame.help:SetTextColor(0.25, 1.0, 0.4)
		end)
		close:SetScript("OnClick", function() copyEdit:ClearFocus(); frame:Hide() end)
		frame.content = content
		frame.text = text
		frame.copyEdit = copyEdit
		frame.copyButton = copyButton
		A.historyExportFrame = frame
	end
	local export, lineCount = A:BuildHistoryExport()
	frame.exportText = export
	frame.text:SetText(export)
	local textHeight = frame.text.GetStringHeight and frame.text:GetStringHeight() or ((lineCount or 1) * 16)
	frame.content:SetHeight(math.max(300, textHeight + 20))
	frame.copyEdit:SetText(export)
	frame.help:SetText("Click Copy, then press Ctrl+C.")
	frame.help:SetTextColor(1, 1, 1)
	frame.content:SetBackdropBorderColor(0.45, 0.45, 0.45, 1)
	if frame.copyButton then
		frame.copyButton.label:SetText("Copy")
		frame.copyButton.label:SetTextColor(GOLD[1], GOLD[2], GOLD[3])
	end
	frame:Show()
end

local function CreateHistoryPopup(parent)
	local p = CreateFrame("Frame", "DemiseRaidCouncilHistory", parent)
	p:SetFrameStrata("HIGH")
	p:SetWidth(420)
	p:SetHeight(400)
	p:SetPoint("TOPLEFT", parent, "TOPLEFT", 16, -96)
	p:SetBackdrop(SOLID)
	MakeOpaque(p)
	p:SetFrameLevel(parent:GetFrameLevel() + 10)
	p:EnableMouse(true)
	p:Hide()

	local title = p:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
	title:SetPoint("TOPLEFT", 12, -12)
	title:SetText("Award history")
	title:SetTextColor(GOLD[1], GOLD[2], GOLD[3])
	p.title = title

	local sLabel = p:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
	sLabel:SetPoint("TOPLEFT", 16, -34)
	sLabel:SetText("Search")
	sLabel:SetTextColor(GOLD[1], GOLD[2], GOLD[3])

	local eb = CreateFrame("EditBox", "DemiseRaidCouncilHistorySearch", p)
	eb:SetPoint("LEFT", sLabel, "RIGHT", 12, 0)
	eb:SetWidth(230)
	eb:SetHeight(22)
	eb:SetAutoFocus(false)
	StyleEditBox(eb)
	eb:SetScript("OnTextChanged", function(self)
		local box = self or this
		A.histSearch = string.lower(box:GetText() or "")
		A:RefreshHistory()
	end)
	eb:SetScript("OnEscapePressed", function(self)
		local box = self or this
		box:SetText("")
		box:ClearFocus()
	end)
	eb:SetScript("OnEnterPressed", function(self)
		local box = self or this
		box:ClearFocus()
	end)
	p.search = eb

	local scroll = CreateFrame("ScrollFrame", "DemiseRaidCouncilHistoryScroll", p, "UIPanelScrollFrameTemplate")
	scroll:SetPoint("TOPLEFT", 12, -62)
	scroll:SetPoint("BOTTOMRIGHT", -30, 60)
	AnchorPopupScrollBar(scroll, p, -66, 62)
	local child = CreateFrame("Frame", nil, scroll)
	child:SetWidth(360)
	child:SetHeight(10)
	scroll:SetScrollChild(child)
	p.content = child
	p.hrows = {}

	local syncBtn = CouncilButton(p, 70, 22, "Sync")
	syncBtn:SetPoint("BOTTOMLEFT", 12, 12)
	syncBtn:SetScript("OnClick", function()
		A:RequestHistorySync()
	end)
	syncBtn:SetScript("OnEnter", function(self)
		GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
		GameTooltip:SetText("Synchronize award history")
		GameTooltip:AddLine("Retrieve missing awards and removals from the other council members.", 1, 1, 1, true)
		GameTooltip:Show()
	end)
	syncBtn:SetScript("OnLeave", function() GameTooltip:Hide() end)
	p.syncBtn = syncBtn

	local exportBtn = CouncilButton(p, 90, 22, "Export Logs")
	exportBtn:SetPoint("BOTTOM", 0, 12)
	exportBtn:SetScript("OnClick", function()
		A:ShowHistoryExport()
	end)
	p.exportBtn = exportBtn

	local clearBtn = CouncilButton(p, 90, 22, "Clear Logs")
	clearBtn:SetPoint("BOTTOMRIGHT", -12, 12)
	clearBtn:SetScript("OnClick", function()
		if table.getn(A:HistoryList()) == 0 then
			A:Print("There are no award logs to clear.")
			return
		end
		StaticPopupDialogs["ARLC_CLEAR_AWARD_LOGS"] = StaticPopupDialogs["ARLC_CLEAR_AWARD_LOGS"] or {
			text = "Clear all award logs? This cannot be undone.",
			button1 = "Clear Logs",
			button2 = "Cancel",
			OnAccept = function() A:ClearHistory() end,
			timeout = 0,
			whileDead = true,
			hideOnEscape = true,
			preferredIndex = 3,
		}
		StaticPopup_Show("ARLC_CLEAR_AWARD_LOGS")
	end)
	p.clearBtn = clearBtn

	A.historyPopupRef = p
	return p
end

local function GetHistRow(i)
	local p = A.historyPopupRef
	local row = p.hrows[i]
	if row then
		return row
	end
	row = CreateFrame("Button", nil, p.content)
	row:SetHeight(20)
	row:SetWidth(350)
	row:SetBackdrop(THIN)
	row:SetBackdropColor(0, 0, 0, 0)
	row:SetBackdropBorderColor(0, 0, 0, 0)
	row.text = row:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
	row.text:SetPoint("LEFT", 10, 0)
	row.text:SetJustifyH("LEFT")
	row.right = row:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
	row.right:SetPoint("RIGHT", -34, 0)
	row.right:SetJustifyH("RIGHT")
	row.del = CouncilButton(row, 18, 16, "-")
	row.del:SetPoint("RIGHT", -6, 0)
	row.del:SetRed(true)
	row.del:Hide()
	p.hrows[i] = row
	return row
end

function A:RefreshHistory()
	local p = A.historyPopupRef
	if not p then
		return
	end
	for _, r in ipairs(p.hrows) do
		r:Hide()
		r:SetScript("OnClick", nil)
		r:SetScript("OnEnter", nil)
		r:SetScript("OnLeave", nil)
		r.del:Hide()
		r.del:SetScript("OnClick", nil)
		r.right:SetText("")
		r.text:SetText("")
		r.link = nil
		r:SetBackdropColor(0, 0, 0, 0)
		r:SetBackdropBorderColor(0, 0, 0, 0)
	end

	local q = A.histSearch or ""
	local order, byPlayer = {}, {}
	for i, e in ipairs(A:HistoryList()) do
		local key = A:NameKey(e.player) or "?"
		if not byPlayer[key] then
			byPlayer[key] = { name = e.player, entries = {} }
			table.insert(order, key)
		end
		table.insert(byPlayer[key].entries, { idx = i, data = e })
	end

	local n, y = 0, 2
	local function nextRow(indent, h)
		n = n + 1
		local r = GetHistRow(n)
		r:ClearAllPoints()
		r:SetPoint("TOPLEFT", indent, -y)
		r:SetWidth(350 - indent)
		r:SetHeight(h)
		r:Show()
		y = y + h + 2
		return r
	end

	local shownAny = false
	for _, key in ipairs(order) do
		local g = byPlayer[key]
		local nameMatch = q == "" or string.find(string.lower(g.name or ""), q, 1, true) ~= nil
		local matched = {}
		for _, entry in ipairs(g.entries) do
			local hay = string.lower((entry.data.name or "") .. " " .. (entry.data.link or ""))
			if q == "" or nameMatch or string.find(hay, q, 1, true) then
				table.insert(matched, entry)
			end
		end
		if table.getn(matched) > 0 then
			shownAny = true
			local itemMatch = q ~= "" and not nameMatch
			local open = A.histExpanded[key] or itemMatch
			local head = nextRow(0, 20)
			head:SetBackdropColor(0.11, 0.10, 0.06, 1)
			head:SetBackdropBorderColor(0.11, 0.10, 0.06, 1)
			head.text:SetText((open and "> " or "- ") .. (g.name or "?"))
			local cr, cg, cb = A:PlayerClassColor(g.name)
			head.text:SetTextColor(cr, cg, cb)
			head.right:SetText(table.getn(matched) .. " items")
			head.right:SetTextColor(1, 1, 1)
			head:SetScript("OnClick", function()
				A.histExpanded[key] = not open
				A:RefreshHistory()
			end)

			if open then
				for _, entry in ipairs(matched) do
					local histIndex = entry.idx
					local r = nextRow(16, 18)
					r:SetBackdropColor(0.1, 0.1, 0.1, 1)
					r:SetBackdropBorderColor(0.1, 0.1, 0.1, 1)
					r.link = entry.data.link
					r.text:SetText(entry.data.link or entry.data.name or "?")
					r.text:SetTextColor(1, 1, 1)
					local ch = entry.data.choice or ""
					r.right:SetText(A:ChoiceLabel(ch))
					local c = A.CHOICE_COLOR[ch] or { 0.8, 0.8, 0.8 }
					r.right:SetTextColor(c[1], c[2], c[3])
					r:SetScript("OnEnter", ItemTooltip)
					r:SetScript("OnLeave", HideTooltip)
					local itemOpen = A.histItemExpanded[histIndex]
					r:SetScript("OnClick", function()
						A.histItemExpanded[histIndex] = not itemOpen
						A:RefreshHistory()
					end)
					r.del:Show()
					r.del:SetScript("OnClick", function()
							local delId = entry.data.id
							if delId then
								A:RemoveHistoryId(delId)
								if A.BroadcastHistoryRemove then
									A:BroadcastHistoryRemove(delId)
								end
							else
								table.remove(A:HistoryList(), histIndex)
							end
							A.histItemExpanded[histIndex] = nil
							A:RefreshHistory()
						end)
					if itemOpen then
						local d = nextRow(32, 16)
						local stamp = entry.data.time
						local when = "Date unknown"
						if stamp and stamp > 0 and date then
							when = date("%Y-%m-%d %H:%M", stamp)
						end
		d.text:SetText("Awarded " .. when)
						d.text:SetTextColor(1, 1, 1)
					end
				end
			end
		end
	end

	if not shownAny then
		local r = nextRow(0, 20)
		r.text:SetText(q ~= "" and "No matching awards" or "No awards recorded yet")
		r.text:SetTextColor(1, 1, 1)
	end

	p.content:SetHeight(y + 4)
	p.title:SetText("Award history (" .. table.getn(A:HistoryList()) .. " entries)")
end

function A:CreateCouncilFrame()
	if A.frame then
		return
	end
	local f = CreateFrame("Frame", "DemiseRaidCouncilCouncilFrame", UIParent)
	f:SetFrameStrata("HIGH")
	f:SetWidth(FRAME_W)
	f:SetHeight(FRAME_H)
	AscensionRaidRollsDB = AscensionRaidRollsDB or {}
	f:SetPoint(
		AscensionRaidRollsDB.point or "CENTER",
		UIParent,
		AscensionRaidRollsDB.relativePoint or "CENTER",
		AscensionRaidRollsDB.x or 0,
		AscensionRaidRollsDB.y or 0
	)
	f:SetBackdrop(SOLID)
	f:SetMovable(true)
	f:EnableMouse(true)
	f:RegisterForDrag("LeftButton")
	f:SetScript("OnReceiveDrag", function() A:TryAddCursorItem() end)
	f:SetScript("OnDragStart", function(self)
		self:StartMoving()
	end)
	f:SetScript("OnDragStop", function(self)
		self:StopMovingOrSizing()
		local point, _, relativePoint, x, y = self:GetPoint(1)
		AscensionRaidRollsDB.point = point
		AscensionRaidRollsDB.relativePoint = relativePoint
		AscensionRaidRollsDB.x = x
		AscensionRaidRollsDB.y = y
	end)
	f:SetClampedToScreen(true)
	f:Hide()
	tinsert(UISpecialFrames, "DemiseRaidCouncilCouncilFrame")

	local header = CreateFrame("Frame", nil, f)
	header:SetPoint("TOPLEFT", 16, -12)
	header:SetPoint("TOPRIGHT", -12, -12)
	header:SetHeight(78)
	f.header = header

	local title = header:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
	title:SetPoint("TOP", 0, -2)
	title:SetText("Demise Raid Council")
	title:SetTextColor(GOLD[1], GOLD[2], GOLD[3])

	local settings = CouncilButton(header, 84, 24, "Menu")
	settings:SetPoint("TOPLEFT", 6, -4)
	f.settingsBtn = settings

	local addRM = CouncilButton(header, 76, 24, "Council")
	addRM:SetPoint("LEFT", settings, "RIGHT", 8, 0)
	f.addRM = addRM

	local histBtn = CouncilButton(header, 76, 24, "Logs")
	histBtn:SetPoint("LEFT", addRM, "RIGHT", 8, 0)
	f.histBtn = histBtn

	local timerBox = CreateFrame("Frame", nil, header)
	timerBox:SetWidth(124)
	timerBox:SetHeight(24)
	timerBox:SetPoint("BOTTOM", header, "BOTTOM", 0, 8)

	local durationLabel = timerBox:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	durationLabel:SetPoint("LEFT", 0, 0)
	durationLabel:SetText("Duration")

	local secLabel = timerBox:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	secLabel:SetText("sec")

	local secEdit = CreateFrame("EditBox", "DemiseRaidCouncilSecEdit", timerBox, "InputBoxTemplate")
	secEdit:SetWidth(42)
	secEdit:SetHeight(24)
	secEdit:SetPoint("LEFT", durationLabel, "RIGHT", 7, 0)
	secLabel:SetPoint("LEFT", secEdit, "RIGHT", 4, 0)
	secEdit:SetAutoFocus(false)
	secEdit:SetNumeric(true)
	secEdit:SetMaxLetters(3)
	secEdit:SetText(tostring(AscensionRaidCouncilDB.voteSeconds or 60))
	secEdit:SetScript("OnEscapePressed", function(self)
		self:ClearFocus()
	end)
	secEdit:SetScript("OnEnterPressed", function(self)
		self:ClearFocus()
	end)
	f.secEdit = secEdit
	f.timerBox = timerBox

	local start = CouncilButton(header, 110, 24, "Start Rolls", "GameFontNormal")
	start:SetPoint("BOTTOMRIGHT", -6, 8)
	f.startBtn = start
	start.label:ClearAllPoints()
	start.label:SetPoint("CENTER", 0, 0)

	local clearAll = CouncilButton(header, 92, 24, "Clear Items")
	clearAll:SetPoint("RIGHT", start, "LEFT", -8, 0)
	clearAll:SetScript("OnClick", function()
		A:BroadcastClear()
		A:ClearSession()
		A.expanded = {}
		A.winners = {}
		A.traded = {}
		A:Print("Council item queue cleared.")
	end)
	f.clearAll = clearAll

	local timersBtn = CouncilButton(header, 76, 24, "Timers")
	timersBtn:SetPoint("RIGHT", clearAll, "LEFT", -8, 0)
	timersBtn:SetScript("OnClick", function()
		if DemiseRaidRolls and DemiseRaidRolls.TradeTimers and DemiseRaidRolls.TradeTimers.Toggle then
			DemiseRaidRolls.TradeTimers.Toggle()
		end
	end)
	f.timersBtn = timersBtn

	local optionsBtn = CouncilButton(header, 84, 24, "Options")
	optionsBtn:SetPoint("BOTTOMLEFT", 6, 8)
	optionsBtn:SetScript("OnClick", function() A:ToggleOptions() end)
	f.optionsBtn = optionsBtn
	addRM:ClearAllPoints()
	addRM:SetPoint("LEFT", optionsBtn, "RIGHT", 8, 0)

	start:SetScript("OnClick", function()
		if A.started then
			A:BroadcastEnd()
			return
		end
		local secs = tonumber(secEdit:GetText()) or 0
		AscensionRaidCouncilDB.voteSeconds = secs
		A:BroadcastStart(secs)
	end)

	local close = CreateFrame("Button", nil, f, "UIPanelCloseButton")
	close:SetPoint("TOPRIGHT", -4, -4)

	local panel = CreateFrame("Frame", nil, f)
	panel:SetPoint("TOPLEFT", 16, -94)
	panel:SetPoint("BOTTOMRIGHT", -16, 14)
	panel:SetBackdrop(THIN)
	panel:SetBackdropColor(0.06, 0.06, 0.06, 0.72)
	panel:SetBackdropBorderColor(0.45, 0.45, 0.45, 0.85)
	panel:EnableMouse(true)
	panel:SetScript("OnReceiveDrag", function() A:TryAddCursorItem() end)
	f.panel = panel

	local councilTimerBar = CreateFrame("StatusBar", nil, panel)
	councilTimerBar:SetHeight(14)
	councilTimerBar:SetPoint("TOPLEFT", panel, "TOPLEFT", 6, -6)
	councilTimerBar:SetPoint("TOPRIGHT", panel, "TOPRIGHT", -26, -6)
	councilTimerBar:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar")
	councilTimerBar:SetMinMaxValues(0, 1)
	councilTimerBar:SetValue(0)
	councilTimerBar:SetStatusBarColor(0.20, 0.75, 0.25)
	local councilTimerBg = councilTimerBar:CreateTexture(nil, "BACKGROUND")
	councilTimerBg:SetAllPoints(councilTimerBar)
	councilTimerBg:SetTexture(0.08, 0.08, 0.08, 0.85)
	local councilTimerText = councilTimerBar:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	councilTimerText:SetPoint("CENTER", councilTimerBar, "CENTER", 0, 0)
	councilTimerText:SetText("Timer ready")
	councilTimerBar:Hide()
	f.councilTimerBar = councilTimerBar
	f.councilTimerText = councilTimerText

	local scroll = CreateFrame("ScrollFrame", "DemiseRaidCouncilCouncilScroll", panel, "UIPanelScrollFrameTemplate")
	scroll:SetPoint("TOPLEFT", 6, -6)
	scroll:SetPoint("BOTTOMRIGHT", -26, 6)
	local child = CreateFrame("Frame", nil, scroll)
	child:SetWidth(FRAME_W - 70)
	child:SetHeight(10)
	scroll:SetScrollChild(child)
	f.content = child
	f.rowWidth = FRAME_W - 74

	local waiting = panel:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	waiting:SetPoint("CENTER", 0, 0)
	waiting:SetWidth(FRAME_W - 140)
	waiting:SetJustifyH("CENTER")
	waiting:SetText("The peasants dream while the elite cast their votes.\nA few gold coins might hasten your rise to the council...")
	waiting:SetTextColor(GOLD[1], GOLD[2], GOLD[3])
	waiting:Hide()
	f.waiting = waiting
	f.scroll = scroll

	local noGroup = panel:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	noGroup:SetPoint("CENTER", 0, 0)
	noGroup:SetText("Join a party or raid to build a council item queue")
	noGroup:SetTextColor(1, 0.35, 0.3)
	noGroup:Hide()
	f.noGroup = noGroup

	f.rmPopup = CreateRMPopup(f)
	f.settingsPopup = A:CreateSettingsPopup(f)
	f.histPopup = CreateHistoryPopup(f)

	local function CloseOthers(keep)
		if f.rmPopup and f.rmPopup ~= keep then
			f.rmPopup:Hide()
		end
		if f.settingsPopup and f.settingsPopup ~= keep then
			f.settingsPopup:Hide()
		end
		if f.histPopup and f.histPopup ~= keep then
			f.histPopup:Hide()
		end
	end
	f.CloseOtherPopups = CloseOthers

	addRM:SetScript("OnClick", function()
		if f.rmPopup:IsShown() then
			f.rmPopup:Hide()
		else
			CloseOthers(f.rmPopup)
			f.rmPopup.edit:SetText("")
			A.rmEditMode = nil
			A:RefreshRMList()
			f.rmPopup:Show()
			if (GetNumRaidMembers and GetNumRaidMembers() or 0) == 0 then
				f.rmPopup.edit:SetFocus()
			end
		end
	end)

	settings:SetScript("OnClick", function()
		if DemiseRaidRollsMenu and DemiseRaidRollsMenu.Show then DemiseRaidRollsMenu.Show() end
	end)

	histBtn:SetScript("OnClick", function()
		if f.histPopup:IsShown() then
			f.histPopup:Hide()
		else
			CloseOthers(f.histPopup)
			A:RefreshHistory()

			f.histPopup:Show()
		end
	end)

	A.frame = f
	A.rows = {}
	A:ApplyScales()
	A:ApplyHighContrast()
end

function A:ToggleCouncilFrame()
	A:CreateCouncilFrame()
	if A.frame:IsShown() then
		A.frame:Hide()
	else
		if not A:IsCouncil() then
			A:RequestCouncilSync()
		end
		A.frame:Show()
		A:RefreshCouncil()

	end
end

local function GetRow(i)
	local A = DemiseRaidCouncil
	local row = A.rows[i]
	if row then
		return row
	end
	row = CreateFrame("Button", nil, A.frame.content)
	row:SetHeight(26)
	row:RegisterForClicks("LeftButtonUp", "RightButtonUp")
	row:SetBackdrop(THIN)
	row:SetBackdropColor(0, 0, 0, 0)
	row:SetBackdropBorderColor(0, 0, 0, 0)

	row.mark = CreateFrame("Button", nil, row)
	row.mark:SetWidth(22)
	row.mark:SetHeight(22)
	row.mark:SetPoint("LEFT", 3, 0)
	row.mark.icon = row.mark:CreateTexture(nil, "ARTWORK")
	row.mark.icon:SetAllPoints(row.mark)
	row.mark:SetHighlightTexture("Interface\\Buttons\\ButtonHilight-Square")
	row.mark:SetScript("OnEnter", function(self)
		GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
		GameTooltip:SetText(self.distributed and "Loot distributed" or "Loot not distributed")
		GameTooltip:AddLine("Click to update the shared distribution status.", 1, 1, 1, true)
		GameTooltip:Show()
	end)
	row.mark:SetScript("OnLeave", function() GameTooltip:Hide() end)
	row.mark:Hide()

	row.icon = row:CreateTexture(nil, "ARTWORK")
	row.icon:SetWidth(20)
	row.icon:SetHeight(20)
	row.icon:SetPoint("LEFT", 34, 0)
	row.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
	row.icon:Hide()

	row.text = row:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
	row.text:SetPoint("LEFT", 57, 0)
	row.text:SetJustifyH("LEFT")

	row.itemHover = CreateFrame("Button", nil, row)
	row.itemHover:SetPoint("LEFT", row, "LEFT", 34, 0)
	row.itemHover:SetWidth(20)
	row.itemHover:SetHeight(24)
	row.itemHover:RegisterForClicks("LeftButtonUp")
	row.itemHover:SetScript("OnEnter", ItemTooltip)
	row.itemHover:SetScript("OnLeave", HideTooltip)
	row.itemHover:Hide()

	row.mid = row:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
	row.mid:SetPoint("LEFT", 300, 0)
	row.mid:SetJustifyH("LEFT")

	row.count = row:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
	row.count:SetJustifyH("RIGHT")

	row.give = CouncilButton(row, 84, 18, "Announce")
	row.give:Hide()
	row.up = CouncilButton(row, 42, 18, "Vote")
	row.up:Hide()
	row.note = CreateFrame("Button", nil, row)
	row.note:SetWidth(18)
	row.note:SetHeight(18)
	row.note:SetBackdrop(THIN)
	row.note:SetBackdropColor(0.08, 0.08, 0.08, 0.96)
	row.note:SetBackdropBorderColor(0.48, 0.48, 0.48, 0.95)
	row.note.icon = row.note:CreateTexture(nil, "ARTWORK")
	row.note.icon:SetTexture("Interface\\Icons\\INV_Scroll_03")
	row.note.icon:SetPoint("TOPLEFT", 3, -3)
	row.note.icon:SetPoint("BOTTOMRIGHT", -3, 3)
	row.note:SetHighlightTexture("Interface\\Buttons\\ButtonHilight-Square")
	function row.note:SetEnabledLook(on)
		if on then self:Enable() else self:Disable() end
	end
	row.note:SetScript("OnEnter", function(self)
		GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
		GameTooltip:SetText("Read player note")
		GameTooltip:Show()
	end)
	row.note:SetScript("OnLeave", function() GameTooltip:Hide() end)
	row.note:Hide()

	local fPath, fSize, fFlags = row.text:GetFont()
	row.baseFontSize = fSize
	function row:SetCompact(on)
		-- Rows are recycled between item headers, responses, equipment and logs.
		-- Keeping a single size prevents stale compact fonts after /reload or a
		-- refresh while retaining the larger ARR visual style everywhere.
		local size = self.baseFontSize
		self.text:SetFont(fPath, size, fFlags)
		self.mid:SetFont(fPath, size, fFlags)
		self.count:SetFont(fPath, size, fFlags)
		if self.give.label then
			self.give.label:SetFont(fPath, size, fFlags)
		end
		if self.up.label then
			self.up.label:SetFont(fPath, size, fFlags)
		end
		if self.note.label then
			self.note.label:SetFont(fPath, size, fFlags)
		end
	end

	A.rows[i] = row
	return row
end

function A:AllItemsComplete()
	local total = A:RequiredCount()
	if total <= 0 or table.getn(A.items) == 0 then
		return false
	end
	for i in ipairs(A.items) do
		if A:CountVoted(i) < total then
			return false
		end
	end
	return true
end

function A:RefreshTimerText()
	local left = A.TimeLeft and A:TimeLeft()
	local txt = ""
	local active = false
	if A.started and left then
		txt = math.floor(left + 0.5) .. " s"
		active = true
	end
	local f = A.frame
	if f and f.startBtn then
		if A.started then
			f.startBtn.label:SetText("Stop Rolls")
		else
			f.startBtn.label:SetText("Start Rolls")
		end
		f.startBtn.label:ClearAllPoints()
		f.startBtn.label:SetPoint("CENTER", 0, 0)
	end
	if f and f.councilTimerBar and f.scroll then
		if active then
			local duration = math.max(1, tonumber(A.voteDuration) or left or 1)
			local ratio = math.max(0, math.min(1, (left or 0) / duration))
			f.councilTimerBar:SetMinMaxValues(0, duration)
			f.councilTimerBar:SetValue(left or 0)
			if ratio <= 0.20 then
				f.councilTimerBar:SetStatusBarColor(0.85, 0.12, 0.12)
			elseif ratio <= 0.50 then
				f.councilTimerBar:SetStatusBarColor(0.95, 0.65, 0.10)
			else
				f.councilTimerBar:SetStatusBarColor(0.20, 0.75, 0.25)
			end
			f.councilTimerText:SetText("Council rolls: " .. txt)
			if not f.councilTimerBar:IsShown() then
				f.scroll:ClearAllPoints()
				f.scroll:SetPoint("TOPLEFT", 6, -24)
				f.scroll:SetPoint("BOTTOMRIGHT", -26, 6)
				f.councilTimerBar:Show()
			end
		else
			if f.councilTimerBar:IsShown() then
				f.councilTimerBar:Hide()
				f.scroll:ClearAllPoints()
				f.scroll:SetPoint("TOPLEFT", 6, -6)
				f.scroll:SetPoint("BOTTOMRIGHT", -26, 6)
			end
		end
	end
	if A.rframe and A.rframe.timerBar then
		if active then
			local duration = math.max(1, tonumber(A.voteDuration) or left or 1)
			local ratio = math.max(0, math.min(1, (left or 0) / duration))
			A.rframe.timerBar:SetMinMaxValues(0, duration)
			A.rframe.timerBar:SetValue(left or 0)
			if ratio <= 0.20 then
				A.rframe.timerBar:SetStatusBarColor(0.85, 0.12, 0.12)
			elseif ratio <= 0.50 then
				A.rframe.timerBar:SetStatusBarColor(0.95, 0.65, 0.10)
			else
				A.rframe.timerBar:SetStatusBarColor(0.20, 0.75, 0.25)
			end
			A.rframe.timerText:SetText("Council rolls: " .. txt)
			A.rframe.timerBar:Show()
		else
			A.rframe.timerBar:SetMinMaxValues(0, 1)
			A.rframe.timerBar:SetValue(0)
			A.rframe.timerText:SetText("Timer ready")
			A.rframe.timerBar:Hide()
		end
	end
end

-- Read-only popup that shows a raider's note to the loot council.
function A:ShowNote(player, item, note)
	if not A.noteViewer then
		local p = CreateFrame("Frame", "DemiseRaidCouncilNoteViewer", UIParent)
		p:SetFrameStrata("DIALOG")
		p:SetWidth(340)
		p:SetHeight(140)
		p:SetPoint("CENTER", UIParent, "CENTER", 0, 100)
		p:SetBackdrop(SOLID)
		p:SetBackdropColor(0.04, 0.04, 0.04, 0.98)
		p:SetBackdropBorderColor(0.55, 0.55, 0.55, 1)
		p:EnableMouse(true)
		p:Hide()

		p.title = p:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
		p.title:SetPoint("TOPLEFT", 12, -12)
		p.title:SetTextColor(GOLD[1], GOLD[2], GOLD[3])

		p.body = p:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
		p.body:SetPoint("TOPLEFT", 14, -38)
		p.body:SetWidth(310)
		p.body:SetJustifyH("LEFT")
		p.body:SetTextColor(1, 1, 1)

		local close = CouncilButton(p, 90, 22, "Close")
		close:SetPoint("BOTTOMRIGHT", -12, 12)
		close:SetScript("OnClick", function()
			p:Hide()
		end)
		A.noteViewer = p
	end
	local p = A.noteViewer
	p.title:SetText((player or "") .. " - " .. ((item and item.link) or ""))
	p.body:SetText(note or "")
	p:Show()
end

local function ApplyCouncilFrameSize(f, compactViewer)
	if compactViewer then
		f:SetWidth(VIEWER_W)
		f:SetHeight(VIEWER_H)
		if f.header then f.header:Show() end
		if f.headerTopSeparator then f.headerTopSeparator:Hide() end
		if f.headerBottomSeparator then f.headerBottomSeparator:Hide() end
		if f.panel then
			f.panel:ClearAllPoints()
			f.panel:SetPoint("TOPLEFT", 16, -58)
			f.panel:SetPoint("BOTTOMRIGHT", -16, 14)
		end
		if f.waiting then f.waiting:SetWidth(VIEWER_W - 80) end
		return
	end

	f:SetWidth(FRAME_W)
	f:SetHeight(FRAME_H)
	if f.header then f.header:Show() end
	if f.headerTopSeparator then f.headerTopSeparator:Show() end
	if f.headerBottomSeparator then f.headerBottomSeparator:Show() end
	if f.panel then
		f.panel:ClearAllPoints()
		f.panel:SetPoint("TOPLEFT", 16, -94)
		f.panel:SetPoint("BOTTOMRIGHT", -16, 14)
	end
	if f.waiting then f.waiting:SetWidth(FRAME_W - 140) end
end

local function CanUseModuleMenuAndOptions()
	if not (GetNumRaidMembers and GetNumRaidMembers() > 0) then return true end
	local masterLooter = A:MasterLooterName()
	return masterLooter and A:NamesEqual(masterLooter, A.me) or false
end

local function SetModuleMenuAndOptionsEnabled(f, enabled)
	for _, button in ipairs({ f.settingsBtn, f.optionsBtn }) do
		if button then
			button:SetEnabledLook(enabled)
			button:SetAlpha(enabled and 1 or 0.45)
		end
	end
end

function A:RefreshCouncil()
	local f = A.frame
	if not f or not f:IsShown() then
		return
	end
	ApplyCouncilFrameSize(f, false)
	for _, r in ipairs(A.rows) do
		r:Hide()
		if r.gearLinkButtons then
			for _, button in ipairs(r.gearLinkButtons) do button:Hide() end
		end
		if r.gearSeparators then
			for _, separator in ipairs(r.gearSeparators) do separator:Hide() end
		end
		r.link = nil
		if r.itemHover then
			r.itemHover.link = nil
			r.itemHover:SetScript("OnClick", nil)
			r.itemHover:Hide()
		end
		r.give:Hide()
		r.up:Hide()
		r.note:Hide()
		r.note:SetScript("OnClick", nil)
		r.icon:Hide()
		r.mark:Hide()
		r.mark.icon:SetTexture("Interface\\AddOns\\DemiseRaidRolls\\Assets\\LootClosed")
		r.mark.distributed = false
		r.mark:SetScript("OnClick", nil)
		r:SetBackdropColor(0, 0, 0, 0)
		r:SetBackdropBorderColor(0, 0, 0, 0)
		r.count:SetText("")
		r.mid:SetText("")
		r.text:SetText("")
		r.text:ClearAllPoints()
		r.text:SetPoint("LEFT", 57, 0)
		r.text:SetTextColor(1, 1, 1)
		r.mid:ClearAllPoints()
		r.mid:SetPoint("LEFT", 300, 0)
		r.give.label:SetText("Announce")
		r.give:SetWidth(84)
		r.give:SetHeight(18)
		r.up:SetHeight(18)
		r.give:SetGrey(false)
		r.up:SetGrey(false)
		r:SetCompact(false)
		r:SetScript("OnClick", nil)
		r:SetScript("OnEnter", nil)
		r:SetScript("OnLeave", nil)
	end
	A:RefreshTimerText()
	if f.itemCount then
		local nItems = table.getn(A.items)
		local maxItems = A.MAX_ITEMS or 20
		f.itemCount:SetText(nItems .. "/" .. maxItems)
		if nItems >= maxItems then
			f.itemCount:SetTextColor(1, 0.35, 0.3)
		else
			f.itemCount:SetTextColor(GOLD[1], GOLD[2], GOLD[3])
		end
	end

	if not A:InGroup() then
		if f.optionsBtn then f.optionsBtn:Show() end
		if f.settingsBtn then f.settingsBtn:Show() end
		SetModuleMenuAndOptionsEnabled(f, true)
		f.scroll:Hide()
		f.startBtn:Hide()
		f.timerBox:Hide()
		f.waiting:Hide()
		if f.addRM then f.addRM:Hide() end
		if f.histBtn then f.histBtn:Hide() end
		if f.timersBtn then f.timersBtn:Hide() end
		if f.clearAll then f.clearAll:Hide() end
		if f.itemCount then f.itemCount:Hide() end
		if f.voteStat then f.voteStat:Hide() end
		if f.doneCheck then
			f.doneCheck:Hide()
			f.doneText:Hide()
		end
		if f.noGroup then f.noGroup:Show() end
		if f.CloseOtherPopups then
			f.CloseOtherPopups(nil)
		elseif f.rmPopup then
			f.rmPopup:Hide()
		end
		return
	end
	if f.noGroup then f.noGroup:Hide() end

	if not A:IsCouncil() then
		ApplyCouncilFrameSize(f, true)
		local now = GetTime()
		if not A.lastSync or (now - A.lastSync) > 5 then
			A.lastSync = now
			A:RequestCouncilSync()
		end
		f.waiting:Show()
		if f.optionsBtn then f.optionsBtn:Hide() end
		f.scroll:Hide()
		if f.settingsBtn then f.settingsBtn:Hide() end
		f.addRM:Hide()
		if f.histBtn then
			f.histBtn:Hide()
		end
		if f.timersBtn then
			f.timersBtn:Hide()
		end
		if f.clearAll then
			f.clearAll:Hide()
		end
		f.startBtn:Hide()
		f.timerBox:Hide()
		if f.itemCount then
			f.itemCount:Hide()
		end
		if f.voteStat then
			f.voteStat:Hide()
		end
		if f.doneCheck then
			f.doneCheck:Hide()
			f.doneText:Hide()
		end
		if f.CloseOtherPopups then
			f.CloseOtherPopups(nil)
		elseif f.rmPopup then
			f.rmPopup:Hide()
		end
		return
	end
	f.waiting:Hide()
	if f.optionsBtn then f.optionsBtn:Show() end
	if f.settingsBtn then f.settingsBtn:Show() end
	SetModuleMenuAndOptionsEnabled(f, CanUseModuleMenuAndOptions())

	if f.noGroup then
		f.noGroup:Hide()
	end

	f.scroll:Show()
	f.startBtn:Show()
	f.timerBox:Show()
	if f.histBtn then
		f.histBtn:Show()
	end
	if f.timersBtn then
		f.timersBtn:Show()
	end
	if f.clearAll then
		f.clearAll:Show()
	end
	if f.itemCount then
		f.itemCount:Show()
	end
	if f.voteStat then
		f.voteStat:Show()
	end
	local W = f.rowWidth
	local y = 6
	local n = 0
	local function nextRow(indent, height)
		n = n + 1
		local row = GetRow(n)
		row:ClearAllPoints()
		row:SetPoint("TOPLEFT", indent, -y)
		row:SetHeight(height or 26)
		row:SetWidth(W - indent)
		row:Show()
		y = y + (height or 26) + 2
		return row
	end

	-- Council members can vote, but only the current Master Looter can announce awards.
	local isML = A:IsML()
	local isRM = A:IsCouncil()

	for i, item in ipairs(A.items) do
		local itemIndex = i
		local itemRef = item
		local voted = A:CountVoted(itemIndex)
		local total = A:RequiredCount()

		local row = nextRow(0, 28)
		row:SetBackdropColor(0.09, 0.09, 0.09, 0)
		local iVoted = A.rmVoted[itemIndex] and A.rmVoted[itemIndex][A:NameKey(A.me)]
		if iVoted then
			row:SetBackdropBorderColor(0.25, 0.9, 0.4, 1)
		else
			row:SetBackdropBorderColor(0, 0, 0, 0)
		end
		A.traded = A.traded or {}
		if isML then
			row.mark:Show()
			row.mark.distributed = A:IsFullyDistributed(itemRef)
			row.mark.icon:SetTexture(row.mark.distributed
				and "Interface\\AddOns\\DemiseRaidRolls\\Assets\\LootOpen"
				or "Interface\\AddOns\\DemiseRaidRolls\\Assets\\LootClosed")
			row.mark:SetScript("OnClick", function()
				local target = A:IsFullyDistributed(itemRef) and 0 or A:ItemQuantity(itemRef)
				itemRef.awardedCount = target
				if target == 0 then itemRef.awardedPlayers = {} end
				A:BroadcastTraded(itemIndex, target)
			end)
		end
		row.link = itemRef.link
		row.itemHover.link = itemRef.link
		row.itemHover:Show()
		row.icon:SetTexture(itemRef.texture)
		row.icon:Show()
		row.text:SetWidth(240)
		local quantityText = A:ItemQuantity(itemRef) > 1 and (" |cffffffffx" .. A:ItemQuantity(itemRef) .. "|r") or ""
		row.text:SetText((A.expanded[itemIndex] and "- " or "+ ") .. (itemRef.link or "") .. quantityText)
		row.itemHover:SetWidth(math.min(263, math.max(20, 23 + (row.text:GetStringWidth() or 0))))
		local choiceCounts = { BiS = 0, Upgrade = 0, Offspec = 0 }
		for _, ch in pairs(A.choices[itemIndex] or {}) do
			if choiceCounts[ch] ~= nil then choiceCounts[ch] = choiceCounts[ch] + 1 end
		end
		A.winners = A.winners or {}
		local choiceSummary = {}
		if choiceCounts.BiS > 0 then table.insert(choiceSummary, "|cffffd633" .. choiceCounts.BiS .. " BiS|r") end
		if choiceCounts.Upgrade > 0 then table.insert(choiceSummary, "|cff59ff80" .. choiceCounts.Upgrade .. " Upgrade|r") end
		if choiceCounts.Offspec > 0 then table.insert(choiceSummary, "|cff80d1ff" .. choiceCounts.Offspec .. " Off Spec|r") end
		if table.getn(choiceSummary) > 0 then
			row.mid:SetText(table.concat(choiceSummary, " |cffffffff|| |r"))
		else
			row.mid:SetText("|cffffffffWaiting for rolls|r")
		end
		row.mid:SetTextColor(1, 1, 1)
		row:SetScript("OnEnter", nil)
		row:SetScript("OnLeave", nil)
		row:SetScript("OnClick", function()
			A.expanded[itemIndex] = not A.expanded[itemIndex]
			A:RefreshCouncil()
		end)
		row.itemHover:SetScript("OnClick", function()
			A.expanded[itemIndex] = not A.expanded[itemIndex]
			A:RefreshCouncil()
		end)

		if isML then
			row.up:SetWidth(22)
			row.up.label:SetText("-")
			row.up:ClearAllPoints()
			row.up:SetPoint("RIGHT", -6, 0)
			row.up:Show()
			row.up:SetEnabledLook(true)
			row.up:SetScript("OnClick", function()
				A:BroadcastRemove(itemIndex)
			end)
		end

		if A.started and isRM and not iVoted then
			row.give:SetWidth(50)
			row.give:SetHeight(16)
			row.give.label:SetText("Pass")
			row.give:ClearAllPoints()
			row.give:SetPoint("RIGHT", row.up, "LEFT", -6, 0)
			row.give:SetEnabledLook(true)
			row.give:Show()
			row.give:SetScript("OnClick", function()
				A:BroadcastDownvote(itemIndex)
			end)
		end
		row.count:ClearAllPoints()
		row.count:SetWidth(66)
		row.count:SetJustifyH("RIGHT")
		if row.give:IsShown() then
			row.count:SetPoint("RIGHT", row.give, "LEFT", -12, 0)
		else
			row.count:SetPoint("RIGHT", row.up, "LEFT", -12, 0)
		end
		row.count:SetText(voted .. "/" .. total .. " votes")
		if total > 0 and voted >= total then
			row.count:SetTextColor(0.3, 1, 0.4)
		else
			row.count:SetTextColor(GOLD[1], GOLD[2], GOLD[3])
		end
		row.mid:ClearAllPoints()
		row.mid:SetPoint("LEFT", 300, 0)
		row.mid:SetPoint("RIGHT", row.count, "LEFT", -12, 0)
		row.mid:SetJustifyH("LEFT")

		if A.expanded[itemIndex] then
			local CHOICE_ORDER = { BiS = 1, Upgrade = 2, Offspec = 3 }
			local list = {}
			for player, choice in pairs(A.choices[itemIndex] or {}) do
				if choice ~= "Pass" then
					table.insert(list, { name = player, choice = choice, up = A:UpvoteCount(itemIndex, player) })
				end
			end
			table.sort(list, function(a, b)
				local ao = CHOICE_ORDER[a.choice] or 9
				local bo = CHOICE_ORDER[b.choice] or 9
				if ao ~= bo then
					return ao < bo
				end
				if a.up == b.up then
					return a.name < b.name
				end
				return a.up > b.up
			end)

			if table.getn(list) == 0 then
				local r = nextRow(30, 20)
				r:SetCompact(true)
				r:SetBackdropColor(0.11, 0.10, 0.06, 1)
				r:SetBackdropBorderColor(0.11, 0.10, 0.06, 1)
				r.text:ClearAllPoints()
				r.text:SetPoint("LEFT", 10, 0)
				r.text:SetText("Waiting for rolls")
				r.text:SetTextColor(A:SecondaryTextColor())
			end

			for idx, entry in ipairs(list) do
				local playerName = entry.name
				local playerChoice = entry.choice
				local r = nextRow(30, 18)
				r:SetCompact(true)
				r:SetBackdropColor(0.1, 0.1, 0.1, 1)
				r:SetBackdropBorderColor(0.1, 0.1, 0.1, 1)

				r.text:ClearAllPoints()
				r.text:SetPoint("LEFT", 12, 0)
				r.text:SetText(entry.name)
				local cr, cg, cb = A:PlayerClassColor(entry.name)
				r.text:SetTextColor(cr, cg, cb)

				r.mid:ClearAllPoints()
				r.mid:SetPoint("LEFT", 280, 0)
				r.mid:SetText(A:ChoiceLabel(entry.choice))
				r.mid:SetTextColor(A:ChoiceTextColor(entry.choice))

				local rightEdge = -6
				if isRM and playerChoice ~= "Pass" then
					itemRef.awardedPlayers = itemRef.awardedPlayers or {}
					local alreadyAwarded = itemRef.awardedPlayers[A:NameKey(playerName)] == true
					local canAnnounce = isML and not alreadyAwarded and not A:IsFullyDistributed(itemRef)
					r.give:SetWidth(76)
					r.give:SetHeight(16)
					r.give:ClearAllPoints()
					r.give:SetPoint("RIGHT", rightEdge, 0)
					r.give:SetEnabledLook(canAnnounce)
					r.give:SetGrey(not canAnnounce)
					r.give:Show()
					r.give:SetScript("OnClick", function()
						A.winners = A.winners or {}
						A.winners[itemIndex] = playerName
						A:BroadcastWinner(itemIndex, playerName)
						local announcementItem = A:AnnouncementItemLink(itemRef)
						if not (AscensionRaidRollsDB and AscensionRaidRollsDB.muteWinnerAnnouncement) then
							A:Announce(announcementItem .. " -> " .. playerName .. " | " .. A:ChoiceLabel(playerChoice))
						end
						if A:NamesEqual(playerName, A.me) then
							A:CompleteSelfAward(playerName, itemRef, itemIndex, playerChoice)
						elseif AscensionRaidRollsDB and AscensionRaidRollsDB.councilTradeOnAnnounce then
							A:TradeAwardedItem(playerName, itemRef, itemIndex, playerChoice)
						else
							A:PrepareAwardTrade(playerName, itemRef, itemIndex, playerChoice)
						end
						A:Print("Award announced: " .. (itemRef.link or "") .. " -> " .. playerName .. " | " .. A:ChoiceLabel(playerChoice))
						A:RefreshCouncil()
					end)
					rightEdge = -86
				end

				if playerChoice ~= "Pass" then
					r.up:SetWidth(40)
					r.up:SetHeight(16)
					r.up.label:SetText("Vote")
					r.up:ClearAllPoints()
					r.up:SetPoint("RIGHT", rightEdge, 0)
					r.up:Show()
					local mine = A.upvotes[itemIndex]
						and A.upvotes[itemIndex][playerName]
						and A.upvotes[itemIndex][playerName][A:NameKey(A.me)]
					local selectionLimitReached = A:VoterSelectionCount(itemIndex, A.me) >= A:ItemQuantity(itemRef)
					local canVote = isRM and (mine or not selectionLimitReached)
					r.up:SetEnabledLook(canVote)
					r.up:SetGrey(mine or not canVote)
					r.up:SetScript("OnClick", function()
						if mine then
							A:BroadcastUnupvote(itemIndex, playerName)
						else
							A:BroadcastUpvote(itemIndex, playerName)
						end
					end)

					r.count:ClearAllPoints()
					r.count:SetPoint("RIGHT", r.up, "LEFT", -6, 0)
					r.count:SetText(entry.up > 0 and tostring(entry.up) or "")
					r.count:SetTextColor(1, 1, 1)
				end

				local note = A.notes[itemIndex] and A.notes[itemIndex][playerName]
				if note then
					r.note:SetWidth(18)
					r.note:SetHeight(18)
					r.note:ClearAllPoints()
					r.note:SetPoint("RIGHT", r.mid, "LEFT", -4, 0)
					r.note:SetEnabledLook(true)
					r.note:Show()
					r.note:SetScript("OnClick", function()
						A:ShowNote(playerName, itemRef, note)
					end)
				end

				local gearItems = A:GearList(itemIndex, playerName)
				if table.getn(gearItems) > 0 then
					local gr = nextRow(46, 16)
					gr:SetCompact(true)
					gr:SetBackdropColor(0.08, 0.08, 0.08, 1)
					gr:SetBackdropBorderColor(0.08, 0.08, 0.08, 1)
					gr.text:ClearAllPoints()
					gr.text:SetPoint("LEFT", 12, 0)
					gr.text:SetText("Currently equipped:")
					gr.text:SetWidth(math.ceil(gr.text:GetStringWidth() or 100))
					gr.text:SetTextColor(A:SecondaryTextColor())
					gr.link = nil
					gr:SetScript("OnEnter", nil)
					gr:SetScript("OnLeave", nil)
					gr.gearLinkButtons = gr.gearLinkButtons or {}
					gr.gearSeparators = gr.gearSeparators or {}
					local previous = gr.text
					for gearIndex, gearItem in ipairs(gearItems) do
						if gearIndex > 1 then
							local separator = gr.gearSeparators[gearIndex - 1]
							if not separator then
								separator = gr:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
								gr.gearSeparators[gearIndex - 1] = separator
							end
							separator:ClearAllPoints()
							separator:SetPoint("LEFT", previous, "RIGHT", 3, 0)
							separator:SetText("||")
							separator:SetTextColor(1, 1, 1)
							separator:Show()
							previous = separator
						end
						local linkButton = gr.gearLinkButtons[gearIndex]
						if not linkButton then
							linkButton = CreateFrame("Button", nil, gr)
							linkButton:SetHeight(16)
							linkButton.label = linkButton:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
							linkButton.label:SetAllPoints(linkButton)
							linkButton.label:SetJustifyH("LEFT")
							linkButton:SetScript("OnEnter", ItemTooltip)
							linkButton:SetScript("OnLeave", HideTooltip)
							gr.gearLinkButtons[gearIndex] = linkButton
						end
						linkButton.link = gearItem.link
						linkButton.label:SetText(gearItem.link)
						linkButton:SetWidth(math.ceil(linkButton.label:GetStringWidth() or 1) + 2)
						linkButton:ClearAllPoints()
						linkButton:SetPoint("LEFT", previous, "RIGHT", 3, 0)
						linkButton:Show()
						previous = linkButton
					end
				end
			end
			y = y + 8
		end

		row.text:SetTextColor(1, 1, 1)
	end

	if table.getn(A.items) == 0 then
		local row = nextRow(0, 28)
		row:SetBackdropColor(0, 0, 0, 0)
		row:SetBackdropBorderColor(0, 0, 0, 0)
		row.text:ClearAllPoints()
		row.text:SetPoint("LEFT", 10, 0)
		row.text:SetWidth(W - 20)
		row.text:SetFontObject("GameFontHighlight")
		row.text:SetText("No item found - Shift + right-click items in your bags")
		row.text:SetTextColor(A:SecondaryTextColor())
	end

	f.content:SetHeight(y + 10)
	A:RefreshTimerText()
	f.startBtn:SetEnabledLook(isRM)

	if isRM then
		f.addRM:Show()
	else
		f.addRM:Hide()
	end
end
