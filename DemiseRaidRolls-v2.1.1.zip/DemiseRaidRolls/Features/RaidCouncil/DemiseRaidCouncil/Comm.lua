local A = DemiseRaidCouncil

local function Channel()
	if UnitInRaid("player") then
		return "RAID"
	elseif UnitInParty("player") then
		return "PARTY"
	end
	return nil
end

function A:Send(msg)
	local ch = Channel()
	if not ch then
		A:OnAddonMessage(A.PREFIX, msg, "WHISPER", A.me)
		return
	end
	SendAddonMessage(A.PREFIX, msg, ch)
end

A.sendQueue = A.sendQueue or {}
local sender = CreateFrame("Frame")
sender:Hide()
sender.acc = 0
sender:SetScript("OnUpdate", function(self, elapsed)
	self.acc = (self.acc or 0) + (elapsed or 0.1)
	if self.acc < 0.2 then
		return
	end
	self.acc = 0
	local msg = table.remove(A.sendQueue, 1)
	if not msg then
		self:Hide()
		if A.histDirty then
			A.histDirty = nil
			if A.RefreshHistory then
				A:RefreshHistory()
			end
		end
		return
	end
	A:Send(msg)
end)

function A:SendQueued(msg)
	table.insert(A.sendQueue, msg)
	sender.acc = 0
	sender:Show()
end

function A:BroadcastAdd(itemString, quantity)
	A:Send("A^" .. itemString .. "^" .. A.me .. "^" .. tostring(math.max(1, tonumber(quantity) or 1)))
end

function A:BroadcastRemove(idx)
	A:Send("R^" .. idx)
end

function A:BroadcastStart(duration)
	if table.getn(A.items) == 0 then
		A:Print("The council item queue is empty.")
		return
	end
	A.mlName = A.me
	local dur = tostring(tonumber(duration) or 0)
	A:Send("S^" .. dur)
	for _, it in ipairs(A.items) do
		A:Send("I^" .. it.itemString .. "^" .. tostring(A:ItemQuantity(it)))
	end
	A:Send("B^" .. dur)
end

function A:BroadcastEnd()
	A:Send("E^")
end

function A:BroadcastClear()
	A:Send("Z^")
end

function A:BroadcastChoice(idx, choice)
	A:Send("V^" .. idx .. "^" .. choice)
end

function A:BroadcastNote(idx, note)
	note = string.gsub(note or "", "%^", "")
	A:Send("N^" .. idx .. "^" .. note)
end

function A:BroadcastGear(idx, gear)
	A:Send("F^" .. idx .. "^" .. (gear or ""))
end

function A:BroadcastUpvote(idx, player)
	A:Send("U^" .. idx .. "^" .. player)
end

function A:BroadcastUnupvote(idx, player)
	A:Send("X^" .. idx .. "^" .. player)
end

function A:BroadcastDownvote(idx)
	A:Send("D^" .. idx)
end

function A:BroadcastWinner(idx, player)
	A:Send("W^" .. idx .. "^" .. player)
end

function A:BroadcastTraded(idx, count)
	if type(count) == "boolean" then count = count and A:ItemQuantity(idx) or 0 end
	A:Send("T^" .. idx .. "^" .. tostring(math.max(0, tonumber(count) or 0)))
end

function A:BroadcastCouncil()
	A:Send("K^" .. table.concat(A.council, "~"))
end

function A:RequestCouncilSync()
	A:Send("Q^")
end

function A:IsSyncPeer(name)
	if not name or name == "" then
		return false
	end
	if A.mlName and A:NamesEqual(name, A.mlName) then
		return true
	end
	for _, n in ipairs(A.council) do
		if A:NamesEqual(n, name) then
			return true
		end
	end
	return false
end

function A:CanSyncHistory()
	return A:IsCouncil() == true
end

local function EncodeHistory(e)
	return (e.id or "")
		.. "^"
		.. (e.player or "")
		.. "^"
		.. (e.choice or "")
		.. "^"
		.. tostring(e.time or 0)
		.. "^"
		.. (e.link or "")
end

local function DecodeHistory(rest)
	local id, player, choice, t, link = string.match(rest, "^(.-)%^(.-)%^(.-)%^(.-)%^(.*)$")
	if not id or id == "" then
		return nil
	end
	local name = string.match(link or "", "%[(.-)%]") or link
	return {
		id = id,
		player = player,
		choice = choice,
		time = tonumber(t) or 0,
		link = link,
		name = name,
	}
end

function A:BroadcastHistoryEntry(e)
	if not A:CanSyncHistory() then
		return
	end
	A:Send("H^" .. EncodeHistory(e))
end

function A:BroadcastHistoryRemove(id)
	if not A:CanSyncHistory() then
		return
	end
	A:Send("Y^" .. id)
end

function A:RequestHistorySync()
	if not A:CanSyncHistory() then
		A:Print("The award ledger can only be synchronized between council members.")
		return
	end
	local count, sig = A:HistorySig()
	A:Send("G^" .. count .. "^" .. sig)
end

function A:AnswerHistorySync(count, sig)
	if not A:CanSyncHistory() then
		return
	end
	local myCount, mySig = A:HistorySig()
	if myCount == count and mySig == sig then
		return
	end
	if myCount == 0 then
		return
	end
	local now = GetTime and GetTime() or 0
	if A.lastHistAnswer and (now - A.lastHistAnswer) < 5 then
		return
	end
	A.lastHistAnswer = now
	local list = A:HistoryList()
	local start = 1
	if table.getn(list) > 200 then
		start = table.getn(list) - 199
	end
	for i = start, table.getn(list) do
		A:SendQueued("H^" .. EncodeHistory(list[i]))
	end
	for id in pairs(A:HistoryDeleted()) do
		A:SendQueued("Y^" .. id)
	end
end

function A:OnAddonMessage(prefix, message, _, sender)
	if prefix ~= A.PREFIX or not message then
		return
	end
	sender = A:Short(sender)
	local senderKey = A:NameKey(sender)
	local cmd, rest = string.match(message, "^(%a)%^(.*)$")
	if not cmd then
		return
	end

	-- DemiseRaidCouncil's original UI and protocol are kept intact, but DemiseRaidRolls
	-- never accepts controller actions from an arbitrary addon-message sender.
	local function IsGroupMember(name)
		if A:NamesEqual(name, A.me) then return true end
		for i = 1, (GetNumRaidMembers and GetNumRaidMembers() or 0) do
			if A:NamesEqual(GetRaidRosterInfo(i), name) then return true end
		end
		for i = 1, (GetNumPartyMembers and GetNumPartyMembers() or 0) do
			if A:NamesEqual(UnitName("party" .. i), name) then return true end
		end
		return false
	end
	local function IsRosterLeader(name)
		for i = 1, (GetNumRaidMembers and GetNumRaidMembers() or 0) do
			local rosterName, rank = GetRaidRosterInfo(i)
			if A:NamesEqual(rosterName, name) and rank and rank >= 1 then return true end
		end
		return false
	end
	local function IsController(name)
		if A:NamesEqual(name, A.me) and A:IsCouncil() then return true end
		if IsRosterLeader(name) then return true end
		local method, partyIndex, raidIndex = GetLootMethod()
		if method == "master" then
			local masterName
			if raidIndex and raidIndex > 0 then masterName = GetRaidRosterInfo(raidIndex)
			elseif partyIndex == 0 then masterName = UnitName("player")
			elseif partyIndex and partyIndex > 0 then masterName = UnitName("party" .. partyIndex) end
			if A:NamesEqual(masterName, name) then return true end
		end
		for _, councilName in ipairs(A.council or {}) do
			if A:NamesEqual(councilName, name) then return true end
		end
		return false
	end
	local controllerCommands = { A=true, R=true, S=true, I=true, B=true, E=true, Z=true, U=true, X=true, D=true, W=true, T=true, K=true }
	local playerCommands = { V=true, N=true, F=true }
	if controllerCommands[cmd] and not IsController(sender) then return end
	if playerCommands[cmd] and not IsGroupMember(sender) then return end

	if cmd == "A" then
		local itemString, adder, quantity = string.match(rest, "^(.-)%^(.-)%^(%d+)$")
		if not itemString then itemString, adder = string.match(rest, "^(.-)%^(.*)$") end
		if itemString then
			A:AddItemLocal(itemString, adder or sender, quantity)
		end
	elseif cmd == "R" then
		local idx = tonumber(rest)
		if idx then
			A:RemoveItemLocal(idx)
		end
	elseif cmd == "S" then
		A.items = {}
		A.choices = {}
		A.upvotes = {}
		A.rmVoted = {}
		A.passes = {}
		A.winners = {}
		A.traded = {}
		A.notes = {}
		A.gear = {}
		A.started = false
		A.mlName = sender
	elseif cmd == "I" then
		local itemString, quantity = string.match(rest, "^(.-)%^(%d+)$")
		itemString = itemString or rest
		local item = A:BuildItem(itemString)
		if item then
			item.quantity = math.max(1, tonumber(quantity) or 1)
			item.awardedCount = 0
			item.awardedPlayers = {}
			table.insert(A.items, item)
		end
	elseif cmd == "B" then
		local secs = tonumber(rest) or 0
		A.started = true
		A.mlName = sender
		A:StartTimer(secs)
		A:ShowRaiderList()
		-- The full response/voting workspace is useful only to the Council Master
		-- and council members. Regular viewers receive only the compact loot frame.
		if A:IsCouncil() and A.frame then
			A.frame:Show()
		end
		A:RefreshCouncil()
	elseif cmd == "E" then
		A.started = false
		A:StopTimer()
		A:HideRaiderList()
		A:RefreshCouncil()
		if A:NamesEqual(sender, A.me) then
			A:Announce("DemiseRaidCouncil: council rolls are closed.")
		end
	elseif cmd == "Z" then
		A.started = false
		A:StopTimer()
		A:HideRaiderList()
		A:ClearSession()
	elseif cmd == "V" then
		local idxStr, choice = string.match(rest, "^(%d+)%^(.*)$")
		local idx = tonumber(idxStr)
		if idx and choice then
			A.choices[idx] = A.choices[idx] or {}
			A.choices[idx][sender] = choice
			A:RefreshCouncil()
		end
	elseif cmd == "N" then
		local idxStr, note = string.match(rest, "^(%d+)%^(.*)$")
		local idx = tonumber(idxStr)
		if idx then
			A.notes[idx] = A.notes[idx] or {}
			if note == "" then
				A.notes[idx][sender] = nil
			else
				A.notes[idx][sender] = string.sub(note, 1, A.NOTE_MAX or 100)
			end
			A:RefreshCouncil()
		end
	elseif cmd == "F" then
		local idxStr, gear = string.match(rest, "^(%d+)%^(.*)$")
		local idx = tonumber(idxStr)
		if idx then
			A.gear[idx] = A.gear[idx] or {}
			A.gear[idx][sender] = gear
			A:RefreshCouncil()
		end
	elseif cmd == "U" then
		local idxStr, player = string.match(rest, "^(%d+)%^(.*)$")
		local idx = tonumber(idxStr)
		if idx and player then
			A.upvotes[idx] = A.upvotes[idx] or {}
			local alreadySelected = A.upvotes[idx][player] and A.upvotes[idx][player][senderKey]
			if not alreadySelected and A:VoterSelectionCount(idx, sender) >= A:ItemQuantity(idx) then return end
			A.upvotes[idx][player] = A.upvotes[idx][player] or {}
			A.upvotes[idx][player][senderKey] = true
			A.passes[idx] = A.passes[idx] or {}
			A.passes[idx][senderKey] = nil
			A:RecalcVoted(idx)
			A:RefreshCouncil()
		end
	elseif cmd == "X" then
		local idxStr, player = string.match(rest, "^(%d+)%^(.*)$")
		local idx = tonumber(idxStr)
		if idx and player then
			if A.upvotes[idx] and A.upvotes[idx][player] then
				A.upvotes[idx][player][senderKey] = nil
			end
			A:RecalcVoted(idx)
			A:RefreshCouncil()
		end
	elseif cmd == "D" then
		local idx = tonumber(rest)
		if idx then
			A.upvotes[idx] = A.upvotes[idx] or {}
			for _, byVoter in pairs(A.upvotes[idx]) do
				byVoter[senderKey] = nil
			end
			A.passes[idx] = A.passes[idx] or {}
			A.passes[idx][senderKey] = true
			A:RecalcVoted(idx)
			A:RefreshCouncil()
		end
	elseif cmd == "W" then
		local idxStr, player = string.match(rest, "^(%d+)%^(.*)$")
		local idx = tonumber(idxStr)
		if idx and player and player ~= "" then
			A.winners = A.winners or {}
			A.winners[idx] = player
			A:RefreshCouncil()
		end
	elseif cmd == "T" then
		local idxStr, val = string.match(rest, "^(%d+)%^(.*)$")
		local idx = tonumber(idxStr)
		if idx then
			A.traded = A.traded or {}
			local item = A.items[idx]
			local count = math.max(0, tonumber(val) or 0)
			if item then item.awardedCount = math.min(A:ItemQuantity(item), count) end
			A.traded[idx] = count > 0 and count or nil
			A:RefreshCouncil()
		end
	elseif cmd == "K" then
		A.council = {}
		for n in string.gmatch(rest, "[^~]+") do
			table.insert(A.council, n)
		end
		AscensionRaidCouncilDB.council = A.council
		if A.RefreshRMList then
			A:RefreshRMList()
		end
		A:RefreshCouncil()
	elseif cmd == "Q" then
		if A:IsML() or (A:IsCouncil() and A:CouncilCount() > 0) then
			A:BroadcastCouncil()
		end
	elseif cmd == "H" then
		if A:CanSyncHistory() and (A:IsSyncPeer(sender) or A:NamesEqual(sender, A.me)) then
			local e = DecodeHistory(rest)
			if e and A:AddHistoryEntry(e) then
				A.histDirty = true
				if A.RefreshHistory then
					A:RefreshHistory()
				end
			end
		end
	elseif cmd == "Y" then
		if A:CanSyncHistory() and (A:IsSyncPeer(sender) or A:NamesEqual(sender, A.me)) then
			if rest and rest ~= "" then
				if A:RemoveHistoryId(rest) then
					A.histDirty = true
					if A.RefreshHistory then
						A:RefreshHistory()
					end
				end
			end
		end
	elseif cmd == "G" then
		if not A:NamesEqual(sender, A.me) and A:CanSyncHistory() and A:IsSyncPeer(sender) then
			local cStr, sStr = string.match(rest, "^(%d+)%^(%-?%d+)$")
			if cStr then
				A:AnswerHistorySync(tonumber(cStr), tonumber(sStr))
			end
		end

	end

end
