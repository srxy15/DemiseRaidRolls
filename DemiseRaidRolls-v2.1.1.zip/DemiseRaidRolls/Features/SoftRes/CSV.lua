-- softres.it CSV: quoted commas/newlines and doubled quotes are supported.
function DemiseRaidRollsSoftRes.DecodeSoftresCSV(input)
    if type(input) ~= "string" then return nil, "the export is not text" end
    if #input > 200000 then return nil, "the CSV is too large" end
    input = input:gsub("^\239\187\191", ""):gsub("\r\n", "\n"):gsub("\r", "\n")
    local rows, row, field = {}, {}, {}
    local quoted, closed = false, false
    local i = 1
    local function FinishField()
        row[#row + 1] = table.concat(field)
        field = {}
        closed = false
    end
    local function FinishRow()
        FinishField()
        if #row > 1 or row[1]:match("%S") then rows[#rows + 1] = row end
        row = {}
    end
    while i <= #input do
        local c = input:sub(i, i)
        if quoted then
            if c == '"' then
                if input:sub(i + 1, i + 1) == '"' then
                    field[#field + 1] = '"'; i = i + 1
                else quoted = false; closed = true end
            else field[#field + 1] = c end
        elseif c == ',' then FinishField()
        elseif c == '\n' then FinishRow()
        elseif c == '"' and #field == 0 and not closed then quoted = true
        elseif closed or c == '"' then return nil, "invalid CSV quoting"
        else field[#field + 1] = c end
        i = i + 1
    end
    if quoted then return nil, "unterminated CSV quote" end
    if #field > 0 or #row > 0 or closed then FinishRow() end
    local header = rows[1]
    if not header then return nil, "paste the complete softres.it CSV, including its header" end
    local columns = {}
    for index, name in ipairs(header) do columns[name:match("^%s*(.-)%s*$")] = index end
    if not columns["Item ID"] or not columns["Raider Name"] then
        return nil, "CSV must contain Item ID and Raider Name columns"
    end
    local root = { metadata = { source = "softres.it CSV" }, softreserves = {}, hardreserves = {} }
    local players = {}
    for index = 2, #rows do
        local values = rows[index]
        if #values ~= #header then return nil, "CSV column count mismatch at row " .. index end
        local name = values[columns["Raider Name"]]:match("^%s*(.-)%s*$")
        local itemID = tonumber(values[columns["Item ID"]])
        if name == "" or not itemID or itemID <= 0 or itemID ~= math.floor(itemID) then
            return nil, "invalid raider name or item ID at CSV row " .. index
        end
        local key = string.lower(name)
        local player = players[key]
        if not player then
            player = { name = name, items = {} }
            players[key] = player
            root.softreserves[#root.softreserves + 1] = player
        end
        player.items[#player.items + 1] = itemID
    end
    return root
end
