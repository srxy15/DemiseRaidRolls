local Addon = DemiseRaidRolls
Addon.TradeableItems = Addon.TradeableItems or {}
local Module = Addon.TradeableItems

local function Print(message)
    if DEFAULT_CHAT_FRAME then DEFAULT_CHAT_FRAME:AddMessage('|cff33ff99ARLC|r: ' .. tostring(message)) end
end

-- Count how many matching copies of the selected item can actually be traded.
-- A copy is eligible for Top X Rolls when either:
--   1) its tooltip contains Ascension's temporary raid-loot trade text, or
--   2) it is still an unbound BoE item ("Binds when equipped").
-- Soulbound copies without the temporary trade permission are excluded.
local tradeScanTooltip

local function GetBagItemCount(bag, slot)
    if not GetContainerItemInfo then
        return 1
    end

    local _, count = GetContainerItemInfo(bag, slot)
    count = tonumber(count) or 1
    if count < 1 then
        count = 1
    end
    return count
end

local function ReadTradeScanTooltipText()
    if not tradeScanTooltip then
        return nil
    end

    -- Concatenate both tooltip columns. Ascension can wrap binding/trade text
    -- across multiple lines, so normalize the complete tooltip before matching.
    local parts = {}
    local numLines = tradeScanTooltip:NumLines() or 0
    local i
    for i = 1, numLines do
        local left = _G["DemiseRaidRollsTradeScanTooltipTextLeft" .. i]
        local right = _G["DemiseRaidRollsTradeScanTooltipTextRight" .. i]
        local leftText = left and left:GetText() or nil
        local rightText = right and right:GetText() or nil
        if leftText and leftText ~= "" then
            parts[#parts + 1] = string.lower(leftText)
        end
        if rightText and rightText ~= "" then
            parts[#parts + 1] = string.lower(rightText)
        end
    end

    local tooltipText = table.concat(parts, " ")
    tooltipText = string.gsub(tooltipText, "%s+", " ")
    return tooltipText
end

local function EnsureTradeScanTooltip()
    if not CreateFrame or not UIParent then
        return false
    end

    if not tradeScanTooltip then
        tradeScanTooltip = CreateFrame("GameTooltip", "DemiseRaidRollsTradeScanTooltip", UIParent, "GameTooltipTemplate")
    end

    tradeScanTooltip:SetOwner(UIParent, "ANCHOR_NONE")
    return true
end

local function GetBagItemTooltipText(bag, slot)
    if not EnsureTradeScanTooltip() then
        return nil
    end

    tradeScanTooltip:ClearLines()
    local ok = pcall(function()
        tradeScanTooltip:SetBagItem(bag, slot)
    end)
    if not ok then
        tradeScanTooltip:Hide()
        return nil
    end

    local tooltipText = ReadTradeScanTooltipText()
    tradeScanTooltip:Hide()
    return tooltipText
end

local function GetItemLinkTooltipText(itemLink)
    if not itemLink or not EnsureTradeScanTooltip() then
        return nil
    end

    tradeScanTooltip:ClearLines()
    local ok = pcall(function()
        tradeScanTooltip:SetHyperlink(itemLink)
    end)
    if not ok then
        tradeScanTooltip:Hide()
        return nil
    end

    local tooltipText = ReadTradeScanTooltipText()
    tradeScanTooltip:Hide()
    return tooltipText
end

local function TooltipContains(text, needle)
    return text and needle and needle ~= "" and string.find(text, needle, 1, true) ~= nil
end

local function GetBindingScanStrings()
    local temporaryTradePrefix = "you may trade this item with players that were also eligible to loot this item for the next"
    local boeText = string.lower(tostring(_G.ITEM_BIND_ON_EQUIP or "Binds when equipped"))
    local soulboundText = string.lower(tostring(_G.ITEM_SOULBOUND or "Soulbound"))
    return temporaryTradePrefix, boeText, soulboundText
end

local function IsItemLinkBoE(itemLink)
    local tooltipText = GetItemLinkTooltipText(itemLink)
    local _, boeText = GetBindingScanStrings()
    return TooltipContains(tooltipText, boeText)
end

local function IsBagItemTradeableForRoll(bag, slot, baseItemIsBoE)
    local tooltipText = GetBagItemTooltipText(bag, slot)
    local temporaryTradePrefix, boeText, soulboundText = GetBindingScanStrings()

    -- Temporary raid-loot permission always makes this specific copy eligible.
    if TooltipContains(tooltipText, temporaryTradePrefix) then
        return true, "temporary-trade"
    end

    -- A copy explicitly marked Soulbound must never increase Top X unless the
    -- temporary-trade permission above was present.
    if TooltipContains(tooltipText, soulboundText) then
        return false, "soulbound"
    end

    -- Prefer the per-slot tooltip when it exposes the BoE line.
    if TooltipContains(tooltipText, boeText) then
        return true, "boe-slot"
    end

    -- Ascension occasionally returns an incomplete hidden bag tooltip for one
    -- of two identical items. The binding rule is an item property, so if the
    -- selected item itself is confirmed BoE and this matching copy is not
    -- explicitly Soulbound, treat it as an unbound BoE copy.
    if baseItemIsBoE then
        return true, "boe-item-fallback"
    end

    return false, tooltipText and "not-tradeable" or "tooltip-unavailable"
end

function Module.Count(itemLink, itemID, debugOutput)
    if not GetContainerNumSlots or not GetContainerItemLink then
        return 1
    end

    local wantedID = tonumber(itemID)
    if not wantedID and type(itemLink) == "string" then
        wantedID = tonumber(itemLink:match("item:(%d+)"))
    end

    -- Determine the static binding rule once from the selected item's hyperlink.
    -- This is more reliable than requiring every hidden bag tooltip to repeat
    -- "Binds when equipped" correctly.
    local baseItemIsBoE = IsItemLinkBoE(itemLink)

    local total = 0
    local bag
    for bag = 0, 4 do
        local slots = GetContainerNumSlots(bag) or 0
        local slot
        for slot = 1, slots do
            local bagLink = GetContainerItemLink(bag, slot)
            if bagLink then
                local bagID = tonumber(bagLink:match("item:(%d+)"))
                local matches = false

                if wantedID and bagID then
                    matches = wantedID == bagID
                elseif itemLink then
                    matches = bagLink == itemLink
                end

                if matches then
                    local eligible, reason = IsBagItemTradeableForRoll(bag, slot, baseItemIsBoE)
                    local count = GetBagItemCount(bag, slot)
                    if eligible then
                        total = total + count
                    end
                    if debugOutput then
                        Print("Top X scan: bag " .. tostring(bag) .. ", slot " .. tostring(slot) .. ", x" .. tostring(count) .. " -> " .. tostring(reason) .. (eligible and " [COUNTED]" or " [IGNORED]"))
                    end
                end
            end
        end
    end

    if debugOutput then
        Print("Top X scan: selected item BoE = " .. tostring(baseItemIsBoE) .. ", total = " .. tostring(total))
    end

    -- Keep the normal single-item wording when fewer than two tradeable copies
    -- can be verified. Temporary-trade loot and unbound BoE copies both count.
    if total < 1 then
        total = 1
    end
    return total
end

