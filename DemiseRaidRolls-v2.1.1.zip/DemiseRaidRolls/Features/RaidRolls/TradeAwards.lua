local Addon = DemiseRaidRolls
Addon.TradeAwards = Addon.TradeAwards or {}
local Awards = Addon.TradeAwards

Awards.active = nil
Awards.verifying = nil
Awards.onCompleted = nil

local function ItemID(link)
    return type(link) == "string" and tonumber(link:match("item:(%d+)")) or nil
end

local function CountMatchingCopies(itemLink, itemID)
    if not GetContainerNumSlots or not GetContainerItemLink then return nil end
    local wantedID = tonumber(itemID) or ItemID(itemLink)
    local total = 0
    local bag
    for bag = 0, 4 do
        local slots = GetContainerNumSlots(bag) or 0
        local slot
        for slot = 1, slots do
            local link = GetContainerItemLink(bag, slot)
            local matches = link and ((itemLink and link == itemLink) or (wantedID and ItemID(link) == wantedID))
            if matches then
                local count = 1
                if GetContainerItemInfo then
                    local _, stackCount = GetContainerItemInfo(bag, slot)
                    count = math.max(1, tonumber(stackCount) or 1)
                end
                total = total + count
            end
        end
    end
    return total
end

local function TradeContainsItem(context)
    if not context or not GetTradePlayerItemLink then return context and context.itemWasPlaced == true end
    local slot
    for slot = 1, 6 do
        local link = GetTradePlayerItemLink(slot)
        if link and ((context.itemLink and link == context.itemLink)
            or (context.itemID and ItemID(link) == context.itemID)) then
            return true
        end
    end
    return false
end

local function Complete(context)
    if not context or context.completed then return end
    context.completed = true
    Awards.active = nil
    Awards.verifying = nil
    if Awards.onCompleted then
        Awards.onCompleted(context.player, context.rollType)
    end
end

function Awards.SetCompletedCallback(callback)
    Awards.onCompleted = callback
end

function Awards.Begin(player, rollType, itemLink, itemID)
    Awards.active = {
        player = player,
        rollType = rollType == "OS" and "OS" or "MS",
        itemLink = itemLink,
        itemID = tonumber(itemID) or ItemID(itemLink),
        copiesBefore = CountMatchingCopies(itemLink, itemID),
        itemWasPlaced = false,
        itemStillPresent = false,
    }
end

function Awards.MarkPlaced()
    if not Awards.active then return end
    Awards.active.itemWasPlaced = true
    Awards.active.itemStillPresent = TradeContainsItem(Awards.active)
end

function Awards.CancelPreparation()
    if Awards.active and not Awards.active.itemWasPlaced then
        Awards.active = nil
    end
end

local verifyDriver = CreateFrame("Frame")
verifyDriver:Hide()
verifyDriver.elapsed = 0
verifyDriver:SetScript("OnUpdate", function(self, elapsed)
    self.elapsed = self.elapsed + (elapsed or 0)
    if self.elapsed < 0.75 then return end
    self:Hide()
    self.elapsed = 0
    local context = Awards.verifying
    Awards.verifying = nil
    if not context or context.completed or not context.itemWasPlaced then return end
    local copiesAfter = CountMatchingCopies(context.itemLink, context.itemID)
    if context.copiesBefore and copiesAfter and copiesAfter < context.copiesBefore then
        Complete(context)
    else
        context.verifyAttempts = (tonumber(context.verifyAttempts) or 0) + 1
        if context.verifyAttempts < 3 then
            Awards.verifying = context
            verifyDriver:Show()
        end
    end
end)

local eventFrame = CreateFrame("Frame")
eventFrame:RegisterEvent("TRADE_ACCEPT_UPDATE")
eventFrame:RegisterEvent("TRADE_PLAYER_ITEM_CHANGED")
eventFrame:RegisterEvent("UI_INFO_MESSAGE")
eventFrame:RegisterEvent("TRADE_CLOSED")
eventFrame:SetScript("OnEvent", function(_, event, ...)
    if event == "TRADE_ACCEPT_UPDATE" or event == "TRADE_PLAYER_ITEM_CHANGED" then
        if Awards.active and Awards.active.itemWasPlaced then
            Awards.active.itemStillPresent = TradeContainsItem(Awards.active)
        end
        return
    end

    if event == "UI_INFO_MESSAGE" then
        local first, second = ...
        local message = tostring(type(second) == "string" and second or first or "")
        local tradeComplete = tostring(_G.ERR_TRADE_COMPLETE or "Trade complete.")
        local context = Awards.active or Awards.verifying
        if context and context.itemWasPlaced and context.itemStillPresent
            and string.lower(message) == string.lower(tradeComplete) then
            Complete(context)
        end
        return
    end

    if Awards.active and Awards.active.itemWasPlaced then
        Awards.active.verifyAttempts = 0
        Awards.verifying = Awards.active
        Awards.active = nil
        verifyDriver.elapsed = 0
        verifyDriver:Show()
    else
        Awards.active = nil
    end
end)
