-- DemiseRaidRolls - temporary loot trade expiration tracker
-- Project Ascension / WoW 3.3.5a compatible; no Retail container APIs.
local Addon = DemiseRaidRolls
Addon.TradeTimers = Addon.TradeTimers or {}
local Timers = Addon.TradeTimers

local ALERT_AT = 20 * 60
local DEFAULT_WINDOW = 2 * 60 * 60
local BAG_SCAN_DELAY = 1
local WORLD_SCAN_DELAY = 3
local TIMER_UPDATE_INTERVAL = 1
local TOOLTIP_RETRY_DELAY = 1
local MAX_TOOLTIP_RETRIES = 2
local RELOCATION_WINDOW = 5
local RELOCATION_EXPIRY_TOLERANCE = 90
local MAX_ROWS = 10
local HEADER_HEIGHT = 21
local ROW_HEIGHT = 19

Timers.entries = Timers.entries or {}
Timers.slotSignatures = Timers.slotSignatures or {}
Timers.recentlyRemoved = Timers.recentlyRemoved or {}
Timers.tooltipRetries = Timers.tooltipRetries or {}
Timers.nextTrackingID = Timers.nextTrackingID or 0
Timers.frame = nil
Timers.tooltip = nil
Timers.manualHidden = true
Timers.forceShown = false

local function NormalizeName(name)
    if type(name) ~= "string" then return nil end
    name = name:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", "")
    name = name:match("^%s*(.-)%s*$")
    name = name and (name:match("^([^%-]+)") or name) or nil
    return name and string.lower(name) or nil
end

local function IsSamePlayer(a, b)
    local left, right = NormalizeName(a), NormalizeName(b)
    return left and right and left == right
end

local function IsCurrentMasterLooter()
    if not GetLootMethod then return false end
    local method, partyIndex, raidIndex = GetLootMethod()
    if method ~= "master" then return false end
    if raidIndex ~= nil then
        if raidIndex == 0 then return true end
        local name = GetRaidRosterInfo and GetRaidRosterInfo(raidIndex) or nil
        return IsSamePlayer(name, UnitName("player"))
    end
    if partyIndex ~= nil then
        if partyIndex == 0 then return true end
        return IsSamePlayer(UnitName("party" .. tostring(partyIndex)), UnitName("player"))
    end
    return false
end

local function FormatTime(seconds)
    seconds = math.max(0, math.floor((tonumber(seconds) or 0) + 0.5))
    local hours = math.floor(seconds / 3600)
    local minutes = math.floor((seconds % 3600) / 60)
    local secs = seconds % 60
    if hours > 0 then
        return string.format("%d:%02d:%02d", hours, minutes, secs)
    end
    return string.format("%d:%02d", minutes, secs)
end

local function ParseRemainingTime(text)
    text = string.lower(tostring(text or ""))
    if text:find("less than a minute", 1, true) then return 30 end
    local h, m, s = text:match("(%d+)%s*:%s*(%d+)%s*:%s*(%d+)")
    if h then return (tonumber(h) * 3600) + (tonumber(m) * 60) + tonumber(s) end

    local total = 0
    local value = text:match("(%d+)%s*day")
    if value then total = total + tonumber(value) * 86400 end
    value = text:match("(%d+)%s*h[ou]*r")
    if value then total = total + tonumber(value) * 3600 end
    value = text:match("(%d+)%s*min")
    if value then total = total + tonumber(value) * 60 end
    value = text:match("(%d+)%s*sec")
    if value then total = total + tonumber(value) end
    return total > 0 and total or nil
end

local function EnsureTooltip()
    if Timers.tooltip then return Timers.tooltip end
    local tooltip = CreateFrame("GameTooltip", "DemiseRaidRollsTradeTimerTooltip", UIParent, "GameTooltipTemplate")
    tooltip:SetOwner(UIParent, "ANCHOR_NONE")
    Timers.tooltip = tooltip
    return tooltip
end

local function ReadTradeTime(bag, slot)
    local tooltip = EnsureTooltip()
    tooltip:ClearLines()
    local ok = pcall(tooltip.SetBagItem, tooltip, bag, slot)
    if not ok then return nil end

    -- Ascension can wrap the temporary-trade sentence across several lines or
    -- place part of it in the tooltip's right column. Read and normalize the
    -- complete tooltip before looking for the two stable sentence fragments.
    local parts = {}
    local i
    for i = 1, 30 do
        local left = _G["DemiseRaidRollsTradeTimerTooltipTextLeft" .. tostring(i)]
        local right = _G["DemiseRaidRollsTradeTimerTooltipTextRight" .. tostring(i)]
        local leftText = left and left:GetText() or nil
        local rightText = right and right:GetText() or nil
        if leftText and leftText ~= "" then parts[#parts + 1] = leftText end
        if rightText and rightText ~= "" then parts[#parts + 1] = rightText end
    end

    local text = string.lower(table.concat(parts, " "))
    text = string.gsub(text, "%s+", " ")
    if text:find("you may trade this item with", 1, true)
        and text:find("eligible to loot this item", 1, true) then
        return ParseRemainingTime(text), text
    end
    return nil
end

local function ShowAlert(itemLink, remaining, owner)
    local ownerText = owner and not IsSamePlayer(owner, UnitName("player")) and (" held by " .. tostring(owner)) or ""
    local message = "TRADE TIMER: " .. tostring(itemLink or "item") .. ownerText .. " has " .. FormatTime(remaining) .. " remaining"
    if RaidNotice_AddMessage and RaidWarningFrame and ChatTypeInfo and ChatTypeInfo["RAID_WARNING"] then
        RaidNotice_AddMessage(RaidWarningFrame, message, ChatTypeInfo["RAID_WARNING"])
    elseif UIErrorsFrame and UIErrorsFrame.AddMessage then
        UIErrorsFrame:AddMessage(message, 1.0, 0.2, 0.2, 1.0)
    end
    if DEFAULT_CHAT_FRAME then
        DEFAULT_CHAT_FRAME:AddMessage("|cff33ff99ARR|r: " .. message)
    end
    if PlaySound then pcall(PlaySound, "RaidWarning") end
end

local function AlertLocalMasterLooter(entry)
    if not IsCurrentMasterLooter() then return false end
    ShowAlert(entry.link, entry.remaining)
    return true
end

local function CheckAlert(entry)
    if not entry or (entry.remaining or 0) > ALERT_AT then return end
    if not entry.alerted and AlertLocalMasterLooter(entry) then
        entry.alerted = true
    end
end

local function CreateFrameUI()
    if Timers.frame then return Timers.frame end
    local frame = CreateFrame("Frame", "DemiseRaidRollsTradeTimersFrame", UIParent)
    frame:SetWidth(250)
    frame:SetHeight(42)
    frame:SetFrameStrata("DIALOG")
    frame:SetClampedToScreen(true)
    frame:EnableMouse(true)
    frame:SetMovable(true)
    frame:RegisterForDrag("LeftButton")
    frame:SetScript("OnDragStart", function(self) self:StartMoving() end)
    frame:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end)
    frame:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", tile = true, tileSize = 8, edgeSize = 8, insets = { left = 2, right = 2, top = 2, bottom = 2 } })
    frame:SetBackdropColor(0, 0, 0, 0.78)
    frame:SetBackdropBorderColor(0.18, 0.18, 0.18, 0.95)
    frame:SetPoint("CENTER", UIParent, "CENTER", -320, 100)

    frame.header = frame:CreateTexture(nil, "BACKGROUND")
    frame.header:SetPoint("TOPLEFT", frame, "TOPLEFT", 2, -2)
    frame.header:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -2, -2)
    frame.header:SetHeight(HEADER_HEIGHT - 2)
    frame.header:SetTexture(0.02, 0.02, 0.02, 0.92)

    frame.title = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    frame.title:SetPoint("TOPLEFT", frame, "TOPLEFT", 7, -5)
    frame.title:SetText("Trade expiration timers")
    frame.title:SetTextColor(1, 1, 1)

    frame.close = CreateFrame("Button", nil, frame, "UIPanelCloseButton")
    frame.close:SetWidth(20)
    frame.close:SetHeight(20)
    frame.close:SetPoint("TOPRIGHT", frame, "TOPRIGHT", 1, 1)
    frame.close:SetScript("OnClick", function() Timers.manualHidden = true; Timers.forceShown = false; frame:Hide() end)

    frame.empty = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    frame.empty:SetPoint("TOPLEFT", frame, "TOPLEFT", 7, -25)
    frame.empty:SetText("No temporarily tradeable items")
    frame.empty:SetTextColor(0.60, 0.60, 0.60)
    frame.empty:Hide()
    frame.rows = {}

    local i
    for i = 1, MAX_ROWS do
        local row = CreateFrame("Frame", nil, frame)
        row:SetHeight(ROW_HEIGHT)
        row:SetPoint("TOPLEFT", frame, "TOPLEFT", 1, -(HEADER_HEIGHT + ((i - 1) * ROW_HEIGHT)))
        row:SetPoint("RIGHT", frame, "RIGHT", -1, 0)
        row:EnableMouse(true)

        row.icon = row:CreateTexture(nil, "ARTWORK")
        row.icon:SetWidth(ROW_HEIGHT)
        row.icon:SetHeight(ROW_HEIGHT)
        row.icon:SetPoint("LEFT", row, "LEFT", 0, 0)

        row.bar = CreateFrame("StatusBar", nil, row)
        row.bar:SetPoint("TOPLEFT", row, "TOPLEFT", ROW_HEIGHT, 0)
        row.bar:SetPoint("BOTTOMRIGHT", row, "BOTTOMRIGHT", 0, 0)
        row.bar:EnableMouse(true)
        row.bar:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar")
        row.bar:SetMinMaxValues(0, DEFAULT_WINDOW)
        row.bar.bg = row.bar:CreateTexture(nil, "BACKGROUND")
        row.bar.bg:SetAllPoints(row.bar)
        row.bar.bg:SetTexture(0.02, 0.02, 0.02, 0.76)

        row.name = row.bar:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        row.name:SetPoint("LEFT", row.bar, "LEFT", 4, 0)
        row.name:SetJustifyH("LEFT")

        row.time = row.bar:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        row.time:SetPoint("RIGHT", row.bar, "RIGHT", -4, 0)
        row.time:SetWidth(52)
        row.time:SetJustifyH("RIGHT")
        row.time:SetTextColor(1, 1, 1)
        row.name:SetPoint("RIGHT", row.time, "LEFT", -2, 0)
        if GameFontHighlightSmall and GameFontHighlightSmall.GetFont then
            local fontPath, fontSize = GameFontHighlightSmall:GetFont()
            if fontPath and fontSize then
                row.name:SetFont(fontPath, fontSize, "OUTLINE")
                row.time:SetFont(fontPath, fontSize, "OUTLINE")
            end
        end

        local function ShowTooltip(self)
            if self.entry and GameTooltip then
                GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
                GameTooltip:SetHyperlink(self.entry.link)
                GameTooltip:Show()
            end
        end
        local function HideTooltip() if GameTooltip then GameTooltip:Hide() end end
        row:SetScript("OnEnter", ShowTooltip)
        row:SetScript("OnLeave", HideTooltip)
        row.bar:SetScript("OnEnter", function() row.bar.entry = row.entry; ShowTooltip(row.bar) end)
        row.bar:SetScript("OnLeave", HideTooltip)
        local function SelectItemForRoll(self, button)
            if button ~= "RightButton" or not IsShiftKeyDown or not IsShiftKeyDown() then return end
            if not row.entry then return end
            local activeModule = DemiseRaidRollsMenu
                and DemiseRaidRollsMenu.GetActiveModule
                and DemiseRaidRollsMenu.GetActiveModule()
            if activeModule == "council" then
                if DemiseRaidCouncil and DemiseRaidCouncil.TryAddLink then
                    DemiseRaidCouncil:TryAddLink(row.entry.link)
                end
                return
            end
            if activeModule == "rolls" and Addon.SetRollItem then
                Addon.SetRollItem(row.entry.link, row.entry.itemID)
            end
        end
        row:SetScript("OnMouseUp", SelectItemForRoll)
        row.bar:SetScript("OnMouseUp", SelectItemForRoll)
        row:Hide()
        frame.rows[i] = row
    end
    frame:Hide()
    Timers.frame = frame
    return frame
end

local function UpdateFrame()
    local frame = CreateFrameUI()
    local list = {}
    local _, entry
    for _, entry in pairs(Timers.entries) do list[#list + 1] = entry end
    table.sort(list, function(a, b)
        if a == b then return false end
        local aRemaining = tonumber(a.remaining) or 0
        local bRemaining = tonumber(b.remaining) or 0
        if aRemaining ~= bRemaining then return aRemaining < bRemaining end
        local aQuality = tonumber(a.quality) or -1
        local bQuality = tonumber(b.quality) or -1
        if aQuality ~= bQuality then return aQuality > bQuality end
        local aName = tostring(a.name or a.link or "")
        local bName = tostring(b.name or b.link or "")
        if aName ~= bName then return aName < bName end
        return (tonumber(a.trackingID) or 0) < (tonumber(b.trackingID) or 0)
    end)

    local i
    for i = 1, MAX_ROWS do
        local row = frame.rows[i]
        entry = list[i]
        if entry then
            row.entry = entry
            row.icon:SetTexture(entry.texture or "Interface\\Icons\\INV_Misc_QuestionMark")
            row.name:SetText(entry.link or "Unknown item")
            row.time:SetText(FormatTime(entry.remaining))
            local maximum = math.max(DEFAULT_WINDOW, tonumber(entry.initialRemaining) or 0)
            row.bar:SetMinMaxValues(0, maximum)
            row.bar:SetValue(math.max(0, entry.remaining or 0))
            if entry.remaining <= ALERT_AT then
                row.bar:SetStatusBarColor(1.0, 0.0, 0.0, 0.38)
            elseif entry.remaining <= 60 * 60 then
                row.bar:SetStatusBarColor(1.0, 1.0, 0.0, 0.34)
            else
                row.bar:SetStatusBarColor(0.0, 1.0, 0.0, 0.30)
            end
            row:Show()
        else
            row.entry = nil
            row:Hide()
        end
    end
    if #list > 0 and not Timers.manualHidden then
        frame.empty:Hide()
        frame:SetHeight(HEADER_HEIGHT + (math.min(#list, MAX_ROWS) * ROW_HEIGHT) + 2)
        frame:Show()
    elseif #list == 0 and Timers.forceShown and not Timers.manualHidden then
        frame.empty:Show()
        frame:SetHeight(42)
        frame:Show()
    else
        frame.empty:Hide()
        frame:Hide()
    end
end

local timerDriver = CreateFrame("Frame")
timerDriver:Hide()
timerDriver.elapsed = 0

local function SlotSignature(bag, slot, link)
    if not link then return nil end
    local count = 1
    if GetContainerItemInfo then
        local _, itemCount = GetContainerItemInfo(bag, slot)
        count = tonumber(itemCount) or 1
    end
    return tostring(link) .. "|" .. tostring(count)
end

local function RememberRemovedEntry(entry, removed)
    if not entry then return end
    entry.removedAt = GetTime and GetTime() or 0
    removed[#removed + 1] = entry
end

local function ScanBag(bag, force, added, removed, retryBags)
    if type(bag) ~= "number" or bag < 0 or bag > 4 then return end
    local slots = GetContainerNumSlots and GetContainerNumSlots(bag) or 0
    local prefix = tostring(bag) .. ":"
    local key
    for key in pairs(Timers.slotSignatures) do
        if string.sub(key, 1, string.len(prefix)) == prefix then
            local oldSlot = tonumber(string.match(key, ":(%d+)$")) or 0
            if oldSlot > slots then
                RememberRemovedEntry(Timers.entries[key], removed)
                Timers.slotSignatures[key] = nil
                Timers.entries[key] = nil
            end
        end
    end

    local slot
    for slot = 1, slots do
        key = prefix .. tostring(slot)
        local link = GetContainerItemLink and GetContainerItemLink(bag, slot) or nil
        local signature = SlotSignature(bag, slot, link)
        if force or signature ~= Timers.slotSignatures[key] then
            local previous = Timers.entries[key]
            RememberRemovedEntry(previous, removed)
            Timers.entries[key] = nil
            if link then
                local remaining = ReadTradeTime(bag, slot)
                if remaining then
                    Timers.slotSignatures[key] = signature
                    Timers.tooltipRetries[key] = nil
                    local itemName, _, quality, _, _, _, _, _, _, texture = GetItemInfo(link)
                    local entry = {
                        key = key,
                        bag = bag,
                        slot = slot,
                        link = link,
                        itemID = tonumber(link:match("item:(%d+)")),
                        texture = texture,
                        name = itemName,
                        quality = quality,
                        remaining = remaining,
                        expiresAt = GetTime() + remaining,
                        initialRemaining = remaining,
                    }
                    Timers.entries[key] = entry
                    added[#added + 1] = entry
                elseif not force then
                    -- A freshly looted item's hidden tooltip is sometimes not
                    -- populated yet on Ascension. Leave its signature pending
                    -- so a targeted follow-up scan checks only this changed
                    -- slot instead of repeatedly scanning the whole inventory.
                    local retry = Timers.tooltipRetries[key]
                    if not retry or retry.signature ~= signature then
                        retry = { signature = signature, attempts = 0 }
                        Timers.tooltipRetries[key] = retry
                    end
                    retry.attempts = retry.attempts + 1
                    if retry.attempts <= MAX_TOOLTIP_RETRIES then
                        retryBags[bag] = true
                    else
                        Timers.slotSignatures[key] = signature
                        Timers.tooltipRetries[key] = nil
                    end
                else
                    Timers.slotSignatures[key] = signature
                    Timers.tooltipRetries[key] = nil
                end
            else
                Timers.slotSignatures[key] = nil
                Timers.tooltipRetries[key] = nil
            end
        end
    end
end

local function SameTrackedItem(left, right)
    if not left or not right then return false end
    if left.itemID and right.itemID and left.itemID ~= right.itemID then return false end
    if left.link and right.link and left.link ~= right.link then return false end
    local leftExpiry = tonumber(left.expiresAt) or 0
    local rightExpiry = tonumber(right.expiresAt) or 0
    return math.abs(leftExpiry - rightExpiry) <= RELOCATION_EXPIRY_TOLERANCE
end

local function AdoptTrackingState(entry, candidates)
    local bestIndex
    local bestDifference
    local i
    for i = 1, #candidates do
        local candidate = candidates[i]
        if SameTrackedItem(entry, candidate) then
            local difference = math.abs((tonumber(entry.expiresAt) or 0) - (tonumber(candidate.expiresAt) or 0))
            if not bestDifference or difference < bestDifference then
                bestDifference = difference
                bestIndex = i
            end
        end
    end

    if bestIndex then
        local previous = table.remove(candidates, bestIndex)
        local now = GetTime and GetTime() or 0
        entry.trackingID = previous.trackingID
        entry.alerted = previous.alerted == true
        -- The tooltip usually rounds its displayed duration to whole minutes.
        -- Preserve the precise locally calculated expiry when this is the same
        -- physical item moving between slots, otherwise every move can add up
        -- to almost a minute back onto the visible countdown.
        entry.expiresAt = tonumber(previous.expiresAt) or entry.expiresAt
        entry.remaining = math.max(0, (tonumber(entry.expiresAt) or now) - now)
        entry.initialRemaining = math.max(tonumber(entry.initialRemaining) or 0, tonumber(previous.initialRemaining) or 0)
        return true
    end

    Timers.nextTrackingID = (tonumber(Timers.nextTrackingID) or 0) + 1
    entry.trackingID = Timers.nextTrackingID
    return false
end

local function ReconcileTrackedItems(added, removed)
    local now = GetTime and GetTime() or 0
    local candidates = {}
    local seen = {}
    local i
    for i = 1, #Timers.recentlyRemoved do
        local entry = Timers.recentlyRemoved[i]
        if not seen[entry] and now - (tonumber(entry.removedAt) or now) <= RELOCATION_WINDOW then
            candidates[#candidates + 1] = entry
            seen[entry] = true
        end
    end
    for i = 1, #removed do
        local entry = removed[i]
        if entry and not seen[entry] then
            candidates[#candidates + 1] = entry
            seen[entry] = true
        end
    end

    for i = 1, #added do
        AdoptTrackingState(added[i], candidates)
        CheckAlert(added[i])
    end

    Timers.recentlyRemoved = {}
    for i = 1, #candidates do
        local entry = candidates[i]
        if now - (tonumber(entry.removedAt) or now) <= RELOCATION_WINDOW then
            Timers.recentlyRemoved[#Timers.recentlyRemoved + 1] = entry
        end
    end
end

local function HasEntries()
    return next(Timers.entries) ~= nil
end

local ScheduleScan

local function CompleteScan(bags, force)
    local added = {}
    local removed = {}
    local retryBags = {}
    local bag
    if bags.all then
        for bag = 0, 4 do ScanBag(bag, force, added, removed, retryBags) end
    else
        for bag in pairs(bags) do ScanBag(bag, force, added, removed, retryBags) end
    end
    ReconcileTrackedItems(added, removed)
    if HasEntries() then timerDriver:Show() else timerDriver:Hide() end
    UpdateFrame()
    for bag in pairs(retryBags) do
        ScheduleScan(bag, TOOLTIP_RETRY_DELAY, false)
    end
end

local scanDriver = CreateFrame("Frame")
scanDriver:Hide()
scanDriver.elapsed = 0
scanDriver.delay = BAG_SCAN_DELAY
scanDriver.bags = {}
scanDriver.force = false
scanDriver:SetScript("OnUpdate", function(self, elapsed)
    self.elapsed = self.elapsed + (elapsed or 0)
    if self.elapsed < self.delay then return end
    self:Hide()
    local bags, force = self.bags, self.force
    self.bags = {}
    self.force = false
    CompleteScan(bags, force)
end)

ScheduleScan = function(bag, delay, force)
    if type(bag) == "number" and bag >= 0 and bag <= 4 then
        scanDriver.bags[bag] = true
    else
        scanDriver.bags.all = true
    end
    scanDriver.force = scanDriver.force or force == true
    scanDriver.elapsed = 0
    scanDriver.delay = tonumber(delay) or BAG_SCAN_DELAY
    scanDriver:Show()
end

timerDriver:SetScript("OnUpdate", function(self, elapsed)
    self.elapsed = self.elapsed + (elapsed or 0)
    if self.elapsed < TIMER_UPDATE_INTERVAL then return end
    self.elapsed = 0
    local now = GetTime()
    local key, entry
    for key, entry in pairs(Timers.entries) do
        entry.remaining = math.max(0, (entry.expiresAt or now) - now)
        if entry.remaining <= 0 then
            Timers.entries[key] = nil
        else
            CheckAlert(entry)
        end
    end
    if not HasEntries() then self:Hide() end
    if Timers.frame and Timers.frame:IsShown() then UpdateFrame() end
end)

function Timers.Toggle()
    local frame = CreateFrameUI()
    if frame:IsShown() then
        Timers.manualHidden = true
        Timers.forceShown = false
        frame:Hide()
        return
    end
    Timers.manualHidden = false
    Timers.forceShown = true
    UpdateFrame()
    ScheduleScan(nil, 0, false)
end

SLASH_DEMISERAIDROLLSTIMERS1 = "/rrtimers"
SlashCmdList["DEMISERAIDROLLSTIMERS"] = Timers.Toggle

local eventFrame = CreateFrame("Frame")
eventFrame:RegisterEvent("ADDON_LOADED")
eventFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
eventFrame:RegisterEvent("BAG_UPDATE")
eventFrame:RegisterEvent("LOOT_CLOSED")
eventFrame:SetScript("OnEvent", function(self, event, ...)
    if event == "ADDON_LOADED" then
        local addonName = ...
        if addonName ~= "DemiseRaidRolls" then return end
        CreateFrameUI()
        ScheduleScan(nil, WORLD_SCAN_DELAY, true)
    elseif event == "BAG_UPDATE" then
        local bag = ...
        ScheduleScan(tonumber(bag), BAG_SCAN_DELAY, false)
    elseif event == "PLAYER_ENTERING_WORLD" then
        ScheduleScan(nil, WORLD_SCAN_DELAY, true)
    else
        ScheduleScan(nil, BAG_SCAN_DELAY, false)
    end
end)
