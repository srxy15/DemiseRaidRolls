local Addon = DemiseRaidRolls
local originalColors = setmetatable({}, { __mode = "k" })

local function ApplyFont(font, enabled)
    if not font or not font.GetTextColor or not font.SetTextColor then return end
    local saved = originalColors[font]
    if not saved then
        local r, g, b, a = font:GetTextColor()
        saved = { r or 1, g or 1, b or 1, a or 1 }
        originalColors[font] = saved
    end
    if not enabled then
        font:SetTextColor(saved[1], saved[2], saved[3], saved[4])
        return
    end
    local r, g, b = saved[1], saved[2], saved[3]
    -- Brighten neutral copy and gold headings while preserving item-quality,
    -- class, SR, MS/OS, success, and error colours.
    if math.abs(r - g) < 0.08 and math.abs(g - b) < 0.08 then
        local shade = math.max(r, g, b) < 0.82 and 0.90 or 1
        font:SetTextColor(shade, shade, shade, saved[4])
    elseif r > 0.70 and g > 0.42 and b < 0.42 then
        font:SetTextColor(1, 0.86, 0.20, saved[4])
    else
        font:SetTextColor(r, g, b, saved[4])
    end
end

local function WalkFrame(frame, enabled, visited, excluded)
    if not frame or visited[frame] or (excluded and excluded[frame]) then return end
    visited[frame] = true
    -- Button templates manage their own enabled/disabled text colours. Changing
    -- their FontStrings here makes disabled actions such as Tie Break and Trade
    -- turn white and bypasses Blizzard's normal button state styling.
    if frame.GetObjectType and frame:GetObjectType() == "Button" then return end
    if frame.GetRegions then
        local regions = { frame:GetRegions() }
        local i
        for i = 1, table.getn(regions) do
            local region = regions[i]
            if region and region.GetObjectType and region:GetObjectType() == "FontString" then ApplyFont(region, enabled) end
        end
    end
    if frame.GetChildren then
        local children = { frame:GetChildren() }
        local i
        for i = 1, table.getn(children) do WalkFrame(children[i], enabled, visited, excluded) end
    end
end

function Addon.ApplyFontPalette(frame, enabled, excluded)
    WalkFrame(frame, enabled == true, {}, excluded)
end

function Addon.IsHighContrast()
    return true
end

function Addon.ApplyHighContrast()
    local state = Addon.RuntimeState or {}
    local enabled = Addon.IsHighContrast()
    if state.mainFrame and state.mainFrame.SetBackdropColor then state.mainFrame:SetBackdropColor(1, 1, 1, enabled and 1 or 0.78) end
    if state.optionsFrame and state.optionsFrame.SetBackdropColor then state.optionsFrame:SetBackdropColor(1, 1, 1, enabled and 1 or 0.92) end
    if state.msPanel and state.msPanel.bg then state.msPanel.bg:SetTexture(0, 0, 0, enabled and 0.88 or 0.22) end
    if state.osPanel and state.osPanel.bg then state.osPanel.bg:SetTexture(0, 0, 0, enabled and 0.88 or 0.22) end
    if state.mainFrame and state.mainFrame.itemHint then
        local shade = enabled and 0.88 or 0.65
        state.mainFrame.itemHint:SetTextColor(shade, shade, shade)
    end
    -- Roll rows own semantic colours which are refreshed continuously: yellow
    -- values, red rerolls and green FIRST markers. They must never be cached or
    -- recoloured by the general contrast palette.
    local excluded = {}
    if state.msPanel then excluded[state.msPanel] = true end
    if state.osPanel then excluded[state.osPanel] = true end
    Addon.ApplyFontPalette(state.mainFrame, enabled, excluded)
    Addon.ApplyFontPalette(state.optionsFrame, enabled)
end
