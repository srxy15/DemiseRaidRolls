local Addon, State = DemiseRaidRolls, DemiseRaidRolls.RuntimeState
local RADIUS, PI = 80, 3.141592653589793

local function Atan2(y, x)
    if math.atan2 then return math.atan2(y, x) end
    if x > 0 then return math.atan(y / x) end
    if x < 0 and y >= 0 then return math.atan(y / x) + PI end
    if x < 0 and y < 0 then return math.atan(y / x) - PI end
    if x == 0 and y > 0 then return PI / 2 end
    if x == 0 and y < 0 then return -PI / 2 end
    return 0
end

local function Position(angle)
    if not State.minimapButton or not Minimap then return end
    local radians = (tonumber(angle) or 225) * PI / 180
    State.minimapButton:ClearAllPoints()
    State.minimapButton:SetPoint("CENTER", Minimap, "CENTER", math.cos(radians) * RADIUS, math.sin(radians) * RADIUS)
end

local function UpdateFromCursor()
    if not State.minimapButton or not Minimap or not GetCursorPosition then return end
    local cursorX, cursorY = GetCursorPosition()
    local minimapX, minimapY = Minimap:GetCenter()
    if not cursorX or not cursorY or not minimapX or not minimapY then return end
    local scale = (UIParent.GetEffectiveScale and UIParent:GetEffectiveScale()) or (UIParent.GetScale and UIParent:GetScale()) or 1
    if scale == 0 then scale = 1 end
    local angle = Atan2((cursorY / scale) - minimapY, (cursorX / scale) - minimapX) * 180 / PI
    if angle < 0 then angle = angle + 360 end
    AscensionRaidRollsDB.minimapAngle = angle
    Position(angle)
end

function Addon.UpdateMinimapVisibility()
	if not State.minimapButton then return end
	if AscensionRaidRollsDB and AscensionRaidRollsDB.hideMinimapIcon then
		State.minimapButton:Hide()
	else
		State.minimapButton:Show()
	end
end

function Addon.CreateMinimapButton(toggleActiveModule)
    if State.minimapButton or not Minimap then return end
    local button = CreateFrame("Button", "DemiseRaidRollsMinimapButton", Minimap)
    State.minimapButton = button
    button:SetWidth(32); button:SetHeight(32); button:SetFrameStrata("MEDIUM")
    button:SetFrameLevel((Minimap:GetFrameLevel() or 0) + 8)
    button:RegisterForClicks("LeftButtonUp", "RightButtonUp"); button:RegisterForDrag("LeftButton"); button:EnableMouse(true)
    button.icon = button:CreateTexture(nil, "ARTWORK")
    button.icon:SetWidth(20); button.icon:SetHeight(20); button.icon:SetPoint("CENTER")
    button.icon:SetTexture("Interface\\Icons\\INV_Misc_Dice_02"); button.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
    button.border = button:CreateTexture(nil, "OVERLAY")
    button.border:SetWidth(54); button.border:SetHeight(54); button.border:SetPoint("TOPLEFT")
    button.border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
    button.highlight = button:CreateTexture(nil, "HIGHLIGHT")
    button.highlight:SetWidth(32); button.highlight:SetHeight(32); button.highlight:SetPoint("CENTER")
    button.highlight:SetTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight"); button.highlight:SetBlendMode("ADD")
    button:SetScript("OnClick", function(_, mouseButton)
        if State.minimapDragging then return end
        if mouseButton == "RightButton" then
            if DemiseRaidRollsMenu.frame and DemiseRaidRollsMenu.frame:IsShown() then DemiseRaidRollsMenu.Close() else DemiseRaidRollsMenu.Show() end
        elseif mouseButton == "LeftButton" then
            if DemiseRaidRollsMenu.HasSessionModule and not DemiseRaidRollsMenu.HasSessionModule() then DemiseRaidRollsMenu.Show(); return end
            if DemiseRaidRollsMenu.Hide then DemiseRaidRollsMenu.Hide() end
            toggleActiveModule()
        end
    end)
    button:SetScript("OnDragStart", function(self) State.minimapDragging = true; self:SetScript("OnUpdate", UpdateFromCursor) end)
    button:SetScript("OnDragStop", function(self) self:SetScript("OnUpdate", nil); UpdateFromCursor(); State.minimapDragging = false end)
    button:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_LEFT"); GameTooltip:SetText("DemiseRaidRolls")
        GameTooltip:AddLine("Left-click: show / hide the active module", 1, 1, 1)
        GameTooltip:AddLine("Right-click: open the module menu", 0.85, 0.85, 0.85)
        GameTooltip:AddLine("Drag: move minimap icon", 0.75, 0.75, 0.75); GameTooltip:Show()
    end)
    button:SetScript("OnLeave", function() GameTooltip:Hide() end)
    Position(AscensionRaidRollsDB.minimapAngle or 225)
	Addon.UpdateMinimapVisibility()
end
